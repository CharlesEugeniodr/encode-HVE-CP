# Mathematical foundations

The BASE state space is

`G = Z_360 × Z_2 × Z_5 × Z_9`, with `|G| = 32,400`.

The monolithic index is

`E(theta,s,tau,phi) = (((theta*2+s)*5+tau)*9+phi)`.

The angular distance is the graph distance on `C_360`:

`delta(theta,theta') = min(|theta-theta'|, 360-|theta-theta'|)`.

Characters are

`chi_k(g) = exp(2*pi*i*(k_theta*theta/360 + k_s*s/2 + k_tau*tau/5 + k_phi*phi/9))`.

The forward transform uses the conjugate character, matching NumPy's negative-exponent FFT convention.
