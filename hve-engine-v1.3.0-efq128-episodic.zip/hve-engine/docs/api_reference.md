# API reference

The stable public entry points are documented in module docstrings and type annotations.

- `hve.core`: `HVEState`, `encode_base`, `decode_base`, group operations.
- `hve.angular`: distance, arcs, shortest paths, sectors, resolution maps.
- `hve.harmonic`: characters, DFT/IDFT, convolution, Parseval, Laplacian spectrum.
- `hve.chromatic`: `HVEColor`, pointed-color indexing, HVE-chi.
- `hve.protocol`: BASE15, CHI39, CHI40, HVE1 frames.
- `hve.comparative`: comparison codecs, measurements, proof certificate, and
  JSON/CSV/Markdown reports.
- `hve.tokenization`: deterministic BPE training, HVE token profiles, and
  held-out vocabulary-cost analysis.
- `hve.ai_mapping`: plugin contract and non-learning mappers.
