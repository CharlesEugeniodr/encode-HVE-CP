# HVE-128 episodic memory

## Scope

The episodic layer represents two context dimensions in one canonical 16-byte
EFQ128 token:

- direction on a 112-position cycle;
- an RGB projection derived deterministically from valence and arousal.

The text of the memory, identifiers, timestamps, provenance, and learned
embeddings remain separate database fields. HVE-128 is the typed context token,
not the complete memory record.

## Canonical token

`efq128/episodic-context/v1` fixes:

| Field | Value |
| --- | --- |
| mode | HVE-128 (`4`) |
| theta | `0` |
| micro | `0` |
| sigma | `1` |
| tau | `0` |
| direction | `0..111` |
| RGB | mapped valence/arousal |
| extra | `0x45504931` (`EPI1`) |
| reserved fields | zero |

The `EPI1` tag prevents profile confusion with HVE-Zeta and other EFQ payloads.

## Direction metric

For `a,b in Z_112`:

`distance(a,b) = min(|a-b|, 112-|a-b|)`

`similarity(a,b) = 1 - distance(a,b)/56`

This makes adjacent states near the `111 -> 0` boundary close rather than far
apart. The attached prototype used only exact equality (`1` or `0`), discarding
that circular structure.

## RGB metric

For RGB triples `x` and `y`:

`similarity(x,y) = 1 - ||x-y||_2 / sqrt(3*255^2)`

The result lies in `[0,1]`. The combined score is:

`w * direction_similarity + (1-w) * rgb_similarity`

where `w` is explicit and defaults to `0.5`.

## PostgreSQL boundary

`migrations/001_hve128_episodic.sql`:

- enforces 16-byte HVE tokens and HVE-128 mode;
- stores the wire profile beside every token;
- extracts direction and RGB correctly from canonical or historical bytes;
- materializes those components as generated columns;
- performs exact similarity ranking.

The query is linear in the number of candidate rows. A GIN index on raw `BYTEA`
does not implement nearest-neighbour search. At larger scale, first filter by
indexed metadata/direction sectors or add a separately benchmarked ANN column.
