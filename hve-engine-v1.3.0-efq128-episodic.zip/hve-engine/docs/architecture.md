# Architecture

## Layers

1. **Core** — exact state algebra and mixed-radix bijection.
2. **Angular** — circular geometry on the `theta` factor.
3. **Harmonic** — character basis and Fourier operators on the finite group.
4. **Chromatic** — optional pointed color domain preserving no-color versus black.
5. **Protocol** — binary profiles and framed transport.
6. **Mapping** — deterministic/rule-based adapters and a plugin contract for future learned models.

The layers are intentionally separated. A mapping policy cannot alter the algebraic core, and the core does not assert semantics for coordinate intervals.
