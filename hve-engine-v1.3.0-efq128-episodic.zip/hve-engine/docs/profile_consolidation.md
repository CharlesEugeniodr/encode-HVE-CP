# HVE profile consolidation

## 1. Canonical relationship

The supplied project material describes several layers.  They are compatible
when their cardinalities and semantics are kept explicit:

| Profile | Product | Cardinality | Engine role |
| --- | ---: | ---: | --- |
| HVE-720 | `360 * 2` | 720 | theta/sigma layer |
| HVE-6480 | `360 * 2 * 9` | 6,480 | HVE-720 plus nine phi planes |
| HVE-6480+tau | `360 * 2 * 9 * 5` | 32,400 | complete BASE core |
| HVE-Lang v1.1 legacy | `360 * 2 * 5 * 5` | 18,000 | subset with five nonnegative phi levels |
| HVE-128 EFQ semantic payload | `360 * 1000 * 2 * 3600 * 112 * 2^24` | exact product | high-resolution payload inside a 128-bit envelope |
| HVE-Zeta Sigma-0 | assigned region | 137,000 | concept IDs injected into HVE-128 `(micro,tau)` |

The HVE-6480+tau CSV enumerates the BASE states in document order:

`index = phi * 3600 + tau * 720 + s * 360 + theta`.

The CSV order is exhaustive and bijective over all 32,400 states.

## 2. Semantic orders

The supplied 32,400-row CSV fixes the following orders:

- tau: `0, +15, -15, +30, -30` degrees;
- phi: `base, +15, +30, +45, +60, -15, -30, -45, -60` degrees;
- sigma: `+1, -1`;
- theta varies fastest from `0` through `359`.

The engine retains its older wire order for backward compatibility and exposes
an exhaustive crosswalk to this document order.

## 3. Legacy 18,000-state migration

The uploaded HVE-Lang v1.1 CSV is a wrapped semicolon table.  Its actual state
space is:

`theta in 0..359`, `sigma in {+1,-1}`, `tau in {-2,-1,0,1,2}`,
`phi in {0,1,2,3,4}`.

The migration interprets each tau level as 15 degrees and each phi level as a
nonnegative 15-degree plane:

- tau `-2,-1,0,1,2` -> `-30,-15,0,+15,+30`;
- phi `0,1,2,3,4` -> `base,+15,+30,+45,+60`.

This gives an injective 18,000-state subset of HVE-32,400.  The 14,400 new
states are the four negative phi planes across the same 3,600 theta/sigma/tau
states.

The legacy metric columns are retained only as source metadata.  If
`Bits_Angular` is interpreted as the minimum state index width, 18,000 states
need 15 bits, not 70.  The declared `Bits_Total_Minimo=40.34` is also smaller
than the declared 41-bit color field, and 25 bytes equals 200 bits rather than
the declared `70+41=111` bits.  Those values require a separate framing or
coding specification before they can become normative.

## 4. HVE-128 EFQ layouts

The primary source lists:

- mode: 3 bits;
- reserved A: 5;
- theta: 9;
- micro: 10;
- sigma: 1;
- tau: 12;
- direction: 7;
- RGB: 24;
- extra: 32;
- reserved B: 24.

These declared widths sum to 127, not 128. The source also labels the seven-bit
direction field as bits 87..80, an eight-bit inclusive interval. Engine 1.2
resolved the specification itself by reserving bit 87, placing direction at
86..80, and keeping RGB contiguous at 79..56.

The subsequently supplied `hve_toolkit_128.py` proves that the historical
implementation did something different. Its function constructs `high_64`
three times; only the last construction reaches `struct.pack`. That effective
wire layout is:

- direction: global bits 87..81;
- upper 16 RGB bits: 80..65;
- unused gap: bit 64;
- lower eight RGB bits: 63..56.

For the sample fields `(theta=12, micro=94, sigma=1, tau=2, direction=2,
RGB=0xFF0000, extra=12)`, the encoders produce:

- canonical: `80060bd00202ff00000000000c000000`;
- attached toolkit: `80060bd00205fe00000000000c000000`.

The formats are individually reversible but not byte-compatible. Engine 1.3
therefore retains the coherent declared layout as `efq128-canonical-v1` and
implements the actual historical bytes as
`efq128-attached-toolkit-legacy-v1`, with explicit semantic transcoding.

Two additional historical defects are isolated rather than propagated:

- negative tau values are masked into unsigned 12-bit values (`-2 -> 4094`,
  `-1 -> 4095`); the transcode preserves raw `0..3599` values and maps only the
  invalid upper region onto the canonical 3600-cycle;
- `extra = (phi << 2) | (tau + 2)` overlaps one bit because `tau + 2` needs
  three bits. It is not an injective pair encoding and cannot recover every
  `(phi, tau)` pair.

The semantic field product is:

`N = 360 * 1000 * 2 * 3600 * 112 * 2^24`.

Its entropy satisfies `62 < log2(N) < 63`; therefore the semantic payload needs
63 bits in a minimum fixed-width word.  The 128-bit token is an envelope that
also carries mode, metadata, and reserved expansion space.  These are distinct
claims and are reported separately.

## 5. HVE-Zeta boundary

The supplied note states that 137,000 concepts were mapped injectively into
`(delta-theta,tau)` at `theta=0`. A file named `hve_toolkit_128.py` was later
supplied, but it contains no Zeta constant, function, dictionary, encoder, or
test. It therefore is not the v5 Zeta artifact described by the note. Engine
1.2's independently named mapping remains:

`zeta-sigma0/micro-fast/engine-v1`.

For concept index `i`:

`micro = i mod 1000`, `tau = floor(i / 1000)`.

The inverse is `i = 1000 * tau + micro`.  The assigned region uses 137 tau rows
out of the available 3,600 and is exhaustively tested for all 137,000 IDs.
This proves the engine mapping. It does not assert binary compatibility with a
Zeta implementation that is still absent.

## 6. Episodic-memory profile

The attached episodic prototype stores direction and valence/arousal-derived
RGB inside HVE-128. Engine 1.3 keeps that deterministic mapping and replaces
the placeholder retrieval with:

- shortest circular distance on the 112-position direction cycle;
- normalized Euclidean distance in the RGB cube;
- a weighted score with an explicit direction weight;
- a namespace tag (`EPI1`) in `extra`, preventing an episodic token from being
  silently decoded as Zeta or another EFQ profile;
- a PostgreSQL migration that stores the 16-byte token and its wire-profile
  identifier, extracts canonical or legacy direction/RGB correctly, and
  performs real ranking.

The PostgreSQL query is an exact scan. The migration does not claim that a GIN
index on `BYTEA` provides nearest-neighbour vector search. A separate ANN
representation or extension is required for approximate large-scale retrieval.

## 7. Visual boundary

The supplied radial numeral-zero image is a useful visualization of layered
angular rays.  The image alone is not evidence of fractality: no iterative
similarity rule, scaling law, or fractal dimension is defined in the artifact.
It is retained as conceptual visualization, not as a normative state table or
mathematical proof.
