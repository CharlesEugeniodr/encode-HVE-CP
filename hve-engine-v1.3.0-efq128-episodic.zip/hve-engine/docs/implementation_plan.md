# HVE Engine — Plano de Implementação Final

> Decisões congeladas em 2026-07-19. Todas as Open Questions resolvidas.

## Decisões Consolidadas

| Decisão | Resolução |
|---------|-----------|
| **Licença** | MIT |
| **Angular Engine** | Geometria circular completa em C₃₆₀ — distância geodésica discreta, vizinhança, arcos, média circular, setores, quantização multi-resolução |
| **Harmonic Engine** | Caracteres χ_k(g), DFT/IDFT sobre G, implementação separável, convolução, Parseval, espectro Laplaciano |
| **AI Mapping** | Interface formal + mapeadores determinístico/regras. Nenhum modelo treinado no Core 1.0 |
| **Repositório** | Novo `hve-engine`. `encode-HVE-CP` permanece como arquivo histórico |
| **Alegação IA** | "AI Mapping Layer defines an extensible inference interface. No trained model is included in the core release." |
| **Alegação geográfica** | Nenhuma geolocalização terrestre. Geodésica = comprimento do menor caminho no grafo circular C₃₆₀ |

---

## Estrutura do Repositório

```
hve-engine/
├── README.md
├── LICENSE                            # MIT
├── CITATION.cff
├── CHANGELOG.md
├── pyproject.toml                     # pip install .
│
├── src/hve/
│   ├── __init__.py                    # Exports públicos + versão
│   ├── core.py                        # HVE-720 BASE: bijeção, grupo, validação
│   ├── angular.py                     # Angular State Engine (C₃₆₀ geometria)
│   ├── harmonic.py                    # Harmonic Engine (DFT sobre G)
│   ├── chromatic.py                   # Chromatic Engine (HVE-χ)
│   ├── protocol.py                    # Framing HVE1 + stream packing
│   ├── canonical.py                   # Conjunto canônico dos 32.400 estados
│   ├── benchmark.py                   # Benchmarks reproduzíveis
│   ├── visualize.py                   # Visualizador (matplotlib)
│   ├── cli.py                         # Interface de linha de comando
│   └── ai_mapping/
│       ├── __init__.py
│       ├── interfaces.py              # Contrato MappingResult + AbstractMapper
│       ├── result.py                  # MappingResult dataclass
│       ├── registry.py                # MapperRegistry (plugin system)
│       ├── deterministic_mapper.py    # Unicode → HVE canônico
│       └── rule_based_mapper.py       # Classificação por regras
│
├── tests/
│   ├── test_core.py                   # Exaustivo: 32.400 round-trips + 368 reservados
│   ├── test_angular.py                # Geometria circular, geodésica, vizinhança
│   ├── test_harmonic.py               # DFT, Parseval, ortogonalidade, convolução
│   ├── test_chromatic.py              # HVE-χ round-trips
│   ├── test_protocol.py              # Framing, CRC, stream packing
│   ├── test_canonical.py             # Validação do conjunto canônico
│   ├── test_ai_mapping.py            # Interface, mapeadores, registry
│   └── golden_vectors.json           # Vetores determinísticos
│
├── examples/
│   ├── basic_usage.py
│   ├── angular_distance.py
│   ├── harmonic_transform.py
│   ├── chromatic_states.py
│   └── custom_mapper.py
│
├── datasets/
│   └── canonical/
│       └── hve720_canonical_states.json
│
├── docs/
│   ├── architecture.md
│   ├── mathematical_foundations.md
│   ├── api_reference.md
│   └── protocol_specification.md
│
├── benchmarks/
│   └── run_benchmarks.py
│
└── .github/
    └── workflows/
        └── ci.yml
```

---

## Especificação Detalhada dos Módulos

### Fase 1 — `hve.core` (importação do código validado)

Importar e reorganizar de `hve_ref.py` (Part I):

```python
# Tipos
HVEState(theta, s, tau, phi)          # frozen dataclass
HVEColor(present, r, g, b)           # frozen dataclass

# Bijeção BASE
encode_base(state) → int              # mixed-radix: (((θ·2+s)·5+τ)·9+φ)
decode_base(index) → HVEState         # divisões sucessivas por 9, 5, 2

# Grupo G = Z₃₆₀ × Z₂ × Z₅ × Z₉
group_add(a, b) → HVEState            # soma componente a componente mod
group_inverse(a) → HVEState           # negação modular
group_identity() → HVEState           # (0, 0, 0, 0)

# Validação
validate_state(state) → None          # raises HVEError
validate_index(index) → None          # rejeita ∉ [0, 32399]

# Constantes
BASE_CARDINALITY = 32_400
THETA_CARD = 360; S_CARD = 2; TAU_CARD = 5; PHI_CARD = 9
RESERVED_WORDS = 368
```

---

### Fase 2 — `hve.angular` (Angular State Engine)

```python
# Distância circular
circular_distance(θ₁, θ₂) → int       # min(|θ₁-θ₂|, 360-|θ₁-θ₂|)
normalized_distance(θ₁, θ₂) → float   # δ/180 ∈ [0, 1]

# Caminho mínimo
shortest_path(θ₁, θ₂) → ShortestPath
  # .distance: int
  # .clockwise: int  (passos CW)
  # .counterclockwise: int  (passos CCW)
  # .direction: 'cw' | 'ccw' | 'antipodal'
  # .arc: list[int]  (θ intermediários)

# Vizinhança
neighborhood(θ, r) → set[int]         # {θ-r, ..., θ+r} mod 360

# Operações angulares
rotate(θ, delta) → int                # (θ + delta) % 360
circular_interval(start, end) → set   # arco de start a end (CW)
arc_contains(start, end, θ) → bool    # θ pertence ao arco?
circular_center(thetas) → float       # centro circular (atan2)
circular_mean(thetas) → float         # média circular
sector_group(thetas, n_sectors) → dict  # agrupamento por setores

# Quantização multi-resolução
quantize_base(θ) → int                # resolução BASE (1°)
quantize_micro(θ, micro_factor) → float  # sub-grau
quantize_nano(θ, nano_factor) → float   # sub-sub-grau
project_resolution(value, from_level, to_level) → value  # projeção

# Geodésica
geodesic_distance(θ₁, θ₂) → int       # = circular_distance (alias explícito)
```

---

### Fase 3 — `hve.harmonic` (Harmonic Engine)

```python
# Caracteres do grupo G = Z₃₆₀ × Z₂ × Z₅ × Z₉
character(k, g) → complex
  # χ_k(g) = exp[2πi(k_θ·θ/360 + k_s·s/2 + k_τ·τ/5 + k_φ·φ/9)]

# DFT sobre G
dft(f) → f_hat                        # f̂(k) = Σ_g f(g)·conj(χ_k(g))
  # f: ndarray[360, 2, 5, 9] → f_hat: ndarray[360, 2, 5, 9]

idft(f_hat) → f                       # f(g) = (1/|G|) Σ_k f̂(k)·χ_k(g)

# Implementação separável (eficiente)
dft_separable(f) → f_hat              # DFT ao longo de cada eixo separadamente
  # Complexidade: 360·(360+2+5+9)·2·5·9 em vez de 32400²

idft_separable(f_hat) → f

# Referência lenta (oráculo de teste)
dft_reference(f) → f_hat              # O(N²) direto para validação

# Operações
convolve(f, g) → h                    # convolução no grupo via DFT
correlate(f, g) → h                   # correlação
spectral_filter(f, mask) → f_filtered # filtro no domínio espectral

# Verificação
parseval_check(f, f_hat) → bool       # Σ|f|² = (1/|G|)Σ|f̂|²
orthogonality_check(k1, k2) → bool    # <χ_k1, χ_k2> = |G|·δ_{k1,k2}

# Análise
power_spectrum(f) → ndarray           # |f̂(k)|²
laplacian_spectrum(adjacency) → eigenvalues  # espectro do Laplaciano
harmonic_modes(n) → list[ndarray]     # primeiros n modos harmônicos

# Raízes da unidade (pré-computadas para eficiência)
_roots_360: ndarray                   # exp(2πi·n/360) para n=0..359
_roots_2: ndarray                     # exp(2πi·n/2) para n=0,1
_roots_5: ndarray                     # exp(2πi·n/5) para n=0..4
_roots_9: ndarray                     # exp(2πi·n/9) para n=0..8
```

---

### Fase 4 — `hve.chromatic` + `hve.protocol`

Importar de `hve_ref.py`:

```python
# Chromatic (HVE-χ)
color_kappa(color) → int              # NoColor→0, RGB→1+R·2¹⁶+G·2⁸+B
color_kappa_inverse(kappa) → HVEColor
encode_chi(state, color) → int        # base_index × 16,777,217 + κ
decode_chi(index) → (HVEState, HVEColor)

# Protocol (HVE1 framing + stream)
pack_base15(indices) → bytes          # MSB-first 15-bit packing
unpack_base15(data, count) → list[int]
pack_chi40(state, color) → bytes      # [index:15][P:1][R:8][G:8][B:8]
unpack_chi40(data) → (HVEState, HVEColor)
pack_chi39(index) → bytes             # 39-bit compact
unpack_chi39(data) → int
make_frame(profile, count, payload) → bytes  # HVE1 header + CRC-32
parse_frame(frame) → (profile, flags, count, payload)
```

---

### Fase 5 — `hve.ai_mapping` (Interface)

```python
@dataclass
class MappingResult:
    state: HVEState
    confidence: float                  # 0.0 para determinístico
    mapper_id: str
    mapper_version: str
    provenance: dict
    alternatives: list['MappingResult']

class AbstractMapper(ABC):
    @abstractmethod
    def map(self, input_data, **kwargs) → MappingResult: ...

class DeterministicMapper(AbstractMapper):
    """Unicode codepoint → posição HVE via tabela canônica."""

class RuleBasedMapper(AbstractMapper):
    """Classificação por classe Unicode, idioma, categoria."""

class MapperRegistry:
    def register(name, mapper): ...
    def get(name) → AbstractMapper: ...
    def list_mappers() → list[str]: ...
```

---

### CLI

```bash
hve validate                                    # 32.400 válidos + 368 reservados + zero falhas
hve encode --theta 45 --s 0 --tau 2 --phi 3    # → 4071
hve encode --theta 45 --s 0 --tau 2 --phi 3 --color 128,64,32  # → HVE-χ
hve decode 4071                                  # → (θ=45, s=0, τ=2, φ=3)
hve decode --chi 68301430233                     # → estado + cor
hve angular-distance 359 0                       # → 1
hve angular-distance 180 0                       # → 180 (antipodal)
hve neighborhood 0 --radius 3                    # → {357, 358, 359, 0, 1, 2, 3}
hve visualize --mode angular --output fig.png
hve visualize --mode state-space --output fig.png
hve visualize --mode harmonic --output fig.png
hve benchmark --iterations 100000
```

---

## Plano de Execução (5 Fases)

### Fase 1 — Infraestrutura + Core (fundação)
- [ ] Criar diretório `hve-engine/`
- [ ] `pyproject.toml` com metadata, dependencies, CLI entry point
- [ ] `LICENSE` (MIT)
- [ ] `src/hve/__init__.py` com versão e exports
- [ ] `src/hve/core.py` — importar e reorganizar de `hve_ref.py`
- [ ] `src/hve/chromatic.py` — extrair lógica HVE-χ
- [ ] `src/hve/protocol.py` — extrair framing e stream packing
- [ ] `tests/test_core.py` — exaustivo (32.400 + 368 + grupo)
- [ ] `tests/test_chromatic.py` — 100K round-trips + boundaries
- [ ] `tests/test_protocol.py` — CRC, framing, packing
- [ ] `tests/golden_vectors.json` — importar vetores

### Fase 2 — Angular Engine + Harmonic Engine
- [ ] `src/hve/angular.py` — geometria circular completa
- [ ] `tests/test_angular.py` — distâncias, vizinhança, arcos, geodésica
- [ ] `src/hve/harmonic.py` — caracteres, DFT separável, convolução
- [ ] `tests/test_harmonic.py` — Parseval, ortogonalidade, inversão, convolução

### Fase 3 — AI Mapping + Canonical
- [ ] `src/hve/ai_mapping/interfaces.py` — AbstractMapper
- [ ] `src/hve/ai_mapping/result.py` — MappingResult
- [ ] `src/hve/ai_mapping/registry.py` — MapperRegistry
- [ ] `src/hve/ai_mapping/deterministic_mapper.py`
- [ ] `src/hve/ai_mapping/rule_based_mapper.py`
- [ ] `src/hve/canonical.py` — tabela canônica
- [ ] `datasets/canonical/hve720_canonical_states.json`
- [ ] `tests/test_ai_mapping.py`
- [ ] `tests/test_canonical.py`

### Fase 4 — CLI + Visualização + Benchmarks
- [ ] `src/hve/cli.py` — click CLI completa
- [ ] `src/hve/visualize.py` — matplotlib visualizações
- [ ] `src/hve/benchmark.py` — benchmarks reproduzíveis
- [ ] `benchmarks/run_benchmarks.py`
- [ ] Exemplos em `examples/`

### Fase 5 — Documentação + CI + Release
- [ ] `README.md` com quickstart completo
- [ ] `docs/architecture.md`
- [ ] `docs/mathematical_foundations.md`
- [ ] `docs/api_reference.md`
- [ ] `docs/protocol_specification.md`
- [ ] `CITATION.cff`
- [ ] `CHANGELOG.md`
- [ ] `.github/workflows/ci.yml` (pytest + lint)
- [ ] Tag v1.0.0

---

## Verificação

### Testes Automatizados
```bash
pip install .
pytest tests/ -v --tb=short
hve validate
hve benchmark --iterations 10000
```

### Critérios de Aceitação
- `hve validate` → 32.400 válidos, 368 rejeitados, zero falhas
- `hve encode --theta 0 --s 0 --tau 0 --phi 0` → `0`
- `hve decode 32399` → `(θ=359, s=1, τ=4, φ=8)`
- `circular_distance(359, 0)` → `1`
- `circular_distance(180, 0)` → `180`
- Parseval: `Σ|f|² == (1/|G|)·Σ|f̂|²` com tolerância < 1e-10
- Round-trip DFT: `idft(dft(f)) ≈ f` com tolerância < 1e-10
- Todos os testes passam em CI (Python 3.10+)
