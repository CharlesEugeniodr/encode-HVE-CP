# HVE × UTF-8 × Binary21 comparison methodology

## Purpose

The comparison engine tests three independent propositions:

1. how much space each representation occupies on the same corpus;
2. how the reference Python implementations perform on the same host;
3. which relations and operators each representation supplies natively.

The engine does not create a composite score. A system can win one metric and
lose another.

## Compared profiles

### UTF-8

The standard lossless UTF-8 byte representation of the input Unicode scalars.

### Binary21

Every Unicode scalar is stored as one fixed 21-bit unsigned integer. This is a
transparent fixed-width binary baseline, not a claim that raw binary has an
intrinsic character model.

### LAB-720 v0

The historical table in `HVE.docx` contains 119 scalar assignments in T+ and 50
in T-. Placeholder labels such as `EXT_RESERVE_119` are reserved names, not
characters, and are excluded. The resulting 169 assignments are packed at
10 bits per position. The T- index is normalized to
`360 + (degree_abs - 1)`, resolving the document's off-by-one endpoint while
preserving the declared interval 0..719.

### HVE-4D BASE15

Canonical HVE states are encoded in 15 bits. This profile is reported only when
every input scalar has a versioned canonical assignment.

### HVE hybrid

The universal text profile encodes a mapped LAB-720 scalar as
`0 || LAB10` (11 bits) and an unassigned Unicode scalar as
`1 || scalar21` (22 bits). Fallback guarantees reversibility but does not invent
HVE geometry for a symbol absent from the table.

### HVE token profile

The optional token experiment trains a deterministic BPE vocabulary on a
declared prefix and measures only the held-out suffix. A pure profile uses
15 bits per vocabulary token when coverage is complete. A universal profile
uses `0 || token15` or `1 || scalar21`. The report gives both payload-only cost
and payload plus the complete UTF-8-serialized vocabulary. No token-order
semantic claim is inferred from compression. When payload bytes are lower than
UTF-8, the report also calculates the amount of held-out text required to
amortize the one-time vocabulary cost.

## Fairness controls

- Identical input text is used for every codec.
- Every result must round-trip exactly.
- Payload bits and stored payload bytes are reported separately.
- An identical 20-byte HVC1 reference frame and CRC-32 are applied when framed
  size or integrity is compared.
- Coverage and fallback cost are explicit.
- Timing uses repeated operations, a warm-up call, medians, and deterministic
  95% bootstrap confidence intervals.
- Single-bit faults are sampled from significant payload bits only.
- zlib level 9 is reported as a common general-purpose compression reference.
- User-supplied UTF-8 files are supported; built-in texts are fixtures, not
  presented as real-world corpora.

## Structural certificate

The certificate executes five obligations:

1. exhaustive BASE bijection over 32,400 states;
2. rejection of all 368 reserved 15-bit words;
3. lossless HVE RAW embedding of deterministic binary vectors;
4. lossless HVE hybrid embedding of boundary and multilingual Unicode vectors;
5. existence of strict added structure within the declared criteria.

The delimited claim is that HVE Universal is a strict functional and structural
extension of raw binary and UTF-8 for lossless embeddings, typed HVE
coordinates, circular metric, finite-group operations, and harmonic transform.

The certificate does **not** claim universal dominance in storage size,
execution speed, byte alignment, or deployed interoperability.

## Mixed-radix layout crosswalk

Two bijective index orders exist in project material:

- Engine 1.0:
  `(((theta * 2 + s) * 5 + tau) * 9 + phi)`;
- 2025 document:
  `phi * 3600 + tau * 720 + s * 360 + theta`.

The default `encode_base`/`decode_base` functions retain Engine 1.0 wire
compatibility. `encode_base_with_layout`, `decode_base_with_layout`, and
`transcode_base_index` make the alternative explicit and reversible.

## Reproduction

```bash
hve compare --output-dir comparison-results
hve compare corpus-a.txt corpus-b.txt --output-dir comparison-results
hve compare corpus.txt --token-vocabulary-size 4096
```

Artifacts:

- `hve_comparison_report.json`;
- `hve_storage_metrics.csv`;
- `hve_comparison_report.md`.
