# Protocol specification 1.0

## BASE15

Each valid BASE index is a 15-bit unsigned word in `[0, 32399]`. Values `[32400, 32767]` are reserved and must be rejected. Streams are packed MSB-first. Final padding bits must be zero.

## CHI39

The monolithic HVE-chi index occupies 39 significant bits inside five bytes. The most significant bit of the five-byte container is reserved and must be zero.

## CHI40

`[BASE index:15][P:1][R:8][G:8][B:8]`. `P=0` requires `R=G=B=0`. `P=1,R=G=B=0` is RGB black.

## HVE1 frame

16-byte header: magic `HVE1`, major version, profile, 16-bit flags, 32-bit state count, and CRC-32 of payload, all multibyte integers in network byte order.
