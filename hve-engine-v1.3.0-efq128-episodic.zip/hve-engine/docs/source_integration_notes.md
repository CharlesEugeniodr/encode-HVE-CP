# Integration notes for the supplied HVE project documents

The comparison layer was checked against:

- `HVE.docx`;
- `Conclusao_Unificada_HVE_720_HVE_Chi_PT.docx`.

## Incorporated definitions

- LAB-720 uses 720 angular/directional positions and a 10-bit address.
- HVE-4D uses `360 × 2 × 5 × 9 = 32,400` states and a 15-bit
  monolithic address.
- The HVE-4D vocabulary can represent characters or longer tokens; compression
  gains must be measured separately from state cardinality.
- Token-based gains must include mapping/vocabulary cost and obey entropy
  limits.
- The chromatic extension and higher-layer applications remain separate from
  the core comparison.
- Empirical comparison must use equivalent conditions and must not infer
  semantic validity from index proximity alone.

## Resolved inconsistencies

### Mixed-radix order

The 2025 project document uses:

`phi * 3600 + tau * 720 + s * 360 + theta`.

Engine 1.0 uses:

`(((theta * 2 + s) * 5 + tau) * 9 + phi)`.

Both are exact bijections, but their indices differ. Engine 1.2 retains the
Engine 1.0 layout as the default for wire compatibility and provides an
exhaustively tested crosswalk to the document layout.

### T- endpoint

The LAB-720 text declares the address interval `0..719` but writes
`360 + theta` for T- degrees `1..360`, which would produce `361..720`. The
versioned executable profile uses `360 + (degree_abs - 1)`, producing exactly
`360..719`.

### Scalar assignments and reserve labels

The source tables contain 119 single-scalar T+ assignments and 50
single-scalar T- assignments. The remaining 551 positions carry reserve,
control, or extension labels. Labels such as `EXT_RESERVE_119` are not Unicode
characters and are not silently added to the text alphabet.

## Source-document benchmark

The supplied unified conclusion was used as a real project-text measurement:

- total text: 7,132 characters;
- token vocabulary: trained on the first 80%, target size 512;
- evaluation: held-out final 20%;
- mean evaluation density: 2.597 characters per token;
- HVE hybrid token payload: 26.12% smaller than UTF-8;
- one-time vocabulary cost: 3,105 bytes;
- amortization break-even: 11,408 evaluated characters.

The result proves a gain for this measured token profile at sufficient reuse.
It is not generalized to unrelated corpora without rerunning the same test.
