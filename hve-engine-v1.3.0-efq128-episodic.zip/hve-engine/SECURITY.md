# Security policy

HVE Engine is an encoding and state-representation framework. It is not a cryptographic cipher and must not be used as a substitute for authenticated encryption, key derivation, or threshold secret sharing.

Report implementation vulnerabilities privately to the repository owner before public disclosure.
