# HVE × UTF-8 × Binary21 — Comparative Report

Generated: `2026-07-28T03:30:09Z`

## Structural result

**Certificate:** PASS

HVE Universal is a strict functional and structural extension of raw binary and UTF-8 within the declared dominance scope.

Not claimed: universal superiority in storage size, execution speed, byte alignment, or deployed interoperability.

| Proof obligation | Result |
|---|---:|
| base_bijection_32400 | PASS |
| reserved_words_rejected_368 | PASS |
| binary_embedding_roundtrips | PASS |
| unicode_embedding_roundtrips | PASS |
| layout_crosswalk_32400 | PASS |
| lab720_scalar_assignments_169 | PASS |
| strict_added_structure | PASS |

## Storage by corpus

| Corpus | Codec | Coverage | Payload bytes | Bits/char | Δ vs UTF-8 |
|---|---|---:|---:|---:|---:|
| ascii | utf8 | n/a | 93 | 8.000 | +0.00% |
| ascii | binary21 | n/a | 245 | 21.000 | +163.44% |
| ascii | hve_hybrid | 87.10% | 145 | 12.419 | +55.91% |
| ascii | hve_lab720_v0 | n/a | n/a | n/a | n/a |
| ascii | hve_base15 | n/a | n/a | n/a | n/a |
| portuguese | utf8 | n/a | 131 | 8.807 | +0.00% |
| portuguese | binary21 | n/a | 313 | 21.000 | +138.93% |
| portuguese | hve_hybrid | 87.39% | 185 | 12.387 | +41.22% |
| portuguese | hve_lab720_v0 | n/a | n/a | n/a | n/a |
| portuguese | hve_base15 | n/a | n/a | n/a | n/a |
| multilingual | utf8 | n/a | 123 | 16.400 | +0.00% |
| multilingual | binary21 | n/a | 158 | 21.000 | +28.46% |
| multilingual | hve_hybrid | 15.00% | 153 | 20.350 | +24.39% |
| multilingual | hve_lab720_v0 | n/a | n/a | n/a | n/a |
| multilingual | hve_base15 | n/a | n/a | n/a | n/a |
| canonical_assigned | utf8 | n/a | 271 | 12.828 | +0.00% |
| canonical_assigned | binary21 | n/a | 444 | 21.000 | +63.84% |
| canonical_assigned | hve_hybrid | 100.00% | 233 | 11.000 | -14.02% |
| canonical_assigned | hve_lab720_v0 | 100.00% | 212 | 10.000 | -21.77% |
| canonical_assigned | hve_base15 | n/a | n/a | n/a | n/a |

## Reference Python performance

Medians include 95% bootstrap confidence intervals. These are host and implementation measurements, not universal hardware claims.

| Corpus | Codec | Encode MiB/s | Decode MiB/s |
|---|---|---:|---:|
| ascii | utf8 | 5.459 | 656.134 |
| ascii | binary21 | 0.413 | 0.399 |
| ascii | hve_hybrid | 0.529 | 0.521 |
| portuguese | utf8 | 15.683 | 601.872 |
| portuguese | binary21 | 0.462 | 0.426 |
| portuguese | hve_hybrid | 0.603 | 0.597 |
| multilingual | utf8 | 21.882 | 345.874 |
| multilingual | binary21 | 0.844 | 0.807 |
| multilingual | hve_hybrid | 0.708 | 0.676 |
| canonical_assigned | utf8 | 21.923 | 695.933 |
| canonical_assigned | binary21 | 0.650 | 0.615 |
| canonical_assigned | hve_lab720_v0 | 1.146 | 1.126 |
| canonical_assigned | hve_hybrid | 0.986 | 0.982 |

## Single-bit payload errors

| Corpus | Codec | Detected | Silent | Common CRC detected |
|---|---|---:|---:|---:|
| ascii | utf8 | 10.94% | 89.06% | 100.00% |
| ascii | binary21 | 0.00% | 100.00% | 100.00% |
| ascii | hve_hybrid | 23.83% | 76.17% | 100.00% |
| portuguese | utf8 | 14.84% | 85.16% | 100.00% |
| portuguese | binary21 | 0.00% | 100.00% | 100.00% |
| portuguese | hve_hybrid | 24.61% | 75.39% | 100.00% |
| multilingual | utf8 | 33.59% | 66.41% | 100.00% |
| multilingual | binary21 | 0.39% | 99.61% | 100.00% |
| multilingual | hve_hybrid | 7.81% | 92.19% | 100.00% |
| canonical_assigned | utf8 | 24.61% | 75.39% | 100.00% |
| canonical_assigned | binary21 | 0.00% | 100.00% | 100.00% |
| canonical_assigned | hve_lab720_v0 | 35.55% | 64.45% | 100.00% |
| canonical_assigned | hve_hybrid | 42.97% | 57.03% | 100.00% |

## Pattern and semantic evaluation

| Corpus | Exact pattern identity |
|---|---:|
| ascii | PASS |
| portuguese | PASS |
| multilingual | PASS |
| canonical_assigned | PASS |

Semantic evaluation status: `not_evaluated`.

No independent labelled similarity pairs were supplied; numeric proximity is not treated as automatic semantic evidence.

## Harmonic-domain benchmark

- States: 32400
- HVE shape: `[360, 2, 5, 9]`
- HVE round-trip max error: `2.232e-15`
- Parseval: PASS
- Median HVE FFTN / flat FFT cost ratio: `2.2759`

The flat FFT is a computational cost baseline. Raw binary and UTF-8 have no intrinsic four-axis harmonic domain.


## Interpretation boundary

- Structural dominance is proved only for the declared functional scope.
- Storage and speed are empirical, corpus-dependent outcomes.
- Binary21 is a fixed Unicode-scalar baseline; raw binary has no intrinsic character semantics.
- HVE BASE15 is reported only when every input symbol has a canonical mapping.
- HVE hybrid fallback preserves Unicode identity but does not invent HVE geometry for an unassigned symbol.
