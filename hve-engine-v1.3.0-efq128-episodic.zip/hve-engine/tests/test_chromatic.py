import random
from hve.chromatic import *
from hve.core import HVEState


def test_special_colors():
    no_color = HVEColor.no_color()
    black = HVEColor.rgb(0,0,0)
    white = HVEColor.rgb(255,255,255)
    assert color_kappa(no_color) == 0
    assert color_kappa(black) == 1
    assert color_kappa(white) == 1 << 24
    assert no_color != black


def test_chi_roundtrip_random():
    rng = random.Random(20260719)
    for _ in range(10_000):
        state = HVEState(rng.randrange(360), rng.randrange(2), rng.randrange(5), rng.randrange(9))
        color = HVEColor.rgb(rng.randrange(256), rng.randrange(256), rng.randrange(256))
        assert decode_chi(encode_chi(state, color)) == (state, color)
