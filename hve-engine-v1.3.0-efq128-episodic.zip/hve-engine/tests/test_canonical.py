from hve.canonical import canonical_positions, position_for_symbol


def test_all_positions_exist():
    positions = canonical_positions()
    assert len(positions) == 720
    assert len({(p.theta,p.s) for p in positions}) == 720
    assert all(p.state.tau == 0 and p.state.phi == 0 for p in positions)


def test_confirmed_symbols():
    assert position_for_symbol("0").theta == 0
    assert position_for_symbol("A").theta == 10
    assert position_for_symbol("a").theta == 36
    assert position_for_symbol(" ").theta == 119
