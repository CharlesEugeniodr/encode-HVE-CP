import pytest
from hve.core import *


def test_exhaustive_base_roundtrip():
    seen = bytearray(BASE_CARDINALITY)
    for theta in range(360):
        for s in range(2):
            for tau in range(5):
                for phi in range(9):
                    state = HVEState(theta, s, tau, phi)
                    index = encode_base(state)
                    assert seen[index] == 0
                    seen[index] = 1
                    assert decode_base(index) == state
    assert all(seen)


def test_reserved_words_rejected():
    for index in range(BASE_CARDINALITY, 1 << 15):
        with pytest.raises(HVEError):
            decode_base(index)


def test_group_axioms_sampled():
    e = group_identity()
    samples = [HVEState(0,0,0,0), HVEState(359,1,4,8), HVEState(123,0,3,7)]
    for a in samples:
        assert group_add(a, e) == a
        assert group_add(a, group_inverse(a)) == e
    a,b,c = samples
    assert group_add(group_add(a,b),c) == group_add(a,group_add(b,c))


def test_document_2025_layout_and_crosswalk():
    state = HVEState(45, 0, 2, 3)
    engine_index = encode_base_with_layout(state, BASE_LAYOUT_ENGINE_V1)
    document_index = encode_base_with_layout(state, BASE_LAYOUT_DOCUMENT_2025)
    assert engine_index == 4071
    assert document_index == 12_285
    assert decode_base_with_layout(document_index, BASE_LAYOUT_DOCUMENT_2025) == state
    assert (
        transcode_base_index(
            engine_index,
            BASE_LAYOUT_ENGINE_V1,
            BASE_LAYOUT_DOCUMENT_2025,
        )
        == document_index
    )


def test_both_base_layouts_are_exhaustive_bijections():
    for layout in BASE_LAYOUTS:
        seen = bytearray(BASE_CARDINALITY)
        for index in range(BASE_CARDINALITY):
            state = decode_base_with_layout(index, layout)
            recovered = encode_base_with_layout(state, layout)
            assert recovered == index
            assert seen[recovered] == 0
            seen[recovered] = 1
        assert all(seen)
