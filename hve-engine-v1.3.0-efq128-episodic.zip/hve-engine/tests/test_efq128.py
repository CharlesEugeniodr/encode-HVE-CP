import math

import pytest

from hve.core import HVEError
from hve.efq128 import (
    EFQ128_BIT_WIDTH,
    FIELD_WIDTHS,
    HVE128Fields,
    MODE_HVE128,
    SEMANTIC_PAYLOAD_ENTROPY_BITS,
    SEMANTIC_PAYLOAD_MIN_WORD_BITS,
    efq128_from_bytes,
    pack_efq128,
    unpack_efq128,
)


def test_layout_is_exactly_128_bits():
    assert sum(FIELD_WIDTHS.values()) == EFQ128_BIT_WIDTH == 128


def test_efq128_pack_unpack_and_bytes():
    fields = HVE128Fields(
        mode=MODE_HVE128,
        theta=359,
        micro=999,
        sigma=1,
        tau=3599,
        direction=111,
        rgb=0xFFFFFF,
        extra=0x12345678,
        reserved_a=31,
        reserved_b=0xABCDEF,
    )
    value = pack_efq128(fields)
    assert unpack_efq128(value) == fields
    assert efq128_from_bytes(fields.to_bytes()) == fields


def test_bit_87_gap_is_explicitly_reserved():
    raw = HVE128Fields(
        mode=MODE_HVE128,
        theta=0,
        micro=0,
        sigma=0,
        tau=0,
        direction=0,
        reserved_c=1,
    ).pack(strict_profile=False)
    with pytest.raises(HVEError):
        unpack_efq128(raw)
    assert unpack_efq128(raw, strict_profile=False).reserved_c == 1


def test_semantic_payload_requires_63_bits_not_62():
    assert 62 < SEMANTIC_PAYLOAD_ENTROPY_BITS < 63
    assert SEMANTIC_PAYLOAD_MIN_WORD_BITS == math.ceil(SEMANTIC_PAYLOAD_ENTROPY_BITS) == 63
