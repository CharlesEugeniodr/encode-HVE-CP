import pytest

from hve.core import HVEError
from hve.episodic import (
    EPISODIC_EXTRA_TAG,
    EpisodicMemory,
    decode_episodic_context,
    direction_similarity,
    encode_episodic_context,
    episodic_similarity,
    map_direction_to_hve,
    map_valence_arousal_to_rgb,
    rgb_similarity,
)


def test_direction_map_and_circular_similarity():
    assert map_direction_to_hve("N") == 0
    assert map_direction_to_hve("sw") == 70
    assert direction_similarity(0, 0) == 1.0
    assert direction_similarity(0, 111) == pytest.approx(1.0 - (1.0 / 56.0))
    assert direction_similarity(0, 56) == 0.0
    with pytest.raises(HVEError):
        map_direction_to_hve("invalid")


def test_attached_rgb_mapping_is_preserved():
    assert map_valence_arousal_to_rgb(0.9, 0.9) == 0xE5E500
    assert map_valence_arousal_to_rgb(-0.7, 0.3) == 0x004CB2
    assert map_valence_arousal_to_rgb(0.0, 0.1) == 0xE5E5E5
    assert rgb_similarity(0, 0) == 1.0
    assert rgb_similarity(0, 0xFFFFFF) == 0.0


def test_episodic_context_is_namespaced_and_reversible():
    token = encode_episodic_context("E", 0.8, 0.9)
    assert len(token) == 16
    fields = decode_episodic_context(token)
    assert fields.direction == 28
    assert fields.rgb == map_valence_arousal_to_rgb(0.8, 0.9)
    assert fields.extra == EPISODIC_EXTRA_TAG
    assert episodic_similarity(token, token) == 1.0


def test_memory_retrieval_ranks_matching_context_first():
    memory = EpisodicMemory()
    happy = memory.store_memory(
        "Encontro feliz no Leste.",
        cardinal_direction="E",
        valence=0.8,
        arousal=0.9,
        memory_id="happy",
        timestamp=1.0,
    )
    memory.store_memory(
        "Discussão triste no Oeste.",
        cardinal_direction="W",
        valence=-0.7,
        arousal=0.5,
        memory_id="sad",
        timestamp=2.0,
    )
    memory.store_memory(
        "Observação neutra no Norte.",
        cardinal_direction="N",
        valence=0.0,
        arousal=0.1,
        memory_id="neutral",
        timestamp=3.0,
    )
    query = encode_episodic_context("E", 0.95, 0.95)
    results = memory.retrieve_by_hve_similarity(query, limit=3)
    assert results[0].record.memory_id == happy
    assert results[0].similarity_score > results[1].similarity_score

