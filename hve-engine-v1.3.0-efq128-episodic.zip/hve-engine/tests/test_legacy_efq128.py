import pytest

from hve.core import HVEError
from hve.efq128 import HVE128Fields, MODE_HVE128, efq128_from_bytes
from hve.legacy_efq128 import (
    LegacyHVE128Fields,
    legacy_bytes_to_canonical_bytes,
    legacy_tau_to_canonical,
    pack_legacy_efq128,
    unpack_legacy_efq128,
)


def test_attached_toolkit_golden_vector_is_reproduced_exactly():
    fields = LegacyHVE128Fields(
        mode=MODE_HVE128,
        theta=12,
        micro=94,
        sigma=1,
        tau_raw=2,
        direction=2,
        rgb=0xFF0000,
        extra=12,
    )
    data = pack_legacy_efq128(fields)
    assert data.hex() == "80060bd00205fe00000000000c000000"
    assert unpack_legacy_efq128(data) == fields


def test_legacy_and_canonical_layouts_are_not_byte_compatible():
    legacy = LegacyHVE128Fields(
        mode=MODE_HVE128,
        theta=12,
        micro=94,
        sigma=1,
        tau_raw=2,
        direction=2,
        rgb=0xFF0000,
        extra=12,
    ).to_bytes()
    canonical = HVE128Fields(
        mode=MODE_HVE128,
        theta=12,
        micro=94,
        sigma=1,
        tau=2,
        direction=2,
        rgb=0xFF0000,
        extra=12,
    ).to_bytes()
    assert canonical.hex() == "80060bd00202ff00000000000c000000"
    assert legacy != canonical
    assert efq128_from_bytes(legacy, strict_profile=False).direction == 5


def test_explicit_transcode_preserves_semantic_fields():
    legacy_fields = LegacyHVE128Fields(
        mode=MODE_HVE128,
        theta=12,
        micro=94,
        sigma=1,
        tau_raw=2,
        direction=2,
        rgb=0xFF0000,
        extra=12,
    )
    canonical = efq128_from_bytes(
        legacy_bytes_to_canonical_bytes(legacy_fields.to_bytes())
    )
    assert canonical.theta == legacy_fields.theta
    assert canonical.micro == legacy_fields.micro
    assert canonical.sigma == legacy_fields.sigma
    assert canonical.tau == 2
    assert canonical.direction == legacy_fields.direction
    assert canonical.rgb == legacy_fields.rgb
    assert canonical.extra == legacy_fields.extra


def test_negative_legacy_tau_is_mapped_to_canonical_cycle():
    assert legacy_tau_to_canonical(0xFFE) == 3598
    assert legacy_tau_to_canonical(0xFFF) == 3599


def test_legacy_direction_endpoint_requires_explicit_policy():
    legacy = LegacyHVE128Fields(
        mode=MODE_HVE128,
        theta=0,
        micro=0,
        sigma=1,
        tau_raw=0,
        direction=112,
        rgb=0,
        extra=0,
    ).to_bytes()
    canonical = efq128_from_bytes(legacy_bytes_to_canonical_bytes(legacy))
    assert canonical.direction == 0
    with pytest.raises(HVEError):
        legacy_bytes_to_canonical_bytes(
            legacy,
            normalize_direction_endpoint=False,
        )

