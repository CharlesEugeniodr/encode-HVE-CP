from hve.legacy18000 import (
    LEGACY18000_CARDINALITY,
    decode_legacy18000,
    encode_legacy18000,
    migrate_from_hve32400,
    migrate_to_hve32400,
)


def test_legacy_exhaustive_roundtrip_and_injection():
    migrated = set()
    for index in range(LEGACY18000_CARDINALITY):
        state = decode_legacy18000(index)
        assert encode_legacy18000(state) == index
        current = migrate_to_hve32400(state)
        assert migrate_from_hve32400(current) == state
        migrated.add(current)
    assert len(migrated) == LEGACY18000_CARDINALITY
