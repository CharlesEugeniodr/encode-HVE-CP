import pytest
from hve.ai_mapping import DeterministicMapper, MapperRegistry, RuleBasedMapper
from hve.core import HVEError


def test_deterministic_mapper():
    result = DeterministicMapper().map("A")
    assert result.state.theta == 10
    assert result.confidence == 1.0


def test_registry():
    registry = MapperRegistry()
    mapper = DeterministicMapper()
    registry.register("canonical", mapper)
    assert registry.get("canonical") is mapper
    assert registry.list_mappers() == ["canonical"]
    with pytest.raises(HVEError):
        registry.register("canonical", mapper)


def test_rule_based_fallback():
    assert RuleBasedMapper().map("9").state.theta == 9
