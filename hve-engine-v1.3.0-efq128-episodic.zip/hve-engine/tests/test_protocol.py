import pytest
from hve.core import HVEError, HVEState
from hve.chromatic import HVEColor, encode_chi
from hve.protocol import *


def test_base15_roundtrip():
    for count in (0,1,2,7,8,9,31,257):
        indices = [(i*7919+17)%32400 for i in range(count)]
        data = pack_base15(indices)
        assert unpack_base15(data, count) == indices


def test_chi_profiles():
    state = HVEState(359,1,4,8)
    color = HVEColor.rgb(0,0,0)
    assert unpack_chi40(pack_chi40(state,color)) == (state,color)
    idx = encode_chi(state,color)
    assert unpack_chi39(pack_chi39(idx)) == idx


def test_frame_crc():
    indices = [i*100 for i in range(9)]
    payload = pack_base15(indices)
    frame = make_frame(PROFILE_BASE15, len(indices), payload, flags=0x1234)
    profile, flags, count, decoded = parse_frame(frame)
    assert (profile, flags, count, decoded) == (PROFILE_BASE15, 0x1234, len(indices), payload)
    damaged = bytearray(frame); damaged[-1] ^= 1
    with pytest.raises(HVEError):
        parse_frame(bytes(damaged))
