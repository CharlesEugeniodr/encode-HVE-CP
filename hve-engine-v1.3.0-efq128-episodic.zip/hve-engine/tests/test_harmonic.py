import numpy as np
from hve.core import HVEState
from hve.harmonic import *


def test_character_identity_and_orthogonality():
    assert character((0,0,0,0), HVEState(123,1,4,8)) == 1+0j
    assert orthogonality_check((0,0,0,0), (0,0,0,0))
    assert orthogonality_check((1,0,0,0), (2,0,0,0))


def test_dft_roundtrip_parseval_and_separability():
    rng = np.random.default_rng(1234)
    f = rng.normal(size=GROUP_SHAPE) + 1j*rng.normal(size=GROUP_SHAPE)
    f_hat = dft(f)
    assert np.allclose(idft(f_hat), f, atol=1e-10, rtol=1e-10)
    assert np.allclose(dft_separable(f), f_hat, atol=1e-10, rtol=1e-10)
    assert np.allclose(idft_separable(f_hat), f, atol=1e-10, rtol=1e-10)
    assert parseval_check(f, f_hat, atol=1e-8, rtol=1e-10)


def test_reference_small_domain():
    rng = np.random.default_rng(2)
    f = rng.normal(size=(4,2,3))
    assert np.allclose(dft_reference(f), np.fft.fftn(f), atol=1e-10)


def test_convolution_theorem():
    f = np.zeros(GROUP_SHAPE, complex)
    g = np.zeros(GROUP_SHAPE, complex)
    f[1,0,0,0] = 1
    g[2,1,0,0] = 1
    h = convolve(f,g)
    assert np.isclose(h[3,1,0,0], 1)
    assert np.count_nonzero(np.abs(h) > 1e-10) == 1


def test_laplacian_spectrum_invariants():
    values = laplacian_spectrum()
    assert values.shape == (GROUP_ORDER,)
    assert abs(values[0]) < 1e-12
    assert np.all(values >= -1e-12)
