import json

import pytest

from hve.comparative import (
    CODEC_BINARY21,
    CODEC_HVE_BASE15,
    CODEC_HVE_HYBRID,
    CODEC_HVE_LAB10,
    CODEC_UTF8,
    DECODERS,
    ENCODERS,
    REFERENCE_HEADER_SIZE,
    analyze_corpus,
    analyze_single_bit_errors,
    default_corpora,
    embed_binary,
    embed_unicode,
    pack_reference_frame,
    recover_binary,
    recover_unicode,
    run_comparison,
    unpack_reference_frame,
    verify_dominance_certificate,
    write_comparison_artifacts,
)
from hve.core import HVEError


@pytest.mark.parametrize(
    "text",
    [
        "",
        "HVE720",
        "ação",
        "Ελληνικά Кириллица العربية 中文 😀",
        "\x00\t\n",
        chr(0x10FFFF),
    ],
)
@pytest.mark.parametrize(
    "codec",
    [CODEC_UTF8, CODEC_BINARY21, CODEC_HVE_HYBRID],
)
def test_universal_text_codecs_roundtrip(text, codec):
    payload = ENCODERS[codec](text)
    assert DECODERS[codec](payload) == text
    assert unpack_reference_frame(pack_reference_frame(payload)).data == payload.data


def test_lab10_exact_width_and_reserved_detection():
    text = "HVE720ação∑"
    payload = ENCODERS[CODEC_HVE_LAB10](text)
    assert payload.bit_length == len(text) * 10
    assert DECODERS[CODEC_HVE_LAB10](payload) == text
    assert payload.mapped_count == len(text)
    with pytest.raises(HVEError):
        ENCODERS[CODEC_HVE_LAB10](" ")


def test_base15_current_canonical_profile():
    text = "HVE 720\n"
    payload = ENCODERS[CODEC_HVE_BASE15](text)
    assert payload.bit_length == len(text) * 15
    assert DECODERS[CODEC_HVE_BASE15](payload) == text
    with pytest.raises(HVEError):
        ENCODERS[CODEC_HVE_BASE15]("á")


def test_binary_and_unicode_embeddings():
    data = bytes(range(256)) * 3
    text = "HVE, português, 中文 e 😀"
    assert recover_binary(embed_binary(data)) == data
    assert recover_unicode(embed_unicode(text)) == text


def test_common_frame_crc_detects_damage():
    frame = bytearray(embed_unicode("HVE"))
    assert len(frame) > REFERENCE_HEADER_SIZE
    frame[-1] ^= 0x01
    with pytest.raises(HVEError, match="CRC"):
        unpack_reference_frame(bytes(frame))


def test_storage_analysis_is_auditable():
    result = analyze_corpus("mapped", "HVE720ação∑")
    assert result["codecs"][CODEC_HVE_LAB10]["payload_bits"] == 110
    assert result["codecs"][CODEC_HVE_HYBRID]["lossless_roundtrip"]
    assert result["codecs"][CODEC_UTF8]["payload_bytes"] > 0
    assert result["codecs"][CODEC_BINARY21]["payload_bits"] == 11 * 21


def test_error_analysis_uses_same_crc_wrapper():
    result = analyze_single_bit_errors(CODEC_HVE_HYBRID, "HVE720ação", trials=16)
    assert result.trials == 16
    assert result.common_frame_crc_detection_rate == 1.0
    assert result.detected_errors + result.silent_corruptions + result.unchanged_results == 16


def test_dominance_certificate():
    certificate = verify_dominance_certificate()
    assert certificate["passed"]
    assert certificate["base_states_verified"] == 32_400
    assert certificate["reserved_words_rejected"] == 368


def test_report_artifacts(tmp_path):
    report = run_comparison(
        {"small": "HVE720ação"},
        repetitions=1,
        target_characters=10,
        bootstrap_resamples=0,
        error_trials=4,
    )
    paths = write_comparison_artifacts(report, tmp_path)
    assert set(paths) == {"json", "csv", "markdown"}
    loaded = json.loads((tmp_path / "hve_comparison_report.json").read_text())
    assert loaded["dominance_certificate"]["passed"]
    assert default_corpora()


def test_cross_validated_token_profile():
    from hve.tokenization import cross_validated_token_analysis

    text = ("a estrutura harmônica preserva padrões e relações. " * 40).strip()
    result = cross_validated_token_analysis(
        text,
        training_fraction=0.8,
        target_vocabulary_size=128,
    )
    assert result["evaluation_characters"] > 0
    assert result["vocabulary_tokens"] <= 128
    assert result["hybrid_token_profile"]["payload_bits"] > 0
