from hve.zeta import (
    ZETA_SYMBOLS,
    decode_zeta,
    encode_zeta,
    pack_zeta,
    unpack_zeta,
    zeta_coordinate,
    zeta_symbol_index,
)


def test_zeta_exhaustive_injection():
    packed = set()
    for index in range(ZETA_SYMBOLS):
        coordinate = zeta_coordinate(index)
        assert zeta_symbol_index(coordinate) == index
        fields = encode_zeta(index)
        assert decode_zeta(fields) == index
        token = pack_zeta(index)
        assert unpack_zeta(token) == index
        packed.add(token)
    assert len(packed) == ZETA_SYMBOLS
