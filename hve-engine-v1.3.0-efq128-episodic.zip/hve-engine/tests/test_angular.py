import math
import pytest
from hve.angular import *
from hve.core import HVEError


def test_distance_and_antipodal():
    assert circular_distance(359, 0) == 1
    assert geodesic_distance(0, 180) == 180
    assert shortest_path(0, 180).direction == "antipodal"


def test_neighborhood_wraps():
    assert neighborhood(0, 3) == {357, 358, 359, 0, 1, 2, 3}


def test_arcs():
    assert circular_interval(358, 2) == (358,359,0,1,2)
    assert arc_contains(358, 2, 0)
    assert not arc_contains(358, 2, 200)


def test_circular_mean():
    assert circular_distance(round(circular_mean([359, 1])), 0) == 0
    with pytest.raises(HVEError):
        circular_mean([0, 180])


def test_resolution_maps():
    base = quantize_base(45)
    micro = project_resolution(base, Resolution.BASE, Resolution.MICRO)
    assert micro == 45_000
    assert project_resolution(micro, Resolution.MICRO, Resolution.BASE) == 45
    assert math.isclose(dequantize(micro, Resolution.MICRO), 45.0)
