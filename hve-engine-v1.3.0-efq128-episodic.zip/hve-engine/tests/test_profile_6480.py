from hve.core import BASE_LAYOUT_DOCUMENT_2025, HVEState, encode_base_with_layout
from hve.profile_6480 import (
    HVE6480_CARDINALITY,
    HVE6480_TAU_CARDINALITY,
    from_semantic,
    hve6480_tau_index,
    to_semantic,
)


def test_6480_factorization():
    assert HVE6480_CARDINALITY == 6480
    assert HVE6480_TAU_CARDINALITY == 32400


def test_semantic_profile_exhaustive():
    for theta in range(360):
        for s in range(2):
            for tau in range(5):
                for phi in range(9):
                    state = HVEState(theta, s, tau, phi)
                    semantic = to_semantic(state)
                    assert (
                        from_semantic(
                            semantic.theta,
                            semantic.sigma,
                            semantic.tau_degrees,
                            semantic.phi_degrees,
                        )
                        == state
                    )
                    assert hve6480_tau_index(state) == encode_base_with_layout(
                        state,
                        BASE_LAYOUT_DOCUMENT_2025,
                    )
