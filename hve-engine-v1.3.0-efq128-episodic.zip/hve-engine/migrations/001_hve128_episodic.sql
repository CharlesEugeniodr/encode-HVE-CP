-- HVE Engine 1.3
-- Canonical and legacy-aware HVE-128 episodic-memory migration for PostgreSQL.
--
-- Assumption: hippocampal.memories(memory_id UUID) already exists.
-- BYTEA stores the exact 16-byte token.  Similarity is computed from decoded
-- direction and RGB components; BYTEA itself is not falsely presented as a
-- vector type or as GIN-indexable nearest-neighbour data.

BEGIN;

ALTER TABLE hippocampal.memories
    ADD COLUMN IF NOT EXISTS hve_vector BYTEA,
    ADD COLUMN IF NOT EXISTS hve_profile TEXT
        NOT NULL DEFAULT 'efq128-canonical-v1';

COMMENT ON COLUMN hippocampal.memories.hve_vector IS
    'Exact 16-byte HVE-128 EFQ context token.';
COMMENT ON COLUMN hippocampal.memories.hve_profile IS
    'Versioned EFQ128 wire layout; canonical and attached-toolkit legacy are distinct.';

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conrelid = 'hippocampal.memories'::regclass
          AND conname = 'memories_hve_vector_16_bytes'
    ) THEN
        ALTER TABLE hippocampal.memories
            ADD CONSTRAINT memories_hve_vector_16_bytes
            CHECK (hve_vector IS NULL OR octet_length(hve_vector) = 16);
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conrelid = 'hippocampal.memories'::regclass
          AND conname = 'memories_hve_profile_known'
    ) THEN
        ALTER TABLE hippocampal.memories
            ADD CONSTRAINT memories_hve_profile_known
            CHECK (
                hve_profile IN (
                    'efq128-canonical-v1',
                    'efq128-attached-toolkit-legacy-v1'
                )
            );
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conrelid = 'hippocampal.memories'::regclass
          AND conname = 'memories_hve_mode_128'
    ) THEN
        ALTER TABLE hippocampal.memories
            ADD CONSTRAINT memories_hve_mode_128
            CHECK (
                hve_vector IS NULL
                OR ((get_byte(hve_vector, 0) >> 5) & 7) = 4
            );
    END IF;

    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conrelid = 'hippocampal.memories'::regclass
          AND conname = 'memories_hve_direction_domain'
    ) THEN
        ALTER TABLE hippocampal.memories
            ADD CONSTRAINT memories_hve_direction_domain
            CHECK (
                hve_vector IS NULL
                OR (
                    hve_profile = 'efq128-canonical-v1'
                    AND (get_byte(hve_vector, 5) & 127) BETWEEN 0 AND 111
                )
                OR (
                    hve_profile = 'efq128-attached-toolkit-legacy-v1'
                    AND ((get_byte(hve_vector, 5) >> 1) & 127)
                        BETWEEN 0 AND 112
                )
            );
    END IF;
END
$$;

CREATE OR REPLACE FUNCTION hippocampal.hve128_direction(
    p_vector BYTEA,
    p_profile TEXT
) RETURNS SMALLINT
LANGUAGE plpgsql
IMMUTABLE
STRICT
PARALLEL SAFE
AS $$
BEGIN
    IF octet_length(p_vector) <> 16 THEN
        RAISE EXCEPTION 'HVE-128 vector must contain exactly 16 bytes';
    END IF;

    IF p_profile = 'efq128-canonical-v1' THEN
        -- Canonical D is byte 5, bits 6..0 (global bits 86..80).
        RETURN (get_byte(p_vector, 5) & 127)::SMALLINT;
    ELSIF p_profile = 'efq128-attached-toolkit-legacy-v1' THEN
        -- Legacy D is byte 5, bits 7..1 (global bits 87..81).
        RETURN ((get_byte(p_vector, 5) >> 1) & 127)::SMALLINT;
    END IF;

    RAISE EXCEPTION 'unsupported HVE-128 profile: %', p_profile;
END;
$$;

CREATE OR REPLACE FUNCTION hippocampal.hve128_rgb(
    p_vector BYTEA,
    p_profile TEXT
) RETURNS INTEGER
LANGUAGE plpgsql
IMMUTABLE
STRICT
PARALLEL SAFE
AS $$
DECLARE
    v_byte5 INTEGER;
    v_byte6 INTEGER;
    v_byte7 INTEGER;
    v_byte8 INTEGER;
BEGIN
    IF octet_length(p_vector) <> 16 THEN
        RAISE EXCEPTION 'HVE-128 vector must contain exactly 16 bytes';
    END IF;

    v_byte5 := get_byte(p_vector, 5);
    v_byte6 := get_byte(p_vector, 6);
    v_byte7 := get_byte(p_vector, 7);
    v_byte8 := get_byte(p_vector, 8);

    IF p_profile = 'efq128-canonical-v1' THEN
        -- Canonical RGB is contiguous in bytes 6..8 (global bits 79..56).
        RETURN (v_byte6 << 16) | (v_byte7 << 8) | v_byte8;
    ELSIF p_profile = 'efq128-attached-toolkit-legacy-v1' THEN
        -- Legacy RGB high bits are 80..65, bit 64 is a gap, and low bits
        -- are 63..56.
        RETURN
            ((v_byte5 & 1) << 23)
            | (v_byte6 << 15)
            | ((v_byte7 >> 1) << 8)
            | v_byte8;
    END IF;

    RAISE EXCEPTION 'unsupported HVE-128 profile: %', p_profile;
END;
$$;

CREATE OR REPLACE FUNCTION hippocampal.hve128_direction_similarity(
    p_a SMALLINT,
    p_b SMALLINT
) RETURNS DOUBLE PRECISION
LANGUAGE sql
IMMUTABLE
STRICT
PARALLEL SAFE
AS $$
    WITH normalized AS (
        SELECT mod(p_a::INTEGER, 112) AS a, mod(p_b::INTEGER, 112) AS b
    ),
    distance AS (
        SELECT least(abs(a - b), 112 - abs(a - b))::DOUBLE PRECISION AS d
        FROM normalized
    )
    SELECT 1.0 - (d / 56.0) FROM distance;
$$;

CREATE OR REPLACE FUNCTION hippocampal.hve128_rgb_similarity(
    p_a INTEGER,
    p_b INTEGER
) RETURNS DOUBLE PRECISION
LANGUAGE sql
IMMUTABLE
STRICT
PARALLEL SAFE
AS $$
    SELECT 1.0 - (
        sqrt(
            power(((p_a >> 16) & 255) - ((p_b >> 16) & 255), 2)
            + power(((p_a >> 8) & 255) - ((p_b >> 8) & 255), 2)
            + power((p_a & 255) - (p_b & 255), 2)
        )
        / sqrt(3.0 * power(255.0, 2))
    );
$$;

ALTER TABLE hippocampal.memories
    ADD COLUMN IF NOT EXISTS hve_direction SMALLINT
        GENERATED ALWAYS AS (
            hippocampal.hve128_direction(hve_vector, hve_profile)
        ) STORED,
    ADD COLUMN IF NOT EXISTS hve_rgb INTEGER
        GENERATED ALWAYS AS (
            hippocampal.hve128_rgb(hve_vector, hve_profile)
        ) STORED;

CREATE INDEX IF NOT EXISTS memories_hve_profile_direction_idx
    ON hippocampal.memories (hve_profile, hve_direction)
    WHERE hve_vector IS NOT NULL;

CREATE OR REPLACE FUNCTION hippocampal.update_memory_hve_vector(
    p_memory_id UUID,
    p_hve_vector BYTEA,
    p_hve_profile TEXT DEFAULT 'efq128-canonical-v1'
) RETURNS BOOLEAN
LANGUAGE plpgsql
AS $$
BEGIN
    IF p_hve_vector IS NULL OR octet_length(p_hve_vector) <> 16 THEN
        RAISE EXCEPTION 'HVE-128 vector must contain exactly 16 bytes';
    END IF;
    IF p_hve_profile NOT IN (
        'efq128-canonical-v1',
        'efq128-attached-toolkit-legacy-v1'
    ) THEN
        RAISE EXCEPTION 'unsupported HVE-128 profile: %', p_hve_profile;
    END IF;

    UPDATE hippocampal.memories
    SET hve_vector = p_hve_vector,
        hve_profile = p_hve_profile
    WHERE memory_id = p_memory_id;

    RETURN FOUND;
END;
$$;

CREATE OR REPLACE FUNCTION hippocampal.retrieve_by_hve_similarity(
    p_query_hve_vector BYTEA,
    p_query_hve_profile TEXT DEFAULT 'efq128-canonical-v1',
    p_limit INTEGER DEFAULT 10,
    p_direction_weight DOUBLE PRECISION DEFAULT 0.5
) RETURNS TABLE (
    memory_id UUID,
    similarity_score DOUBLE PRECISION,
    direction_score DOUBLE PRECISION,
    rgb_score DOUBLE PRECISION
)
LANGUAGE plpgsql
STABLE
PARALLEL SAFE
AS $$
DECLARE
    v_query_direction SMALLINT;
    v_query_rgb INTEGER;
BEGIN
    IF p_limit < 1 THEN
        RAISE EXCEPTION 'limit must be positive';
    END IF;
    IF p_direction_weight < 0.0 OR p_direction_weight > 1.0 THEN
        RAISE EXCEPTION 'direction weight must be in [0, 1]';
    END IF;

    v_query_direction := hippocampal.hve128_direction(
        p_query_hve_vector,
        p_query_hve_profile
    );
    v_query_rgb := hippocampal.hve128_rgb(
        p_query_hve_vector,
        p_query_hve_profile
    );

    RETURN QUERY
    SELECT
        m.memory_id,
        (
            p_direction_weight * scores.direction_score
            + (1.0 - p_direction_weight) * scores.rgb_score
        ) AS similarity_score,
        scores.direction_score,
        scores.rgb_score
    FROM hippocampal.memories AS m
    CROSS JOIN LATERAL (
        SELECT
            hippocampal.hve128_direction_similarity(
                v_query_direction,
                m.hve_direction
            ) AS direction_score,
            hippocampal.hve128_rgb_similarity(v_query_rgb, m.hve_rgb) AS rgb_score
    ) AS scores
    WHERE m.hve_vector IS NOT NULL
    ORDER BY 2 DESC, m.memory_id
    LIMIT p_limit;
END;
$$;

COMMENT ON FUNCTION hippocampal.retrieve_by_hve_similarity IS
    'Exact HVE episodic-context ranking over decoded cyclic direction and RGB. This is a scan, not an ANN vector index.';

COMMIT;
