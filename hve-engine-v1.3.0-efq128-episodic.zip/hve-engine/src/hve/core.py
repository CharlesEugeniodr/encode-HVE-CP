"""HVE-720 BASE core: state validation, bijection, and group operations."""

from __future__ import annotations

from dataclasses import dataclass

THETA_CARD = 360
S_CARD = 2
TAU_CARD = 5
PHI_CARD = 9
BASE_CARDINALITY = THETA_CARD * S_CARD * TAU_CARD * PHI_CARD
BASE_WORD_BITS = 15
BASE_WORD_CAPACITY = 1 << BASE_WORD_BITS
BASE_RESERVED_WORDS = BASE_WORD_CAPACITY - BASE_CARDINALITY
BASE_LAYOUT_ENGINE_V1 = "theta-s-tau-phi/v1"
BASE_LAYOUT_DOCUMENT_2025 = "phi-tau-s-theta/document-2025"
BASE_LAYOUTS = frozenset({BASE_LAYOUT_ENGINE_V1, BASE_LAYOUT_DOCUMENT_2025})


class HVEError(ValueError):
    """Raised when a value violates the HVE profile."""


@dataclass(frozen=True, slots=True)
class HVEState:
    theta: int
    s: int
    tau: int
    phi: int

    def validate(self) -> None:
        validate_state(self)


def validate_state(state: HVEState) -> None:
    if not isinstance(state, HVEState):
        raise HVEError("state must be an HVEState")
    if not 0 <= state.theta < THETA_CARD:
        raise HVEError("theta must be in [0, 359]")
    if not 0 <= state.s < S_CARD:
        raise HVEError("s must be in {0, 1}")
    if not 0 <= state.tau < TAU_CARD:
        raise HVEError("tau must be in [0, 4]")
    if not 0 <= state.phi < PHI_CARD:
        raise HVEError("phi must be in [0, 8]")


def validate_index(index: int) -> None:
    if not isinstance(index, int) or isinstance(index, bool):
        raise HVEError("BASE index must be an integer")
    if not 0 <= index < BASE_CARDINALITY:
        raise HVEError("BASE index must be in [0, 32399]")


def sigma_to_s(sigma: int) -> int:
    if sigma == 1:
        return 0
    if sigma == -1:
        return 1
    raise HVEError("sigma must be +1 or -1")


def s_to_sigma(s: int) -> int:
    if s == 0:
        return 1
    if s == 1:
        return -1
    raise HVEError("s must be 0 or 1")


def encode_base_with_layout(
    state: HVEState,
    layout: str = BASE_LAYOUT_ENGINE_V1,
) -> int:
    validate_state(state)
    if layout == BASE_LAYOUT_ENGINE_V1:
        return (
            ((state.theta * S_CARD + state.s) * TAU_CARD + state.tau)
            * PHI_CARD
            + state.phi
        )
    if layout == BASE_LAYOUT_DOCUMENT_2025:
        return (
            state.phi * (TAU_CARD * S_CARD * THETA_CARD)
            + state.tau * (S_CARD * THETA_CARD)
            + state.s * THETA_CARD
            + state.theta
        )
    raise HVEError(f"unsupported BASE layout: {layout}")


def decode_base_with_layout(
    index: int,
    layout: str = BASE_LAYOUT_ENGINE_V1,
) -> HVEState:
    validate_index(index)
    if layout == BASE_LAYOUT_ENGINE_V1:
        phi = index % PHI_CARD
        q1 = index // PHI_CARD
        tau = q1 % TAU_CARD
        q2 = q1 // TAU_CARD
        s = q2 % S_CARD
        theta = q2 // S_CARD
        return HVEState(theta, s, tau, phi)
    if layout == BASE_LAYOUT_DOCUMENT_2025:
        theta = index % THETA_CARD
        q1 = index // THETA_CARD
        s = q1 % S_CARD
        q2 = q1 // S_CARD
        tau = q2 % TAU_CARD
        phi = q2 // TAU_CARD
        return HVEState(theta, s, tau, phi)
    raise HVEError(f"unsupported BASE layout: {layout}")


def encode_base(state: HVEState) -> int:
    """Encode with the Engine 1.0 layout retained for wire compatibility."""

    return encode_base_with_layout(state, BASE_LAYOUT_ENGINE_V1)


def decode_base(index: int) -> HVEState:
    """Decode with the Engine 1.0 layout retained for wire compatibility."""

    return decode_base_with_layout(index, BASE_LAYOUT_ENGINE_V1)


def transcode_base_index(
    index: int,
    source_layout: str,
    target_layout: str,
) -> int:
    """Convert an index between the two documented mixed-radix layouts."""

    state = decode_base_with_layout(index, source_layout)
    return encode_base_with_layout(state, target_layout)


def group_identity() -> HVEState:
    return HVEState(0, 0, 0, 0)


def group_add(a: HVEState, b: HVEState) -> HVEState:
    validate_state(a)
    validate_state(b)
    return HVEState(
        (a.theta + b.theta) % THETA_CARD,
        (a.s + b.s) % S_CARD,
        (a.tau + b.tau) % TAU_CARD,
        (a.phi + b.phi) % PHI_CARD,
    )


def group_inverse(a: HVEState) -> HVEState:
    validate_state(a)
    return HVEState(
        (-a.theta) % THETA_CARD,
        (-a.s) % S_CARD,
        (-a.tau) % TAU_CARD,
        (-a.phi) % PHI_CARD,
    )


def group_subtract(a: HVEState, b: HVEState) -> HVEState:
    return group_add(a, group_inverse(b))
