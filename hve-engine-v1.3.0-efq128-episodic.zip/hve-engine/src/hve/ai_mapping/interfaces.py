from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from .result import MappingResult


class AbstractMapper(ABC):
    mapper_id: str
    mapper_version: str

    @abstractmethod
    def map(self, input_data: Any, **kwargs: Any) -> MappingResult:
        raise NotImplementedError
