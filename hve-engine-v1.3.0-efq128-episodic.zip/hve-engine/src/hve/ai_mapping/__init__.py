"""Mapping interfaces. Version 1.0 includes no trained AI model."""

from .interfaces import AbstractMapper
from .result import MappingResult
from .registry import MapperRegistry
from .deterministic_mapper import DeterministicMapper
from .rule_based_mapper import RuleBasedMapper

__all__ = ["AbstractMapper", "MappingResult", "MapperRegistry", "DeterministicMapper", "RuleBasedMapper"]
