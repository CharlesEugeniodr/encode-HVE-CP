from __future__ import annotations

from .interfaces import AbstractMapper
from ..core import HVEError


class MapperRegistry:
    def __init__(self) -> None:
        self._mappers: dict[str, AbstractMapper] = {}

    def register(self, name: str, mapper: AbstractMapper, *, replace: bool = False) -> None:
        if not name:
            raise HVEError("mapper name cannot be empty")
        if name in self._mappers and not replace:
            raise HVEError(f"mapper already registered: {name}")
        self._mappers[name] = mapper

    def get(self, name: str) -> AbstractMapper:
        try:
            return self._mappers[name]
        except KeyError as exc:
            raise HVEError(f"unknown mapper: {name}") from exc

    def list_mappers(self) -> list[str]:
        return sorted(self._mappers)
