from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from ..core import HVEError, HVEState, validate_state


@dataclass(frozen=True, slots=True)
class MappingResult:
    state: HVEState
    confidence: float
    mapper_id: str
    mapper_version: str
    provenance: dict[str, Any] = field(default_factory=dict)
    alternatives: tuple["MappingResult", ...] = ()

    def __post_init__(self) -> None:
        validate_state(self.state)
        if not 0.0 <= self.confidence <= 1.0:
            raise HVEError("confidence must be in [0, 1]")
        if not self.mapper_id or not self.mapper_version:
            raise HVEError("mapper_id and mapper_version are required")
