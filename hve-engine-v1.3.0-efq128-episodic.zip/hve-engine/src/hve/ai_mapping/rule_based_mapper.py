from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

from .interfaces import AbstractMapper
from .result import MappingResult
from .deterministic_mapper import DeterministicMapper
from ..core import HVEError, HVEState


@dataclass(frozen=True, slots=True)
class MappingRule:
    name: str
    predicate: Callable[[Any], bool]
    state_factory: Callable[[Any], HVEState]
    confidence: float = 1.0


class RuleBasedMapper(AbstractMapper):
    """Explicit non-learning rule engine.

    No default semantic rules are invented beyond delegation to the canonical mapper.
    Users may add versioned rules with documented provenance.
    """

    mapper_id = "hve.rule_based"
    mapper_version = "1.0.0"

    def __init__(self, rules: list[MappingRule] | None = None, *, canonical_fallback: bool = True) -> None:
        self.rules = list(rules or [])
        self.canonical_fallback = canonical_fallback
        self._canonical = DeterministicMapper()

    def map(self, input_data: Any, **kwargs: Any) -> MappingResult:
        for rule in self.rules:
            if rule.predicate(input_data):
                return MappingResult(
                    state=rule.state_factory(input_data),
                    confidence=rule.confidence,
                    mapper_id=self.mapper_id,
                    mapper_version=self.mapper_version,
                    provenance={"rule": rule.name},
                )
        if self.canonical_fallback:
            return self._canonical.map(input_data)
        raise HVEError("no rule matched the input")
