from __future__ import annotations

from typing import Any

from .interfaces import AbstractMapper
from .result import MappingResult
from ..canonical import position_for_symbol
from ..core import HVEError


class DeterministicMapper(AbstractMapper):
    """Map a symbol assigned by canonical table version 1.0 to tau=phi=0.

    Confidence is 1.0 because the result is exact under the selected table, not a
    probabilistic prediction.
    """

    mapper_id = "hve.canonical.deterministic"
    mapper_version = "1.0.0"

    def map(self, input_data: Any, **kwargs: Any) -> MappingResult:
        if not isinstance(input_data, str) or len(input_data) != 1:
            raise HVEError("deterministic mapper expects one Unicode character")
        position = position_for_symbol(input_data)
        return MappingResult(
            state=position.state,
            confidence=1.0,
            mapper_id=self.mapper_id,
            mapper_version=self.mapper_version,
            provenance={"symbol": input_data, "category": position.category, "table": "canonical-1.0"},
        )
