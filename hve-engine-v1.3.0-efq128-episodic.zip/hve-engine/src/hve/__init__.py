"""Public API for HVE Engine."""

from .core import (
    BASE_CARDINALITY,
    BASE_LAYOUT_DOCUMENT_2025,
    BASE_LAYOUT_ENGINE_V1,
    BASE_LAYOUTS,
    BASE_RESERVED_WORDS,
    HVEError,
    HVEState,
    decode_base,
    decode_base_with_layout,
    encode_base,
    encode_base_with_layout,
    group_add,
    group_identity,
    group_inverse,
    transcode_base_index,
    validate_index,
    validate_state,
)
from .chromatic import HVEColor, decode_chi, encode_chi
from .efq128 import HVE128Fields, efq128_from_bytes, pack_efq128, unpack_efq128
from .episodic import (
    EpisodicMemory,
    decode_episodic_context,
    encode_episodic_context,
    episodic_similarity,
)
from .legacy18000 import (
    Legacy18000State,
    decode_legacy18000,
    encode_legacy18000,
    migrate_from_hve32400,
    migrate_to_hve32400,
)
from .legacy_efq128 import (
    LegacyHVE128Fields,
    legacy_bytes_to_canonical_bytes,
    pack_legacy_efq128,
    unpack_legacy_efq128,
)
from .profile_6480 import (
    HVE6480SemanticState,
    from_semantic,
    hve6480_tau_index,
    to_semantic,
)
from .zeta import decode_zeta, encode_zeta, pack_zeta, unpack_zeta

__all__ = [
    "BASE_CARDINALITY",
    "BASE_LAYOUT_DOCUMENT_2025",
    "BASE_LAYOUT_ENGINE_V1",
    "BASE_LAYOUTS",
    "BASE_RESERVED_WORDS",
    "HVEError",
    "HVEState",
    "HVEColor",
    "HVE128Fields",
    "LegacyHVE128Fields",
    "HVE6480SemanticState",
    "Legacy18000State",
    "EpisodicMemory",
    "encode_base",
    "encode_base_with_layout",
    "decode_base",
    "decode_base_with_layout",
    "transcode_base_index",
    "encode_chi",
    "decode_chi",
    "pack_efq128",
    "unpack_efq128",
    "efq128_from_bytes",
    "pack_legacy_efq128",
    "unpack_legacy_efq128",
    "legacy_bytes_to_canonical_bytes",
    "encode_episodic_context",
    "decode_episodic_context",
    "episodic_similarity",
    "to_semantic",
    "from_semantic",
    "hve6480_tau_index",
    "encode_legacy18000",
    "decode_legacy18000",
    "migrate_to_hve32400",
    "migrate_from_hve32400",
    "encode_zeta",
    "decode_zeta",
    "pack_zeta",
    "unpack_zeta",
    "group_add",
    "group_inverse",
    "group_identity",
    "validate_state",
    "validate_index",
]

__version__ = "1.3.0"
