"""HVE serialization profiles and HVE1 framing."""

from __future__ import annotations

import binascii
import struct
from collections.abc import Iterable, Sequence

from .core import BASE_CARDINALITY, HVEError, HVEState, decode_base, encode_base
from .chromatic import CHI_MAX_INDEX, HVEColor

PROFILE_BASE15 = 0x01
PROFILE_CHI40 = 0x02
FRAME_MAGIC = b"HVE1"
FRAME_VERSION_MAJOR = 1
FRAME_HEADER_SIZE = 16


def base15_packed_size(state_count: int) -> int:
    if not isinstance(state_count, int) or isinstance(state_count, bool) or state_count < 0:
        raise HVEError("state_count must be a nonnegative integer")
    return (state_count * 15 + 7) // 8


def pack_base15(indices: Sequence[int]) -> bytes:
    output = bytearray(base15_packed_size(len(indices)))
    bit_pos = 0
    for word in indices:
        if not isinstance(word, int) or isinstance(word, bool) or not 0 <= word < BASE_CARDINALITY:
            raise HVEError("invalid or reserved 15-bit word")
        for bit in range(14, -1, -1):
            byte_index = bit_pos // 8
            bit_in_byte = 7 - (bit_pos % 8)
            output[byte_index] |= ((word >> bit) & 1) << bit_in_byte
            bit_pos += 1
    return bytes(output)


def unpack_base15(data: bytes, state_count: int) -> list[int]:
    required = base15_packed_size(state_count)
    if len(data) != required:
        raise HVEError(f"payload length must be exactly {required} bytes")
    result = []
    bit_pos = 0
    for _ in range(state_count):
        word = 0
        for bit in range(14, -1, -1):
            byte_index = bit_pos // 8
            bit_in_byte = 7 - (bit_pos % 8)
            word |= ((data[byte_index] >> bit_in_byte) & 1) << bit
            bit_pos += 1
        if word >= BASE_CARDINALITY:
            raise HVEError("decoded word belongs to reserved interval")
        result.append(word)
    if required and (state_count * 15) % 8:
        padding = 8 - (state_count * 15) % 8
        if data[-1] & ((1 << padding) - 1):
            raise HVEError("nonzero padding bits")
    return result


def pack_chi40(state: HVEState, color: HVEColor) -> bytes:
    base_index = encode_base(state)
    color.validate()
    word = (base_index << 25) | (int(color.present) << 24) | (color.r << 16) | (color.g << 8) | color.b
    return word.to_bytes(5, "big")


def unpack_chi40(data: bytes) -> tuple[HVEState, HVEColor]:
    if len(data) != 5:
        raise HVEError("CHI40 state must occupy exactly five bytes")
    word = int.from_bytes(data, "big")
    base_index = (word >> 25) & 0x7FFF
    color = HVEColor(bool((word >> 24) & 1), (word >> 16) & 0xFF, (word >> 8) & 0xFF, word & 0xFF)
    color.validate()
    return decode_base(base_index), color


def pack_chi39(index: int) -> bytes:
    if not isinstance(index, int) or isinstance(index, bool) or not 0 <= index <= CHI_MAX_INDEX:
        raise HVEError("HVE-chi index outside valid interval")
    return index.to_bytes(5, "big")


def unpack_chi39(data: bytes) -> int:
    if len(data) != 5:
        raise HVEError("CHI39 representation must occupy five bytes")
    if data[0] & 0x80:
        raise HVEError("bit 39 is reserved and must be zero")
    index = int.from_bytes(data, "big")
    if index > CHI_MAX_INDEX:
        raise HVEError("HVE-chi index outside valid interval")
    return index


def frame_payload_size(profile: int, state_count: int) -> int:
    if not isinstance(state_count, int) or isinstance(state_count, bool) or not 0 <= state_count <= 0xFFFFFFFF:
        raise HVEError("state_count must fit uint32")
    if profile == PROFILE_BASE15:
        return base15_packed_size(state_count)
    if profile == PROFILE_CHI40:
        return state_count * 5
    raise HVEError("unsupported profile")


def make_frame(profile: int, count: int, payload: bytes, flags: int = 0) -> bytes:
    expected = frame_payload_size(profile, count)
    if len(payload) != expected:
        raise HVEError(f"payload must contain exactly {expected} bytes")
    if not isinstance(flags, int) or isinstance(flags, bool) or not 0 <= flags <= 0xFFFF:
        raise HVEError("flags must fit uint16")
    crc = binascii.crc32(payload) & 0xFFFFFFFF
    header = FRAME_MAGIC + bytes((FRAME_VERSION_MAJOR, profile)) + struct.pack(">HII", flags, count, crc)
    return header + payload


def parse_frame(frame: bytes) -> tuple[int, int, int, bytes]:
    if len(frame) < FRAME_HEADER_SIZE:
        raise HVEError("truncated frame")
    if frame[:4] != FRAME_MAGIC:
        raise HVEError("invalid frame magic")
    if frame[4] != FRAME_VERSION_MAJOR:
        raise HVEError("unsupported frame version")
    profile = frame[5]
    flags, count, stored_crc = struct.unpack(">HII", frame[6:16])
    expected = frame_payload_size(profile, count)
    if len(frame) != FRAME_HEADER_SIZE + expected:
        raise HVEError("frame length mismatch")
    payload = frame[FRAME_HEADER_SIZE:]
    if (binascii.crc32(payload) & 0xFFFFFFFF) != stored_crc:
        raise HVEError("CRC mismatch")
    return profile, flags, count, payload


def encode_states_base15(states: Iterable[HVEState]) -> bytes:
    return pack_base15([encode_base(state) for state in states])
