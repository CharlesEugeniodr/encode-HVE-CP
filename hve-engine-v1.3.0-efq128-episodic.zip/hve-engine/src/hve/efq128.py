"""Canonical executable HVE-128 EFQ v1 bit layout.

The source document labels bits 87..80 as a seven-bit direction field, although
that inclusive interval has eight bits. The canonical profile reserves bit 87,
places direction at 86..80, and keeps RGB contiguous at 79..56. The effective
layout of the subsequently supplied historical toolkit differs and is
implemented separately in :mod:`hve.legacy_efq128`.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import ceil, log2

from .core import HVEError

MODE_HVE2D = 0b000
MODE_HVE2D_PLUS = 0b001
MODE_HVE64 = 0b010
MODE_HVE96 = 0b011
MODE_HVE128 = 0b100

EFQ128_BYTE_WIDTH = 16
EFQ128_BIT_WIDTH = 128

FIELD_WIDTHS = {
    "mode": 3,
    "reserved_a": 5,
    "theta": 9,
    "micro": 10,
    "sigma": 1,
    "tau": 12,
    "reserved_c": 1,
    "direction": 7,
    "rgb": 24,
    "extra": 32,
    "reserved_b": 24,
}

SEMANTIC_DIRECTION_CARDINALITY = 112
SEMANTIC_PAYLOAD_CARDINALITY = (
    360 * 1000 * 2 * 3600 * SEMANTIC_DIRECTION_CARDINALITY * (1 << 24)
)
SEMANTIC_PAYLOAD_ENTROPY_BITS = log2(SEMANTIC_PAYLOAD_CARDINALITY)
SEMANTIC_PAYLOAD_MIN_WORD_BITS = ceil(SEMANTIC_PAYLOAD_ENTROPY_BITS)


def _bounded_int(name: str, value: int, lower: int, upper_exclusive: int) -> None:
    if not isinstance(value, int) or isinstance(value, bool):
        raise HVEError(f"{name} must be an integer")
    if not lower <= value < upper_exclusive:
        raise HVEError(f"{name} must be in [{lower}, {upper_exclusive - 1}]")


@dataclass(frozen=True, slots=True)
class HVE128Fields:
    mode: int
    theta: int
    micro: int
    sigma: int
    tau: int
    direction: int
    rgb: int = 0
    extra: int = 0
    reserved_a: int = 0
    reserved_c: int = 0
    reserved_b: int = 0

    def validate(self, *, strict_profile: bool = True) -> None:
        _bounded_int("mode", self.mode, 0, 1 << 3)
        _bounded_int("reserved_a", self.reserved_a, 0, 1 << 5)
        _bounded_int("theta", self.theta, 0, 360)
        _bounded_int("micro", self.micro, 0, 1000)
        _bounded_int("sigma", self.sigma, 0, 2)
        _bounded_int("tau", self.tau, 0, 3600)
        _bounded_int("reserved_c", self.reserved_c, 0, 2)
        direction_limit = SEMANTIC_DIRECTION_CARDINALITY if strict_profile else 1 << 7
        _bounded_int("direction", self.direction, 0, direction_limit)
        _bounded_int("rgb", self.rgb, 0, 1 << 24)
        _bounded_int("extra", self.extra, 0, 1 << 32)
        _bounded_int("reserved_b", self.reserved_b, 0, 1 << 24)
        if strict_profile and self.reserved_c != 0:
            raise HVEError("bit 87 is reserved and must be zero in HVE-128 EFQ v1")

    def pack(self, *, strict_profile: bool = True) -> int:
        return pack_efq128(self, strict_profile=strict_profile)

    def to_bytes(self, *, strict_profile: bool = True) -> bytes:
        return self.pack(strict_profile=strict_profile).to_bytes(
            EFQ128_BYTE_WIDTH,
            byteorder="big",
            signed=False,
        )


def pack_efq128(fields: HVE128Fields, *, strict_profile: bool = True) -> int:
    if not isinstance(fields, HVE128Fields):
        raise HVEError("fields must be HVE128Fields")
    fields.validate(strict_profile=strict_profile)
    value = 0
    value |= fields.mode << 125
    value |= fields.reserved_a << 120
    value |= fields.theta << 111
    value |= fields.micro << 101
    value |= fields.sigma << 100
    value |= fields.tau << 88
    value |= fields.reserved_c << 87
    value |= fields.direction << 80
    value |= fields.rgb << 56
    value |= fields.extra << 24
    value |= fields.reserved_b
    return value


def unpack_efq128(value: int, *, strict_profile: bool = True) -> HVE128Fields:
    _bounded_int("HVE-128 value", value, 0, 1 << EFQ128_BIT_WIDTH)
    fields = HVE128Fields(
        mode=(value >> 125) & 0x7,
        reserved_a=(value >> 120) & 0x1F,
        theta=(value >> 111) & 0x1FF,
        micro=(value >> 101) & 0x3FF,
        sigma=(value >> 100) & 0x1,
        tau=(value >> 88) & 0xFFF,
        reserved_c=(value >> 87) & 0x1,
        direction=(value >> 80) & 0x7F,
        rgb=(value >> 56) & 0xFFFFFF,
        extra=(value >> 24) & 0xFFFFFFFF,
        reserved_b=value & 0xFFFFFF,
    )
    fields.validate(strict_profile=strict_profile)
    return fields


def efq128_from_bytes(data: bytes, *, strict_profile: bool = True) -> HVE128Fields:
    if not isinstance(data, bytes) or len(data) != EFQ128_BYTE_WIDTH:
        raise HVEError("HVE-128 byte payload must contain exactly 16 bytes")
    return unpack_efq128(
        int.from_bytes(data, byteorder="big", signed=False),
        strict_profile=strict_profile,
    )


assert sum(FIELD_WIDTHS.values()) == EFQ128_BIT_WIDTH
assert SEMANTIC_PAYLOAD_MIN_WORD_BITS == 63
