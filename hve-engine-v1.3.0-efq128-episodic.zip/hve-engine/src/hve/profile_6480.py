"""Semantic profile for the HVE-6480+tau state table.

The supplied HVE-6480 table is not a second state space.  It is the
document-order enumeration of the same 32,400 BASE states:

    (360 theta * 2 sigma * 9 phi) * 5 tau = 6,480 * 5 = 32,400.
"""

from __future__ import annotations

import csv
from dataclasses import dataclass
import hashlib
from pathlib import Path

from .core import (
    BASE_CARDINALITY,
    BASE_LAYOUT_DOCUMENT_2025,
    HVEError,
    HVEState,
    encode_base_with_layout,
    s_to_sigma,
    sigma_to_s,
    validate_state,
)

HVE6480_CARDINALITY = 360 * 2 * 9
HVE6480_TAU_CARDINALITY = HVE6480_CARDINALITY * 5

# Order is normative because it is the order used by the supplied 32,400-row CSV.
TAU_DEGREES = (0, 15, -15, 30, -30)
PHI_DEGREES = (0, 15, 30, 45, 60, -15, -30, -45, -60)

TAU_LABELS = ("0°", "+15°", "-15°", "+30°", "-30°")
PHI_LABELS = ("base", "+15°", "+30°", "+45°", "+60°", "-15°", "-30°", "-45°", "-60°")

EXPECTED_CSV_HEADER = (
    "Index",
    "Theta(°)",
    "Sigma",
    "Microtorsion(τ)",
    "Plane(φ)",
)


@dataclass(frozen=True, slots=True)
class HVE6480SemanticState:
    theta: int
    sigma: int
    tau_degrees: int
    phi_degrees: int


@dataclass(frozen=True, slots=True)
class HVE6480CsvAudit:
    rows: int
    unique_states: int
    sequential_indices: bool
    semantic_indices_match: bool
    sha256: str

    @property
    def passed(self) -> bool:
        return (
            self.rows == BASE_CARDINALITY
            and self.unique_states == BASE_CARDINALITY
            and self.sequential_indices
            and self.semantic_indices_match
        )


def to_semantic(state: HVEState) -> HVE6480SemanticState:
    validate_state(state)
    return HVE6480SemanticState(
        theta=state.theta,
        sigma=s_to_sigma(state.s),
        tau_degrees=TAU_DEGREES[state.tau],
        phi_degrees=PHI_DEGREES[state.phi],
    )


def from_semantic(
    theta: int,
    sigma: int,
    tau_degrees: int,
    phi_degrees: int,
) -> HVEState:
    try:
        tau = TAU_DEGREES.index(tau_degrees)
    except ValueError as exc:
        raise HVEError(f"tau_degrees must be one of {TAU_DEGREES}") from exc
    try:
        phi = PHI_DEGREES.index(phi_degrees)
    except ValueError as exc:
        raise HVEError(f"phi_degrees must be one of {PHI_DEGREES}") from exc
    state = HVEState(theta=theta, s=sigma_to_s(sigma), tau=tau, phi=phi)
    validate_state(state)
    return state


def hve6480_tau_index(state: HVEState) -> int:
    """Return the index used by the supplied HVE-6480+tau CSV."""

    return encode_base_with_layout(state, BASE_LAYOUT_DOCUMENT_2025)


def _normalize_degree_label(value: str) -> str:
    return value.strip().replace("−", "-")


def _parse_tau_label(value: str) -> int:
    normalized = _normalize_degree_label(value)
    try:
        return TAU_LABELS.index(normalized)
    except ValueError as exc:
        raise HVEError(f"unsupported HVE-6480 tau label: {value!r}") from exc


def _parse_phi_label(value: str) -> int:
    normalized = _normalize_degree_label(value)
    try:
        return PHI_LABELS.index(normalized)
    except ValueError as exc:
        raise HVEError(f"unsupported HVE-6480 phi label: {value!r}") from exc


def validate_hve6480_csv(path: str | Path) -> HVE6480CsvAudit:
    """Validate the complete supplied enumeration against the executable core."""

    source = Path(path)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    seen_states: set[HVEState] = set()
    sequential = True
    semantic_match = True
    row_count = 0

    with source.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        if tuple(reader.fieldnames or ()) != EXPECTED_CSV_HEADER:
            raise HVEError("unexpected HVE-6480 CSV header")
        for row_count, row in enumerate(reader, start=1):
            index = int(row["Index"])
            sequential = sequential and index == row_count - 1
            state = HVEState(
                theta=int(row["Theta(°)"]),
                s=sigma_to_s(int(row["Sigma"])),
                tau=_parse_tau_label(row["Microtorsion(τ)"]),
                phi=_parse_phi_label(row["Plane(φ)"]),
            )
            validate_state(state)
            seen_states.add(state)
            semantic_match = semantic_match and hve6480_tau_index(state) == index

    audit = HVE6480CsvAudit(
        rows=row_count,
        unique_states=len(seen_states),
        sequential_indices=sequential,
        semantic_indices_match=semantic_match,
        sha256=digest,
    )
    if not audit.passed:
        raise HVEError(f"HVE-6480 CSV validation failed: {audit}")
    return audit
