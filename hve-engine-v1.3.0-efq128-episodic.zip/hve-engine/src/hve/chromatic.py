"""HVE-chi pointed chromatic extension."""

from __future__ import annotations

from dataclasses import dataclass

from .core import BASE_CARDINALITY, HVEError, HVEState, decode_base, encode_base

COLOR_RGB_CARDINALITY = 1 << 24
COLOR_POINTED_CARDINALITY = COLOR_RGB_CARDINALITY + 1
CHI_CARDINALITY = BASE_CARDINALITY * COLOR_POINTED_CARDINALITY
CHI_MAX_INDEX = CHI_CARDINALITY - 1


@dataclass(frozen=True, slots=True)
class HVEColor:
    present: bool
    r: int = 0
    g: int = 0
    b: int = 0

    def validate(self) -> None:
        for name, value in (("r", self.r), ("g", self.g), ("b", self.b)):
            if not isinstance(value, int) or isinstance(value, bool) or not 0 <= value <= 255:
                raise HVEError(f"{name} must be an integer in [0, 255]")
        if not self.present and (self.r or self.g or self.b):
            raise HVEError("NoColor requires r=g=b=0")

    @classmethod
    def no_color(cls) -> "HVEColor":
        return cls(False, 0, 0, 0)

    @classmethod
    def rgb(cls, r: int, g: int, b: int) -> "HVEColor":
        color = cls(True, r, g, b)
        color.validate()
        return color


def color_kappa(color: HVEColor) -> int:
    color.validate()
    return 0 if not color.present else 1 + (color.r << 16) + (color.g << 8) + color.b


def color_kappa_inverse(kappa: int) -> HVEColor:
    if not isinstance(kappa, int) or isinstance(kappa, bool) or not 0 <= kappa < COLOR_POINTED_CARDINALITY:
        raise HVEError("kappa outside the pointed chromatic space")
    if kappa == 0:
        return HVEColor.no_color()
    raw = kappa - 1
    return HVEColor.rgb((raw >> 16) & 0xFF, (raw >> 8) & 0xFF, raw & 0xFF)


def encode_chi(state: HVEState, color: HVEColor) -> int:
    return encode_base(state) * COLOR_POINTED_CARDINALITY + color_kappa(color)


def decode_chi(index: int) -> tuple[HVEState, HVEColor]:
    if not isinstance(index, int) or isinstance(index, bool) or not 0 <= index <= CHI_MAX_INDEX:
        raise HVEError("HVE-chi index outside valid interval")
    base_index, kappa = divmod(index, COLOR_POINTED_CARDINALITY)
    return decode_base(base_index), color_kappa_inverse(kappa)
