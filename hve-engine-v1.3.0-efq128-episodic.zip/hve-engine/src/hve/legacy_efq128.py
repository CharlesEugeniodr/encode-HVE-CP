"""Exact support for the attached historical ``hve_toolkit_128.py`` wire layout.

The historical encoder is internally reversible, but its final effective
packing differs from the bit intervals stated in its own comments:

* direction occupies global bits 87..81;
* the upper 16 RGB bits occupy 80..65;
* global bit 64 is an unused gap;
* the lower eight RGB bits occupy 63..56.

The canonical EFQ128 codec instead reserves bit 87, places direction at 86..80,
and stores RGB contiguously at 79..56.  This module keeps the historical bytes
readable and provides an explicit semantic transcode.  It does not silently
reinterpret legacy bytes as canonical bytes.
"""

from __future__ import annotations

from dataclasses import dataclass

from .core import HVEError
from .efq128 import (
    EFQ128_BYTE_WIDTH,
    HVE128Fields,
    MODE_HVE128,
    pack_efq128,
)

LEGACY_EFQ128_PROFILE = "efq128/attached-toolkit/legacy-v1"
LEGACY_DIRECTION_ENDPOINT = 112
LEGACY_TAU_MODULUS = 1 << 12
CANONICAL_TAU_MODULUS = 3_600


def _bounded_int(name: str, value: int, lower: int, upper_exclusive: int) -> None:
    if not isinstance(value, int) or isinstance(value, bool):
        raise HVEError(f"{name} must be an integer")
    if not lower <= value < upper_exclusive:
        raise HVEError(f"{name} must be in [{lower}, {upper_exclusive - 1}]")


@dataclass(frozen=True, slots=True)
class LegacyHVE128Fields:
    """Fields exposed by the historical 16-byte layout.

    ``tau_raw`` is the unsigned 12-bit wire value.  The attached character
    encoder wrote negative values with ``tau & 0xFFF``; ``tau_signed12`` exposes
    that possible signed interpretation without applying it during decoding.
    """

    mode: int
    theta: int
    micro: int
    sigma: int
    tau_raw: int
    direction: int
    rgb: int
    extra: int
    reserved_a: int = 0
    gap_64: int = 0
    reserved_b: int = 0

    @property
    def tau_signed12(self) -> int:
        if self.tau_raw >= (LEGACY_TAU_MODULUS // 2):
            return self.tau_raw - LEGACY_TAU_MODULUS
        return self.tau_raw

    def validate(self, *, strict_profile: bool = True) -> None:
        _bounded_int("mode", self.mode, 0, 1 << 3)
        _bounded_int("reserved_a", self.reserved_a, 0, 1 << 5)
        _bounded_int("theta", self.theta, 0, 1 << 9)
        _bounded_int("micro", self.micro, 0, 1 << 10)
        _bounded_int("sigma", self.sigma, 0, 2)
        _bounded_int("tau_raw", self.tau_raw, 0, LEGACY_TAU_MODULUS)
        _bounded_int("direction", self.direction, 0, 1 << 7)
        _bounded_int("rgb", self.rgb, 0, 1 << 24)
        _bounded_int("extra", self.extra, 0, 1 << 32)
        _bounded_int("gap_64", self.gap_64, 0, 2)
        _bounded_int("reserved_b", self.reserved_b, 0, 1 << 24)
        if not strict_profile:
            return
        if self.mode != MODE_HVE128:
            raise HVEError("legacy toolkit mode must be HVE-128 (4)")
        if self.theta >= 360:
            raise HVEError("legacy theta must be in [0, 359]")
        if self.micro >= 1_000:
            raise HVEError("legacy micro must be in [0, 999]")
        if self.direction > LEGACY_DIRECTION_ENDPOINT:
            raise HVEError("legacy direction must be in [0, 112]")
        if self.reserved_a or self.gap_64 or self.reserved_b:
            raise HVEError("legacy toolkit reserved and gap bits must be zero")

    def to_bytes(self, *, strict_profile: bool = True) -> bytes:
        return pack_legacy_efq128(self, strict_profile=strict_profile)


def pack_legacy_efq128(
    fields: LegacyHVE128Fields,
    *,
    strict_profile: bool = True,
) -> bytes:
    """Pack exactly as the final effective encoder in the attached toolkit."""

    if not isinstance(fields, LegacyHVE128Fields):
        raise HVEError("fields must be LegacyHVE128Fields")
    fields.validate(strict_profile=strict_profile)
    rgb_high = (fields.rgb >> 8) & 0xFFFF
    rgb_low = fields.rgb & 0xFF
    value = 0
    value |= fields.mode << 125
    value |= fields.reserved_a << 120
    value |= fields.theta << 111
    value |= fields.micro << 101
    value |= fields.sigma << 100
    value |= fields.tau_raw << 88
    value |= fields.direction << 81
    value |= rgb_high << 65
    value |= fields.gap_64 << 64
    value |= rgb_low << 56
    value |= fields.extra << 24
    value |= fields.reserved_b
    return value.to_bytes(EFQ128_BYTE_WIDTH, byteorder="big", signed=False)


def unpack_legacy_efq128(
    data: bytes,
    *,
    strict_profile: bool = True,
) -> LegacyHVE128Fields:
    """Decode the historical byte layout without applying semantic repairs."""

    if not isinstance(data, bytes) or len(data) != EFQ128_BYTE_WIDTH:
        raise HVEError("legacy HVE-128 payload must contain exactly 16 bytes")
    value = int.from_bytes(data, byteorder="big", signed=False)
    rgb_high = (value >> 65) & 0xFFFF
    rgb_low = (value >> 56) & 0xFF
    fields = LegacyHVE128Fields(
        mode=(value >> 125) & 0x7,
        reserved_a=(value >> 120) & 0x1F,
        theta=(value >> 111) & 0x1FF,
        micro=(value >> 101) & 0x3FF,
        sigma=(value >> 100) & 0x1,
        tau_raw=(value >> 88) & 0xFFF,
        direction=(value >> 81) & 0x7F,
        rgb=(rgb_high << 8) | rgb_low,
        extra=(value >> 24) & 0xFFFFFFFF,
        gap_64=(value >> 64) & 0x1,
        reserved_b=value & 0xFFFFFF,
    )
    fields.validate(strict_profile=strict_profile)
    return fields


def legacy_tau_to_canonical(tau_raw: int) -> int:
    """Map legacy tau onto the canonical 3600-cycle.

    Values already valid in the documented ``0..3599`` domain are preserved.
    Only the otherwise invalid upper 12-bit region is interpreted through the
    historical signed-mask behaviour. This avoids corrupting valid legacy tau
    values in ``2048..3599`` while still repairing ``-2 -> 4094`` and
    ``-1 -> 4095`` from the character heuristic.
    """

    _bounded_int("tau_raw", tau_raw, 0, LEGACY_TAU_MODULUS)
    if tau_raw < CANONICAL_TAU_MODULUS:
        return tau_raw
    signed = tau_raw - LEGACY_TAU_MODULUS if tau_raw >= 2048 else tau_raw
    return signed % CANONICAL_TAU_MODULUS


def legacy_to_canonical_fields(
    fields: LegacyHVE128Fields,
    *,
    normalize_direction_endpoint: bool = True,
) -> HVE128Fields:
    """Preserve field semantics while changing from legacy to canonical layout.

    The historical encoder admitted direction 112 even though a 112-position
    cycle has canonical coordinates 0..111.  By default the duplicate endpoint
    is normalized to 0.  Set ``normalize_direction_endpoint=False`` to reject it
    instead of performing that normalization.
    """

    fields.validate(strict_profile=True)
    direction = fields.direction
    if direction == LEGACY_DIRECTION_ENDPOINT:
        if not normalize_direction_endpoint:
            raise HVEError("legacy direction 112 requires endpoint normalization")
        direction = 0
    return HVE128Fields(
        mode=fields.mode,
        theta=fields.theta,
        micro=fields.micro,
        sigma=fields.sigma,
        tau=legacy_tau_to_canonical(fields.tau_raw),
        direction=direction,
        rgb=fields.rgb,
        extra=fields.extra,
        reserved_a=fields.reserved_a,
        reserved_c=0,
        reserved_b=fields.reserved_b,
    )


def legacy_bytes_to_canonical_bytes(
    data: bytes,
    *,
    normalize_direction_endpoint: bool = True,
) -> bytes:
    """Transcode a historical token into canonical EFQ128 bytes."""

    fields = legacy_to_canonical_fields(
        unpack_legacy_efq128(data),
        normalize_direction_endpoint=normalize_direction_endpoint,
    )
    return pack_efq128(fields).to_bytes(EFQ128_BYTE_WIDTH, "big")
