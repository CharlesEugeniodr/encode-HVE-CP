"""Angular State Engine: discrete circular geometry on C_360."""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
import math
from collections.abc import Iterable

from .core import HVEError, THETA_CARD


class Resolution(IntEnum):
    BASE = 1
    MICRO = 1_000
    NANO = 1_080_000


@dataclass(frozen=True, slots=True)
class ShortestPath:
    start: int
    end: int
    distance: int
    clockwise: int
    counterclockwise: int
    direction: str
    arc: tuple[int, ...]


def normalize_theta(theta: int | float) -> int:
    if not isinstance(theta, (int, float)) or isinstance(theta, bool) or not math.isfinite(theta):
        raise HVEError("theta must be a finite number")
    if float(theta).is_integer():
        return int(theta) % THETA_CARD
    raise HVEError("BASE theta must be an integer number of degrees")


def rotate(theta: int, delta: int) -> int:
    return (normalize_theta(theta) + int(delta)) % THETA_CARD


def circular_distance(theta1: int, theta2: int) -> int:
    a, b = normalize_theta(theta1), normalize_theta(theta2)
    diff = abs(a - b)
    return min(diff, THETA_CARD - diff)


def geodesic_distance(theta1: int, theta2: int) -> int:
    """Shortest-path distance on cycle graph C_360; not terrestrial geodesy."""
    return circular_distance(theta1, theta2)


def normalized_distance(theta1: int, theta2: int) -> float:
    return circular_distance(theta1, theta2) / (THETA_CARD / 2)


def circular_interval(start: int, end: int) -> tuple[int, ...]:
    """Clockwise arc from start to end, inclusive; positive angular increment is clockwise."""
    s, e = normalize_theta(start), normalize_theta(end)
    steps = (e - s) % THETA_CARD
    return tuple((s + i) % THETA_CARD for i in range(steps + 1))


def arc_contains(start: int, end: int, theta: int) -> bool:
    s, e, t = normalize_theta(start), normalize_theta(end), normalize_theta(theta)
    return (t - s) % THETA_CARD <= (e - s) % THETA_CARD


def shortest_path(theta1: int, theta2: int) -> ShortestPath:
    a, b = normalize_theta(theta1), normalize_theta(theta2)
    cw = (b - a) % THETA_CARD
    ccw = (a - b) % THETA_CARD
    if cw < ccw:
        direction = "cw"
        arc = tuple((a + i) % THETA_CARD for i in range(cw + 1))
        distance = cw
    elif ccw < cw:
        direction = "ccw"
        arc = tuple((a - i) % THETA_CARD for i in range(ccw + 1))
        distance = ccw
    else:
        direction = "antipodal" if cw else "stationary"
        # At 180 degrees both arcs are minimal; the stored arc is the deterministic CW representative.
        arc = tuple((a + i) % THETA_CARD for i in range(cw + 1))
        distance = cw
    return ShortestPath(a, b, distance, cw, ccw, direction, arc)


def neighborhood(theta: int, radius: int = 1, *, include_center: bool = True) -> set[int]:
    center = normalize_theta(theta)
    if not isinstance(radius, int) or isinstance(radius, bool) or radius < 0:
        raise HVEError("radius must be a nonnegative integer")
    values = {(center + d) % THETA_CARD for d in range(-radius, radius + 1)}
    if not include_center:
        values.discard(center)
    return values


def circular_mean(thetas: Iterable[int | float]) -> float:
    values = list(thetas)
    if not values:
        raise HVEError("at least one theta is required")
    angles = [math.radians(float(t) % THETA_CARD) for t in values]
    x = sum(math.cos(a) for a in angles) / len(angles)
    y = sum(math.sin(a) for a in angles) / len(angles)
    if math.hypot(x, y) < 1e-15:
        raise HVEError("circular mean is undefined for a balanced antipodal distribution")
    return math.degrees(math.atan2(y, x)) % THETA_CARD


def circular_center(thetas: Iterable[int | float]) -> float:
    """Resultant-vector center; identical to circular mean in profile 1.0."""
    return circular_mean(thetas)


def sector_group(thetas: Iterable[int | float], n_sectors: int) -> dict[int, list[float]]:
    if not isinstance(n_sectors, int) or isinstance(n_sectors, bool) or not 1 <= n_sectors <= THETA_CARD:
        raise HVEError("n_sectors must be an integer in [1, 360]")
    groups = {i: [] for i in range(n_sectors)}
    width = THETA_CARD / n_sectors
    for theta in thetas:
        value = float(theta) % THETA_CARD
        sector = min(int(value / width), n_sectors - 1)
        groups[sector].append(value)
    return groups


def quantize(angle_degrees: float, factor: int | Resolution = Resolution.BASE) -> int:
    """Map an angle in degrees to Z_(360*factor), using nearest-grid quantization."""
    if not isinstance(angle_degrees, (int, float)) or not math.isfinite(float(angle_degrees)):
        raise HVEError("angle_degrees must be finite")
    f = int(factor)
    if f <= 0:
        raise HVEError("factor must be positive")
    return int(round((float(angle_degrees) % THETA_CARD) * f)) % (THETA_CARD * f)


def dequantize(value: int, factor: int | Resolution = Resolution.BASE) -> float:
    f = int(factor)
    if f <= 0 or not isinstance(value, int) or isinstance(value, bool):
        raise HVEError("value must be integer and factor positive")
    if not 0 <= value < THETA_CARD * f:
        raise HVEError("value outside resolution domain")
    return value / f


def quantize_base(angle_degrees: float) -> int:
    return quantize(angle_degrees, Resolution.BASE)


def quantize_micro(angle_degrees: float, micro_factor: int = Resolution.MICRO) -> int:
    return quantize(angle_degrees, micro_factor)


def quantize_nano(angle_degrees: float, nano_factor: int = Resolution.NANO) -> int:
    return quantize(angle_degrees, nano_factor)


def project_resolution(value: int, from_factor: int | Resolution, to_factor: int | Resolution) -> int:
    """Project an angular coordinate between G_m levels.

    Refinement uses exact scaling when `from_factor` divides `to_factor`.
    Coarsening follows the manuscript's floor quantization.
    """
    f_from, f_to = int(from_factor), int(to_factor)
    if f_from <= 0 or f_to <= 0 or not isinstance(value, int) or isinstance(value, bool):
        raise HVEError("invalid resolution projection arguments")
    if not 0 <= value < THETA_CARD * f_from:
        raise HVEError("value outside source resolution domain")
    if f_to >= f_from:
        if f_to % f_from:
            raise HVEError("exact refinement requires source factor to divide target factor")
        return (value * (f_to // f_from)) % (THETA_CARD * f_to)
    return math.floor((f_to / f_from) * value) % (THETA_CARD * f_to)
