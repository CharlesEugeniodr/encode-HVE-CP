"""Reproducible HVE × UTF-8 × fixed-binary comparison engine.

The module deliberately separates three questions that are often conflated:

1. storage efficiency for a declared corpus;
2. operational performance of the reference Python codecs;
3. structural capabilities supplied natively by each representation.

No scalar "winner score" is produced.  Size, speed, error behaviour, coverage,
and native structure remain independently auditable measurements.
"""

from __future__ import annotations

from collections.abc import Callable, Iterable, Mapping, Sequence
from dataclasses import asdict, dataclass
import binascii
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import platform
import random
import statistics
import struct
import time
from typing import Any
import zlib

import numpy as np

from .angular import circular_distance
from .canonical import canonical_positions
from .core import (
    BASE_CARDINALITY,
    BASE_LAYOUT_DOCUMENT_2025,
    BASE_LAYOUT_ENGINE_V1,
    BASE_RESERVED_WORDS,
    HVEError,
    decode_base,
    decode_base_with_layout,
    encode_base,
    encode_base_with_layout,
)
from .protocol import pack_base15, unpack_base15
from .harmonic import GROUP_ORDER, GROUP_SHAPE, dft, idft, parseval_check
from .tokenization import cross_validated_token_analysis

CODEC_UTF8 = "utf8"
CODEC_BINARY21 = "binary21"
CODEC_HVE_LAB10 = "hve_lab720_v0"
CODEC_HVE_BASE15 = "hve_base15"
CODEC_HVE_HYBRID = "hve_hybrid"
CODEC_HVE_RAW = "hve_raw"

CODEC_IDS = {
    CODEC_UTF8: 1,
    CODEC_BINARY21: 2,
    CODEC_HVE_LAB10: 3,
    CODEC_HVE_BASE15: 4,
    CODEC_HVE_HYBRID: 5,
    CODEC_HVE_RAW: 6,
}
ID_CODECS = {value: key for key, value in CODEC_IDS.items()}

REFERENCE_MAGIC = b"HVC1"
REFERENCE_VERSION = 1
REFERENCE_HEADER = struct.Struct(">4sBBHIII")
REFERENCE_HEADER_SIZE = REFERENCE_HEADER.size


@dataclass(frozen=True, slots=True)
class EncodedPayload:
    """A codec payload plus the metadata needed for exact reconstruction."""

    codec: str
    data: bytes
    item_count: int
    bit_length: int
    mapped_count: int = 0
    fallback_count: int = 0

    @property
    def payload_bytes(self) -> int:
        return len(self.data)


@dataclass(frozen=True, slots=True)
class TimingResult:
    operation: str
    repetitions: int
    iterations_per_repetition: int
    median_seconds: float
    ci95_low_seconds: float
    ci95_high_seconds: float
    min_seconds: float
    max_seconds: float
    characters_per_second: float
    input_mib_per_second: float
    samples_seconds: tuple[float, ...]


@dataclass(frozen=True, slots=True)
class ErrorResult:
    codec: str
    trials: int
    detected_errors: int
    silent_corruptions: int
    unchanged_results: int
    detected_error_rate: float
    silent_corruption_rate: float
    mean_changed_characters_when_silent: float
    common_frame_crc_detection_rate: float


class _BitWriter:
    def __init__(self) -> None:
        self._data = bytearray()
        self._current = 0
        self._used = 0
        self.bit_length = 0

    def write(self, value: int, width: int) -> None:
        if width < 0 or value < 0 or value >= (1 << width):
            raise HVEError("value does not fit requested bit width")
        for shift in range(width - 1, -1, -1):
            self._current = (self._current << 1) | ((value >> shift) & 1)
            self._used += 1
            self.bit_length += 1
            if self._used == 8:
                self._data.append(self._current)
                self._current = 0
                self._used = 0

    def finish(self) -> bytes:
        if self._used:
            self._data.append(self._current << (8 - self._used))
        return bytes(self._data)


class _BitReader:
    def __init__(self, data: bytes, bit_length: int) -> None:
        if bit_length < 0 or bit_length > len(data) * 8:
            raise HVEError("invalid bit length")
        self._data = data
        self._bit_length = bit_length
        self._position = 0

    @property
    def remaining(self) -> int:
        return self._bit_length - self._position

    def read(self, width: int) -> int:
        if width < 0 or self._position + width > self._bit_length:
            raise HVEError("truncated bitstream")
        value = 0
        for _ in range(width):
            byte_index = self._position // 8
            bit_index = 7 - (self._position % 8)
            value = (value << 1) | ((self._data[byte_index] >> bit_index) & 1)
            self._position += 1
        return value


def _validate_padding(data: bytes, bit_length: int) -> None:
    if bit_length < 0 or bit_length > len(data) * 8:
        raise HVEError("invalid bit length")
    required = (bit_length + 7) // 8
    if len(data) != required:
        raise HVEError("payload length and bit length disagree")
    padding = required * 8 - bit_length
    if padding and data and data[-1] & ((1 << padding) - 1):
        raise HVEError("nonzero padding bits")


def _validate_scalar(value: int) -> None:
    if not 0 <= value <= 0x10FFFF or 0xD800 <= value <= 0xDFFF:
        raise HVEError(f"U+{value:04X} is not a Unicode scalar value")


def _validate_text(text: str) -> None:
    if not isinstance(text, str):
        raise HVEError("text must be str")
    for char in text:
        _validate_scalar(ord(char))


def _canonical_maps() -> tuple[dict[str, int], dict[int, str]]:
    symbol_to_index: dict[str, int] = {}
    index_to_symbol: dict[int, str] = {}
    for position in canonical_positions():
        symbol = position.symbol
        if symbol is None:
            continue
        if len(symbol) != 1:
            raise HVEError("comparative codec requires scalar canonical assignments")
        index = encode_base(position.state)
        if symbol in symbol_to_index or index in index_to_symbol:
            raise HVEError("canonical table contains a duplicate assignment")
        symbol_to_index[symbol] = index
        index_to_symbol[index] = symbol
    return symbol_to_index, index_to_symbol


def _lab720_v0_maps() -> tuple[dict[str, int], dict[int, str]]:
    """Return the scalar assignments transcribed from ``HVE.docx``.

    The source table declares 119 T+ scalars and 50 T- scalars.  Placeholder
    names such as ``EXT_RESERVE_119`` are intentionally not treated as text
    symbols.  The document describes indices 0..719 but writes the T- formula
    with an off-by-one endpoint; this executable profile resolves it as
    ``360 + (degree_abs - 1)``.
    """

    plus: dict[int, str] = {}
    plus.update({theta: str(theta) for theta in range(10)})
    plus.update({theta: chr(ord("A") + theta - 10) for theta in range(10, 36)})
    plus.update({theta: chr(ord("a") + theta - 36) for theta in range(36, 62)})
    punctuation = "!\"#$%&'()*+,-./:;<=>?@[\\]^_{|}~"
    plus.update({theta: char for theta, char in enumerate(punctuation, start=62)})
    portuguese = "áàâãéêíóôõúüçÁÀÂÃÉÊÍÓÔÕÚÜÇ"
    plus.update({theta: char for theta, char in enumerate(portuguese, start=93)})

    minus_by_degree: dict[int, str] = {}
    logic_math = (
        "¬∧∨⊻→↔∀∃∈∉⊂⊆⊄⊇∪∩"
        "±×÷≈≠≤≥≡≜∑∏√∫∇"
    )
    minus_by_degree.update(
        {degree: char for degree, char in enumerate(logic_math, start=1)}
    )
    diacritics = (
        "\u0301\u0300\u0302\u0303\u0308\u030c\u0304\u0323\u0327\u0306"
        "\u0307\u030a\u030b\u030f\u0315\u031c\u0331\u0332\u0342\u0345"
    )
    minus_by_degree.update(
        {degree: char for degree, char in enumerate(diacritics, start=181)}
    )

    index_to_symbol = dict(plus)
    index_to_symbol.update(
        {360 + degree - 1: char for degree, char in minus_by_degree.items()}
    )
    if len(index_to_symbol) != 169 or len(set(index_to_symbol.values())) != 169:
        raise AssertionError("LAB-720 v0 scalar table transcription is inconsistent")
    symbol_to_index = {symbol: index for index, symbol in index_to_symbol.items()}
    return symbol_to_index, index_to_symbol


def encode_utf8(text: str) -> EncodedPayload:
    _validate_text(text)
    data = text.encode("utf-8", errors="strict")
    return EncodedPayload(CODEC_UTF8, data, len(text), len(data) * 8)


def decode_utf8(payload: EncodedPayload) -> str:
    if payload.codec != CODEC_UTF8:
        raise HVEError("payload is not UTF-8")
    text = payload.data.decode("utf-8", errors="strict")
    if len(text) != payload.item_count:
        raise HVEError("UTF-8 item count mismatch")
    return text


def encode_binary21(text: str) -> EncodedPayload:
    """Pack every Unicode scalar as a fixed-width 21-bit binary integer."""

    _validate_text(text)
    writer = _BitWriter()
    for char in text:
        writer.write(ord(char), 21)
    data = writer.finish()
    return EncodedPayload(CODEC_BINARY21, data, len(text), writer.bit_length)


def decode_binary21(payload: EncodedPayload) -> str:
    if payload.codec != CODEC_BINARY21:
        raise HVEError("payload is not binary21")
    expected_bits = payload.item_count * 21
    if payload.bit_length != expected_bits:
        raise HVEError("binary21 bit length mismatch")
    _validate_padding(payload.data, payload.bit_length)
    reader = _BitReader(payload.data, payload.bit_length)
    chars: list[str] = []
    for _ in range(payload.item_count):
        scalar = reader.read(21)
        _validate_scalar(scalar)
        chars.append(chr(scalar))
    return "".join(chars)


def encode_hve_lab10(text: str) -> EncodedPayload:
    """Encode text assigned by the historical LAB-720 v0 table in 10 bits."""

    _validate_text(text)
    symbol_to_index, _ = _lab720_v0_maps()
    writer = _BitWriter()
    for char in text:
        try:
            writer.write(symbol_to_index[char], 10)
        except KeyError as exc:
            raise HVEError(
                f"U+{ord(char):04X} is not assigned in LAB-720 table v0"
            ) from exc
    data = writer.finish()
    return EncodedPayload(
        CODEC_HVE_LAB10,
        data,
        len(text),
        writer.bit_length,
        mapped_count=len(text),
    )


def decode_hve_lab10(payload: EncodedPayload) -> str:
    if payload.codec != CODEC_HVE_LAB10:
        raise HVEError("payload is not HVE LAB10")
    if payload.bit_length != payload.item_count * 10:
        raise HVEError("HVE LAB10 bit length mismatch")
    _validate_padding(payload.data, payload.bit_length)
    _, index_to_symbol = _lab720_v0_maps()
    reader = _BitReader(payload.data, payload.bit_length)
    chars: list[str] = []
    for _ in range(payload.item_count):
        index = reader.read(10)
        if index >= 720:
            raise HVEError("LAB10 token belongs to the 304-word reserved interval")
        try:
            chars.append(index_to_symbol[index])
        except KeyError as exc:
            raise HVEError("LAB10 token references an unassigned position") from exc
    return "".join(chars)


def encode_hve_base15(text: str) -> EncodedPayload:
    """Encode fully mapped text as canonical HVE states with tau=phi=0."""

    _validate_text(text)
    symbol_to_index, _ = _canonical_maps()
    indices: list[int] = []
    for char in text:
        try:
            indices.append(symbol_to_index[char])
        except KeyError as exc:
            raise HVEError(
                f"U+{ord(char):04X} is not assigned in the canonical HVE table"
            ) from exc
    data = pack_base15(indices)
    return EncodedPayload(
        CODEC_HVE_BASE15,
        data,
        len(text),
        len(text) * 15,
        mapped_count=len(text),
    )


def decode_hve_base15(payload: EncodedPayload) -> str:
    if payload.codec != CODEC_HVE_BASE15:
        raise HVEError("payload is not HVE BASE15")
    if payload.bit_length != payload.item_count * 15:
        raise HVEError("HVE BASE15 bit length mismatch")
    _, index_to_symbol = _canonical_maps()
    chars: list[str] = []
    for index in unpack_base15(payload.data, payload.item_count):
        try:
            chars.append(index_to_symbol[index])
        except KeyError as exc:
            raise HVEError("BASE state has no canonical text assignment") from exc
    return "".join(chars)


def encode_hve_hybrid(text: str) -> EncodedPayload:
    """Encode text with native HVE states and a lossless Unicode fallback.

    Token layout:

    - ``0 || LAB10`` for a versioned HVE-720 symbol (11 bits);
    - ``1 || Unicode scalar`` for fallback (22 bits).

    This profile gives HVE complete Unicode-scalar coverage without pretending
    that fallback symbols possess canonical HVE geometry.
    """

    _validate_text(text)
    symbol_to_index, _ = _lab720_v0_maps()
    writer = _BitWriter()
    mapped = 0
    fallback = 0
    for char in text:
        index = symbol_to_index.get(char)
        if index is not None:
            writer.write(0, 1)
            writer.write(index, 10)
            mapped += 1
        else:
            writer.write(1, 1)
            writer.write(ord(char), 21)
            fallback += 1
    data = writer.finish()
    return EncodedPayload(
        CODEC_HVE_HYBRID,
        data,
        len(text),
        writer.bit_length,
        mapped_count=mapped,
        fallback_count=fallback,
    )


def decode_hve_hybrid(payload: EncodedPayload) -> str:
    if payload.codec != CODEC_HVE_HYBRID:
        raise HVEError("payload is not HVE hybrid")
    _validate_padding(payload.data, payload.bit_length)
    _, index_to_symbol = _lab720_v0_maps()
    reader = _BitReader(payload.data, payload.bit_length)
    chars: list[str] = []
    mapped = 0
    fallback = 0
    for _ in range(payload.item_count):
        tag = reader.read(1)
        if tag == 0:
            index = reader.read(10)
            if index >= 720:
                raise HVEError("hybrid token contains a reserved LAB10 word")
            try:
                chars.append(index_to_symbol[index])
            except KeyError as exc:
                raise HVEError("hybrid token references an unassigned LAB10 position") from exc
            mapped += 1
        else:
            scalar = reader.read(21)
            _validate_scalar(scalar)
            chars.append(chr(scalar))
            fallback += 1
    if reader.remaining:
        raise HVEError("hybrid payload contains trailing bits")
    if payload.mapped_count and mapped != payload.mapped_count:
        raise HVEError("hybrid mapped-count mismatch")
    if payload.fallback_count and fallback != payload.fallback_count:
        raise HVEError("hybrid fallback-count mismatch")
    return "".join(chars)


ENCODERS: dict[str, Callable[[str], EncodedPayload]] = {
    CODEC_UTF8: encode_utf8,
    CODEC_BINARY21: encode_binary21,
    CODEC_HVE_LAB10: encode_hve_lab10,
    CODEC_HVE_BASE15: encode_hve_base15,
    CODEC_HVE_HYBRID: encode_hve_hybrid,
}

DECODERS: dict[str, Callable[[EncodedPayload], str]] = {
    CODEC_UTF8: decode_utf8,
    CODEC_BINARY21: decode_binary21,
    CODEC_HVE_LAB10: decode_hve_lab10,
    CODEC_HVE_BASE15: decode_hve_base15,
    CODEC_HVE_HYBRID: decode_hve_hybrid,
}


def pack_reference_frame(payload: EncodedPayload) -> bytes:
    """Apply identical framing and CRC-32 overhead to every compared codec."""

    try:
        codec_id = CODEC_IDS[payload.codec]
    except KeyError as exc:
        raise HVEError("unsupported codec") from exc
    if not 0 <= payload.item_count <= 0xFFFFFFFF:
        raise HVEError("item count must fit uint32")
    if not 0 <= payload.bit_length <= 0xFFFFFFFF:
        raise HVEError("bit length must fit uint32")
    _validate_padding(payload.data, payload.bit_length)
    crc = binascii.crc32(payload.data) & 0xFFFFFFFF
    header = REFERENCE_HEADER.pack(
        REFERENCE_MAGIC,
        REFERENCE_VERSION,
        codec_id,
        0,
        payload.item_count,
        payload.bit_length,
        crc,
    )
    return header + payload.data


def unpack_reference_frame(frame: bytes) -> EncodedPayload:
    if len(frame) < REFERENCE_HEADER_SIZE:
        raise HVEError("truncated comparison frame")
    magic, version, codec_id, flags, item_count, bit_length, stored_crc = (
        REFERENCE_HEADER.unpack(frame[:REFERENCE_HEADER_SIZE])
    )
    if magic != REFERENCE_MAGIC:
        raise HVEError("invalid comparison-frame magic")
    if version != REFERENCE_VERSION:
        raise HVEError("unsupported comparison-frame version")
    if flags != 0:
        raise HVEError("unsupported comparison-frame flags")
    try:
        codec = ID_CODECS[codec_id]
    except KeyError as exc:
        raise HVEError("unknown comparison-frame codec") from exc
    data = frame[REFERENCE_HEADER_SIZE:]
    _validate_padding(data, bit_length)
    if (binascii.crc32(data) & 0xFFFFFFFF) != stored_crc:
        raise HVEError("comparison-frame CRC mismatch")
    return EncodedPayload(codec, data, item_count, bit_length)


def embed_binary(data: bytes) -> bytes:
    """Inject arbitrary bytes into the HVE universal container without loss."""

    if not isinstance(data, bytes):
        raise HVEError("binary input must be bytes")
    payload = EncodedPayload(CODEC_HVE_RAW, data, len(data), len(data) * 8)
    return pack_reference_frame(payload)


def recover_binary(frame: bytes) -> bytes:
    payload = unpack_reference_frame(frame)
    if payload.codec != CODEC_HVE_RAW:
        raise HVEError("frame is not an HVE RAW embedding")
    if payload.item_count != len(payload.data) or payload.bit_length != len(payload.data) * 8:
        raise HVEError("invalid HVE RAW metadata")
    return payload.data


def embed_unicode(text: str) -> bytes:
    return pack_reference_frame(encode_hve_hybrid(text))


def recover_unicode(frame: bytes) -> str:
    payload = unpack_reference_frame(frame)
    return decode_hve_hybrid(payload)


def _payload_metadata(payload: EncodedPayload, character_count: int) -> dict[str, Any]:
    framed = pack_reference_frame(payload)
    denominator = max(character_count, 1)
    return {
        "applicable": True,
        "lossless_roundtrip": True,
        "payload_bits": payload.bit_length,
        "payload_bytes": payload.payload_bytes,
        "framed_bytes": len(framed),
        "framing_overhead_bytes": len(framed) - payload.payload_bytes,
        "bits_per_character": payload.bit_length / denominator,
        "stored_bytes_per_character": payload.payload_bytes / denominator,
        "mapped_characters": payload.mapped_count,
        "fallback_characters": payload.fallback_count,
        "canonical_coverage_rate": (
            payload.mapped_count / denominator
            if payload.codec in {CODEC_HVE_LAB10, CODEC_HVE_BASE15, CODEC_HVE_HYBRID}
            else None
        ),
        "zlib9_payload_bytes": len(zlib.compress(payload.data, level=9)),
        "sha256": hashlib.sha256(payload.data).hexdigest(),
    }


def analyze_corpus(name: str, text: str) -> dict[str, Any]:
    """Measure exact codec sizes and verify lossless reconstruction."""

    _validate_text(text)
    if not name:
        raise HVEError("corpus name must not be empty")
    metrics: dict[str, Any] = {}
    payloads: dict[str, EncodedPayload] = {}
    for codec in (CODEC_UTF8, CODEC_BINARY21, CODEC_HVE_HYBRID):
        payload = ENCODERS[codec](text)
        recovered = DECODERS[codec](payload)
        if recovered != text:
            raise AssertionError(f"{codec} round-trip failure")
        payloads[codec] = payload
        metrics[codec] = _payload_metadata(payload, len(text))
    for codec in (CODEC_HVE_LAB10, CODEC_HVE_BASE15):
        try:
            mapped_payload = ENCODERS[codec](text)
        except HVEError as exc:
            metrics[codec] = {
                "applicable": False,
                "lossless_roundtrip": False,
                "reason": str(exc),
            }
        else:
            if DECODERS[codec](mapped_payload) != text:
                raise AssertionError(f"{codec} round-trip failure")
            payloads[codec] = mapped_payload
            metrics[codec] = _payload_metadata(mapped_payload, len(text))

    utf8_bytes = metrics[CODEC_UTF8]["payload_bytes"]
    for codec, values in metrics.items():
        if not values["applicable"]:
            continue
        codec_bytes = values["payload_bytes"]
        values["size_change_vs_utf8_percent"] = (
            0.0 if utf8_bytes == 0 else ((codec_bytes - utf8_bytes) / utf8_bytes) * 100.0
        )
    binary_bytes = metrics[CODEC_BINARY21]["payload_bytes"]
    hybrid_bytes = metrics[CODEC_HVE_HYBRID]["payload_bytes"]
    winner = min(
        (
            (values["payload_bytes"], codec)
            for codec, values in metrics.items()
            if values["applicable"]
        ),
        default=(0, "none"),
    )[1]
    return {
        "name": name,
        "characters": len(text),
        "unique_scalars": len(set(text)),
        "input_utf8_bytes": len(text.encode("utf-8")),
        "codecs": metrics,
        "payload_size_winner": winner,
        "hve_hybrid_vs_binary21_percent": (
            0.0 if binary_bytes == 0 else ((hybrid_bytes - binary_bytes) / binary_bytes) * 100.0
        ),
    }


def _bootstrap_median_ci(
    samples: Sequence[float],
    *,
    resamples: int,
    seed: int,
) -> tuple[float, float]:
    if not samples:
        raise HVEError("timing samples must not be empty")
    if resamples <= 0 or len(samples) == 1:
        value = statistics.median(samples)
        return value, value
    rng = random.Random(seed)
    count = len(samples)
    medians = sorted(
        statistics.median(rng.choices(samples, k=count)) for _ in range(resamples)
    )
    low_index = max(0, math.floor(0.025 * (resamples - 1)))
    high_index = min(resamples - 1, math.ceil(0.975 * (resamples - 1)))
    return medians[low_index], medians[high_index]


def _time_operation(
    *,
    operation: str,
    action: Callable[[], object],
    repetitions: int,
    iterations: int,
    character_count: int,
    input_bytes: int,
    bootstrap_resamples: int,
    seed: int,
) -> TimingResult:
    if repetitions < 1 or iterations < 1:
        raise HVEError("timing repetitions and iterations must be positive")
    action()  # warm-up and early correctness failure
    samples: list[float] = []
    for _ in range(repetitions):
        start = time.perf_counter_ns()
        for _ in range(iterations):
            action()
        elapsed = (time.perf_counter_ns() - start) / 1_000_000_000
        samples.append(elapsed / iterations)
    median = statistics.median(samples)
    low, high = _bootstrap_median_ci(
        samples,
        resamples=bootstrap_resamples,
        seed=seed,
    )
    safe_median = max(median, float.fromhex("0x1.0p-1022"))
    return TimingResult(
        operation=operation,
        repetitions=repetitions,
        iterations_per_repetition=iterations,
        median_seconds=median,
        ci95_low_seconds=low,
        ci95_high_seconds=high,
        min_seconds=min(samples),
        max_seconds=max(samples),
        characters_per_second=character_count / safe_median,
        input_mib_per_second=(input_bytes / (1024 * 1024)) / safe_median,
        samples_seconds=tuple(samples),
    )


def benchmark_corpus(
    name: str,
    text: str,
    *,
    repetitions: int = 9,
    target_characters: int = 100_000,
    bootstrap_resamples: int = 1_000,
    seed: int = 20260728,
) -> dict[str, Any]:
    """Benchmark codecs on the same text with deterministic CI resampling."""

    _validate_text(text)
    if repetitions < 1:
        raise HVEError("repetitions must be positive")
    iterations = max(1, min(10_000, target_characters // max(len(text), 1)))
    input_bytes = len(text.encode("utf-8"))
    results: dict[str, Any] = {}
    for offset, codec in enumerate(
        (
            CODEC_UTF8,
            CODEC_BINARY21,
            CODEC_HVE_LAB10,
            CODEC_HVE_HYBRID,
            CODEC_HVE_BASE15,
        )
    ):
        try:
            payload = ENCODERS[codec](text)
        except HVEError as exc:
            results[codec] = {"applicable": False, "reason": str(exc)}
            continue
        decoder = DECODERS[codec]
        encode_timing = _time_operation(
            operation="encode",
            action=lambda encoder=ENCODERS[codec]: encoder(text),
            repetitions=repetitions,
            iterations=iterations,
            character_count=len(text),
            input_bytes=input_bytes,
            bootstrap_resamples=bootstrap_resamples,
            seed=seed + offset * 2,
        )
        decode_timing = _time_operation(
            operation="decode",
            action=lambda decoder=decoder, payload=payload: decoder(payload),
            repetitions=repetitions,
            iterations=iterations,
            character_count=len(text),
            input_bytes=input_bytes,
            bootstrap_resamples=bootstrap_resamples,
            seed=seed + offset * 2 + 1,
        )
        if decoder(payload) != text:
            raise AssertionError(f"{codec} benchmark round-trip failure")
        results[codec] = {
            "applicable": True,
            "encode": asdict(encode_timing),
            "decode": asdict(decode_timing),
        }
    return {
        "name": name,
        "characters": len(text),
        "iterations_per_repetition": iterations,
        "codecs": results,
    }


def _sequence_occurrences(sequence: Sequence[int], pattern: Sequence[int]) -> list[int]:
    if not pattern:
        return list(range(len(sequence) + 1))
    result: list[int] = []
    width = len(pattern)
    for start in range(len(sequence) - width + 1):
        if sequence[start : start + width] == pattern:
            result.append(start)
    return result


def _hybrid_tokens(text: str) -> list[int]:
    symbol_to_index, _ = _lab720_v0_maps()
    # Disjoint integer domains preserve token identity without serializing bits.
    return [
        symbol_to_index[char]
        if char in symbol_to_index
        else 720 + ord(char)
        for char in text
    ]


def analyze_pattern_search(
    text: str,
    patterns: Sequence[str] | None = None,
) -> dict[str, Any]:
    """Verify exact pattern preservation on equivalent logical token streams."""

    _validate_text(text)
    if patterns is None:
        if not text:
            patterns = ("",)
        else:
            width = min(5, len(text))
            candidates = {
                text[:width],
                text[max(0, len(text) // 2 - width // 2) :][:width],
                text[-width:],
            }
            patterns = tuple(sorted(candidates))
    scalar_sequence = [ord(char) for char in text]
    hybrid_sequence = _hybrid_tokens(text)
    cases: list[dict[str, Any]] = []
    all_consistent = True
    for pattern in patterns:
        _validate_text(pattern)
        scalar_positions = _sequence_occurrences(
            scalar_sequence,
            [ord(char) for char in pattern],
        )
        hybrid_positions = _sequence_occurrences(
            hybrid_sequence,
            _hybrid_tokens(pattern),
        )
        utf8_roundtrip_positions = _sequence_occurrences(
            [ord(char) for char in decode_utf8(encode_utf8(text))],
            [ord(char) for char in pattern],
        )
        consistent = scalar_positions == hybrid_positions == utf8_roundtrip_positions
        all_consistent &= consistent
        cases.append(
            {
                "pattern": pattern,
                "occurrences": scalar_positions,
                "hve_utf8_binary_consistent": consistent,
            }
        )
    return {
        "exact_pattern_identity_preserved": all_consistent,
        "cases": cases,
        "hve_native_relational_search": (
            "available for assigned HVE coordinates; exact text search remains "
            "representation-independent"
        ),
        "utf8_native_relational_search": False,
        "raw_binary_native_relational_search": False,
    }


def _average_ranks(values: Sequence[float]) -> list[float]:
    indexed = sorted(enumerate(values), key=lambda item: item[1])
    ranks = [0.0] * len(values)
    cursor = 0
    while cursor < len(indexed):
        end = cursor + 1
        while end < len(indexed) and indexed[end][1] == indexed[cursor][1]:
            end += 1
        average_rank = (cursor + 1 + end) / 2
        for position in range(cursor, end):
            ranks[indexed[position][0]] = average_rank
        cursor = end
    return ranks


def _pearson(a: Sequence[float], b: Sequence[float]) -> float | None:
    if len(a) != len(b) or len(a) < 2:
        return None
    mean_a = statistics.mean(a)
    mean_b = statistics.mean(b)
    da = [value - mean_a for value in a]
    db = [value - mean_b for value in b]
    denominator = math.sqrt(sum(value * value for value in da) * sum(value * value for value in db))
    if denominator == 0:
        return None
    return sum(x * y for x, y in zip(da, db)) / denominator


def _lab_coordinate(index: int) -> tuple[int, int]:
    if not 0 <= index < 720:
        raise HVEError("LAB index outside [0, 719]")
    if index < 360:
        return index, 0
    degree_abs = index - 360 + 1
    return (-degree_abs) % 360, 1


def evaluate_semantic_pairs(
    pairs: Sequence[tuple[str, str, float]] | None,
) -> dict[str, Any]:
    """Evaluate, never assume, correlation between HVE distance and labels."""

    if not pairs:
        return {
            "status": "not_evaluated",
            "reason": (
                "No independent labelled similarity pairs were supplied; numeric "
                "proximity is not treated as automatic semantic evidence."
            ),
        }
    symbol_to_index, _ = _lab720_v0_maps()
    predicted: list[float] = []
    observed: list[float] = []
    excluded = 0
    for left, right, similarity in pairs:
        if (
            len(left) != 1
            or len(right) != 1
            or left not in symbol_to_index
            or right not in symbol_to_index
        ):
            excluded += 1
            continue
        if not math.isfinite(float(similarity)):
            raise HVEError("semantic similarity labels must be finite")
        theta_left, s_left = _lab_coordinate(symbol_to_index[left])
        theta_right, s_right = _lab_coordinate(symbol_to_index[right])
        angular = circular_distance(theta_left, theta_right) / 180.0
        polarity = float(s_left != s_right)
        normalized_distance = (angular + polarity) / 2.0
        predicted.append(1.0 - normalized_distance)
        observed.append(float(similarity))
    correlation = _pearson(_average_ranks(predicted), _average_ranks(observed))
    status = "evaluated" if predicted else "insufficient_mapped_pairs"
    return {
        "status": status,
        "mapped_pairs": len(predicted),
        "excluded_pairs": excluded,
        "spearman_rank_correlation": correlation,
        "reason": (
            None
            if predicted
            else "No supplied pair had two scalar symbols assigned in LAB-720 v0."
        ),
        "interpretation": (
            "A correlation is empirical evidence for this labelled dataset only; "
            "it is not a proof of universal semantic ordering."
        ),
    }


def benchmark_harmonic_domain(
    *,
    repetitions: int = 7,
    bootstrap_resamples: int = 1_000,
    seed: int = 20260728,
) -> dict[str, Any]:
    """Compare HVE's structured group transform with a flat FFT cost baseline."""

    rng = np.random.default_rng(seed)
    signal = rng.standard_normal(GROUP_SHAPE) + 1j * rng.standard_normal(GROUP_SHAPE)
    flat_signal = signal.reshape(-1)
    hve_spectrum = dft(signal)
    flat_spectrum = np.fft.fft(flat_signal)
    hve_error = float(np.max(np.abs(idft(hve_spectrum) - signal)))
    flat_error = float(np.max(np.abs(np.fft.ifft(flat_spectrum) - flat_signal)))
    hve_timing = _time_operation(
        operation="HVE group FFTN",
        action=lambda: dft(signal),
        repetitions=repetitions,
        iterations=1,
        character_count=GROUP_ORDER,
        input_bytes=signal.nbytes,
        bootstrap_resamples=bootstrap_resamples,
        seed=seed,
    )
    flat_timing = _time_operation(
        operation="flat FFT baseline",
        action=lambda: np.fft.fft(flat_signal),
        repetitions=repetitions,
        iterations=1,
        character_count=GROUP_ORDER,
        input_bytes=flat_signal.nbytes,
        bootstrap_resamples=bootstrap_resamples,
        seed=seed + 1,
    )
    return {
        "states": GROUP_ORDER,
        "hve_shape": list(GROUP_SHAPE),
        "hve_group_fftn": asdict(hve_timing),
        "flat_fft_baseline": asdict(flat_timing),
        "median_cost_ratio_hve_to_flat": (
            hve_timing.median_seconds / flat_timing.median_seconds
        ),
        "hve_roundtrip_max_abs_error": hve_error,
        "flat_roundtrip_max_abs_error": flat_error,
        "hve_parseval_passed": parseval_check(signal, hve_spectrum),
        "structured_axes_preserved_by_hve": True,
        "structured_axes_preserved_by_flat_baseline": False,
        "boundary": (
            "The flat FFT is a computational cost baseline. Raw binary and UTF-8 "
            "have no intrinsic four-axis harmonic domain."
        ),
    }


def _changed_characters(original: str, changed: str) -> int:
    overlap = sum(a != b for a, b in zip(original, changed))
    return overlap + abs(len(original) - len(changed))


def _frame_crc_detects(payload: EncodedPayload, bit_index: int) -> bool:
    frame = bytearray(pack_reference_frame(payload))
    byte_index = REFERENCE_HEADER_SIZE + bit_index // 8
    bit_in_byte = 7 - (bit_index % 8)
    frame[byte_index] ^= 1 << bit_in_byte
    try:
        unpack_reference_frame(bytes(frame))
    except HVEError:
        return True
    return False


def analyze_single_bit_errors(
    codec: str,
    text: str,
    *,
    trials: int = 256,
    seed: int = 20260728,
) -> ErrorResult:
    """Measure payload-only single-bit corruption and common-frame detection."""

    if codec not in ENCODERS:
        raise HVEError("unknown text codec")
    if trials < 1:
        raise HVEError("error trials must be positive")
    payload = ENCODERS[codec](text)
    if payload.bit_length == 0:
        return ErrorResult(codec, 0, 0, 0, 0, 0.0, 0.0, 0.0, 0.0)
    rng = random.Random(seed)
    population = list(range(payload.bit_length))
    bit_indices = (
        population
        if trials >= len(population)
        else rng.sample(population, trials)
    )
    detected = 0
    silent = 0
    unchanged = 0
    changed_counts: list[int] = []
    crc_detected = 0
    for bit_index in bit_indices:
        changed_data = bytearray(payload.data)
        byte_index = bit_index // 8
        bit_in_byte = 7 - (bit_index % 8)
        changed_data[byte_index] ^= 1 << bit_in_byte
        changed_payload = EncodedPayload(
            payload.codec,
            bytes(changed_data),
            payload.item_count,
            payload.bit_length,
            payload.mapped_count,
            payload.fallback_count,
        )
        try:
            recovered = DECODERS[codec](changed_payload)
        except (HVEError, UnicodeError):
            detected += 1
        else:
            if recovered == text:
                unchanged += 1
            else:
                silent += 1
                changed_counts.append(_changed_characters(text, recovered))
        crc_detected += int(_frame_crc_detects(payload, bit_index))
    actual_trials = len(bit_indices)
    return ErrorResult(
        codec=codec,
        trials=actual_trials,
        detected_errors=detected,
        silent_corruptions=silent,
        unchanged_results=unchanged,
        detected_error_rate=detected / actual_trials,
        silent_corruption_rate=silent / actual_trials,
        mean_changed_characters_when_silent=(
            statistics.mean(changed_counts) if changed_counts else 0.0
        ),
        common_frame_crc_detection_rate=crc_detected / actual_trials,
    )


STRUCTURAL_CAPABILITIES: dict[str, dict[str, Any]] = {
    "raw_binary": {
        "arbitrary_bytes_lossless": True,
        "all_unicode_scalars_lossless": "requires an external text convention",
        "fixed_symbol_boundary": False,
        "typed_hve_coordinates": False,
        "native_circular_metric": False,
        "native_finite_group_operations": False,
        "native_harmonic_transform": False,
        "reserved_invalid_state_detection": False,
        "byte_aligned": True,
        "global_deployment": True,
    },
    CODEC_UTF8: {
        "arbitrary_bytes_lossless": False,
        "all_unicode_scalars_lossless": True,
        "fixed_symbol_boundary": False,
        "typed_hve_coordinates": False,
        "native_circular_metric": False,
        "native_finite_group_operations": False,
        "native_harmonic_transform": False,
        "reserved_invalid_state_detection": True,
        "byte_aligned": True,
        "global_deployment": True,
    },
    "hve_universal": {
        "arbitrary_bytes_lossless": True,
        "all_unicode_scalars_lossless": True,
        "fixed_symbol_boundary": True,
        "typed_hve_coordinates": True,
        "native_circular_metric": True,
        "native_finite_group_operations": True,
        "native_harmonic_transform": True,
        "reserved_invalid_state_detection": True,
        "byte_aligned": False,
        "global_deployment": False,
    },
}

STRUCTURAL_DOMINANCE_SCOPE = (
    "arbitrary_bytes_lossless",
    "all_unicode_scalars_lossless",
    "typed_hve_coordinates",
    "native_circular_metric",
    "native_finite_group_operations",
    "native_harmonic_transform",
)


def verify_dominance_certificate(seed: int = 20260728) -> dict[str, Any]:
    """Execute proof obligations for the delimited structural claim."""

    seen = bytearray(BASE_CARDINALITY)
    for index in range(BASE_CARDINALITY):
        state = decode_base(index)
        recovered = encode_base(state)
        if recovered != index or seen[recovered]:
            raise AssertionError("BASE bijection proof obligation failed")
        seen[recovered] = 1
    reserved_rejected = 0
    for index in range(BASE_CARDINALITY, 1 << 15):
        try:
            decode_base(index)
        except HVEError:
            reserved_rejected += 1
    crosswalk_verified = 0
    for index in range(BASE_CARDINALITY):
        state = decode_base_with_layout(index, BASE_LAYOUT_ENGINE_V1)
        document_index = encode_base_with_layout(
            state,
            BASE_LAYOUT_DOCUMENT_2025,
        )
        recovered = decode_base_with_layout(
            document_index,
            BASE_LAYOUT_DOCUMENT_2025,
        )
        if recovered != state:
            raise AssertionError("mixed-radix layout crosswalk failed")
        crosswalk_verified += 1
    lab_symbol_to_index, lab_index_to_symbol = _lab720_v0_maps()
    binary_vectors = [b"", bytes(range(256))]
    rng = random.Random(seed)
    for length in (1, 2, 7, 31, 257, 4096):
        binary_vectors.append(bytes(rng.randrange(256) for _ in range(length)))
    binary_roundtrips = sum(
        recover_binary(embed_binary(vector)) == vector for vector in binary_vectors
    )
    unicode_vectors = [
        "",
        "HVE 720",
        "ação, razão e frequência",
        "Ελληνικά Кириллица العربية 中文 😀",
        "\x00\t\n",
        chr(0x10FFFF),
    ]
    unicode_roundtrips = sum(
        recover_unicode(embed_unicode(vector)) == vector for vector in unicode_vectors
    )
    canonical_records = [
        {
            "theta": p.theta,
            "s": p.s,
            "category": p.category,
            "symbol": p.symbol,
        }
        for p in canonical_positions()
    ]
    canonical_hash = hashlib.sha256(
        json.dumps(
            canonical_records,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ).encode("utf-8")
    ).hexdigest()
    hve = STRUCTURAL_CAPABILITIES["hve_universal"]
    competitors = ("raw_binary", CODEC_UTF8)
    dominance_by_competitor = {
        competitor: all(bool(hve[criterion]) for criterion in STRUCTURAL_DOMINANCE_SCOPE)
        and any(
            not bool(STRUCTURAL_CAPABILITIES[competitor][criterion])
            or isinstance(STRUCTURAL_CAPABILITIES[competitor][criterion], str)
            for criterion in STRUCTURAL_DOMINANCE_SCOPE
        )
        for competitor in competitors
    }
    obligations = {
        "base_bijection_32400": all(seen),
        "reserved_words_rejected_368": reserved_rejected == BASE_RESERVED_WORDS,
        "binary_embedding_roundtrips": binary_roundtrips == len(binary_vectors),
        "unicode_embedding_roundtrips": unicode_roundtrips == len(unicode_vectors),
        "layout_crosswalk_32400": crosswalk_verified == BASE_CARDINALITY,
        "lab720_scalar_assignments_169": (
            len(lab_symbol_to_index) == len(lab_index_to_symbol) == 169
        ),
        "strict_added_structure": all(dominance_by_competitor.values()),
    }
    return {
        "claim": (
            "HVE Universal is a strict functional and structural extension of raw "
            "binary and UTF-8 within the declared dominance scope."
        ),
        "scope": list(STRUCTURAL_DOMINANCE_SCOPE),
        "not_claimed": (
            "universal superiority in storage size, execution speed, byte alignment, "
            "or deployed interoperability"
        ),
        "obligations": obligations,
        "passed": all(obligations.values()),
        "base_states_verified": sum(seen),
        "reserved_words_rejected": reserved_rejected,
        "layout_crosswalk_states_verified": crosswalk_verified,
        "lab720_scalar_assignments": len(lab_symbol_to_index),
        "lab720_unassigned_or_reserved_positions": 720 - len(lab_index_to_symbol),
        "binary_vectors_verified": binary_roundtrips,
        "unicode_vectors_verified": unicode_roundtrips,
        "canonical_table_sha256": canonical_hash,
        "dominance_by_competitor": dominance_by_competitor,
    }


def default_corpora() -> dict[str, str]:
    """Small deterministic fixtures; external files are accepted for real corpora."""

    _, lab_assigned = _lab720_v0_maps()
    assigned = "".join(lab_assigned[index] for index in sorted(lab_assigned))
    return {
        "ascii": (
            "HVE 720 maps finite states, preserves exact identity, and supports "
            "reproducible computation.\n"
        ),
        "portuguese": (
            "A codificação harmônica preserva ação, razão, frequência, direção e "
            "relações matemáticas sem perder a reversibilidade.\n"
        ),
        "multilingual": (
            "Português Ελληνικά Кириллица العربية हिन्दी "
            "中文 日本語 한국어 😀🧭⚙️\n"
        ),
        "canonical_assigned": assigned,
    }


def load_corpora(paths: Iterable[str | Path]) -> dict[str, str]:
    corpora: dict[str, str] = {}
    for raw_path in paths:
        path = Path(raw_path)
        name = path.stem
        if name in corpora:
            raise HVEError(f"duplicate corpus name: {name}")
        corpora[name] = path.read_text(encoding="utf-8")
    return corpora


def load_semantic_pairs(path: str | Path) -> list[tuple[str, str, float]]:
    """Load JSON records with ``left``, ``right``, and ``similarity`` fields."""

    raw = json.loads(Path(path).read_text(encoding="utf-8"))
    if not isinstance(raw, list):
        raise HVEError("semantic-pairs file must contain a JSON list")
    result: list[tuple[str, str, float]] = []
    for position, record in enumerate(raw):
        if not isinstance(record, dict):
            raise HVEError(f"semantic pair {position} must be an object")
        try:
            left = record["left"]
            right = record["right"]
            similarity = float(record["similarity"])
        except (KeyError, TypeError, ValueError) as exc:
            raise HVEError(
                f"semantic pair {position} requires left, right, and similarity"
            ) from exc
        if not isinstance(left, str) or not isinstance(right, str):
            raise HVEError(f"semantic pair {position} symbols must be strings")
        result.append((left, right, similarity))
    return result


def run_comparison(
    corpora: Mapping[str, str] | None = None,
    *,
    semantic_pairs: Sequence[tuple[str, str, float]] | None = None,
    token_vocabulary_size: int | None = None,
    token_training_fraction: float = 0.8,
    token_minimum_pair_frequency: int = 2,
    token_maximum_characters: int = 32,
    repetitions: int = 9,
    target_characters: int = 100_000,
    bootstrap_resamples: int = 1_000,
    error_trials: int = 256,
    seed: int = 20260728,
    include_timings: bool = True,
    include_error_analysis: bool = True,
    include_harmonic_benchmark: bool = True,
) -> dict[str, Any]:
    selected = dict(corpora or default_corpora())
    if not selected:
        raise HVEError("at least one corpus is required")
    corpus_results = []
    for offset, (name, text) in enumerate(selected.items()):
        entry: dict[str, Any] = {
            "storage": analyze_corpus(name, text),
            "pattern_search": analyze_pattern_search(text),
        }
        if token_vocabulary_size is not None:
            try:
                entry["token_profile"] = cross_validated_token_analysis(
                    text,
                    training_fraction=token_training_fraction,
                    target_vocabulary_size=token_vocabulary_size,
                    minimum_pair_frequency=token_minimum_pair_frequency,
                    maximum_token_characters=token_maximum_characters,
                )
            except HVEError as exc:
                entry["token_profile"] = {
                    "applicable": False,
                    "reason": str(exc),
                }
            else:
                entry["token_profile"]["applicable"] = True
        if include_timings:
            entry["performance"] = benchmark_corpus(
                name,
                text,
                repetitions=repetitions,
                target_characters=target_characters,
                bootstrap_resamples=bootstrap_resamples,
                seed=seed + offset * 100,
            )
        if include_error_analysis:
            errors: dict[str, Any] = {}
            for codec_offset, codec in enumerate(
                (
                    CODEC_UTF8,
                    CODEC_BINARY21,
                    CODEC_HVE_LAB10,
                    CODEC_HVE_HYBRID,
                    CODEC_HVE_BASE15,
                )
            ):
                try:
                    result = analyze_single_bit_errors(
                        codec,
                        text,
                        trials=error_trials,
                        seed=seed + offset * 100 + codec_offset,
                    )
                except HVEError as exc:
                    errors[codec] = {"applicable": False, "reason": str(exc)}
                else:
                    errors[codec] = {"applicable": True, **asdict(result)}
            entry["single_bit_errors"] = errors
        corpus_results.append(entry)
    report = {
        "schema": "hve-comparison-report/1.0",
        "generated_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "method": {
            "same_input_per_corpus": True,
            "lossless_roundtrip_required": True,
            "common_reference_frame_bytes": REFERENCE_HEADER_SIZE,
            "binary_baseline": "fixed 21-bit Unicode scalar packing",
            "hve_lab_profile": (
                "10-bit LAB-720 v0 positions; 169 scalar assignments transcribed "
                "from HVE.docx; applicable only at 100% coverage"
            ),
            "hve_base_profile": (
                "15-bit HVE-4D canonical states; applicable only at 100% coverage"
            ),
            "hve_universal_profile": "1+10-bit LAB token or 1+21-bit Unicode fallback",
            "timing_repetitions": repetitions if include_timings else 0,
            "timing_target_characters": target_characters if include_timings else 0,
            "bootstrap_resamples": bootstrap_resamples if include_timings else 0,
            "error_trials_requested": error_trials if include_error_analysis else 0,
            "seed": seed,
            "token_vocabulary_size": token_vocabulary_size,
            "token_training_fraction": (
                token_training_fraction if token_vocabulary_size is not None else None
            ),
            "token_minimum_pair_frequency": (
                token_minimum_pair_frequency
                if token_vocabulary_size is not None
                else None
            ),
            "token_maximum_characters": (
                token_maximum_characters if token_vocabulary_size is not None else None
            ),
        },
        "environment": {
            "platform": platform.platform(),
            "python": platform.python_version(),
            "implementation": platform.python_implementation(),
        },
        "structural_capabilities": STRUCTURAL_CAPABILITIES,
        "dominance_certificate": verify_dominance_certificate(seed),
        "semantic_evaluation": evaluate_semantic_pairs(semantic_pairs),
        "corpora": corpus_results,
    }
    if include_harmonic_benchmark:
        report["harmonic_benchmark"] = benchmark_harmonic_domain(
            repetitions=max(1, min(repetitions, 9)),
            bootstrap_resamples=bootstrap_resamples,
            seed=seed,
        )
    return report


def _storage_rows(report: Mapping[str, Any]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    for corpus_entry in report["corpora"]:
        storage = corpus_entry["storage"]
        for codec, values in storage["codecs"].items():
            row = {
                "corpus": storage["name"],
                "characters": storage["characters"],
                "unique_scalars": storage["unique_scalars"],
                "codec": codec,
                **values,
            }
            rows.append(row)
    return rows


def _csv_text(rows: Sequence[Mapping[str, Any]]) -> str:
    if not rows:
        return ""
    fieldnames: list[str] = []
    for row in rows:
        for key in row:
            if key not in fieldnames:
                fieldnames.append(key)
    buffer = io.StringIO()
    writer = csv.DictWriter(buffer, fieldnames=fieldnames, extrasaction="ignore")
    writer.writeheader()
    for row in rows:
        writer.writerow(row)
    return buffer.getvalue()


def render_markdown(report: Mapping[str, Any]) -> str:
    certificate = report["dominance_certificate"]
    lines = [
        "# HVE × UTF-8 × Binary21 — Comparative Report",
        "",
        f"Generated: `{report['generated_utc']}`",
        "",
        "## Structural result",
        "",
        f"**Certificate:** {'PASS' if certificate['passed'] else 'FAIL'}",
        "",
        certificate["claim"],
        "",
        f"Not claimed: {certificate['not_claimed']}.",
        "",
        "| Proof obligation | Result |",
        "|---|---:|",
    ]
    for name, passed in certificate["obligations"].items():
        lines.append(f"| {name} | {'PASS' if passed else 'FAIL'} |")
    lines.extend(
        [
            "",
            "## Storage by corpus",
            "",
            "| Corpus | Codec | Coverage | Payload bytes | Bits/char | Δ vs UTF-8 |",
            "|---|---|---:|---:|---:|---:|",
        ]
    )
    for entry in report["corpora"]:
        storage = entry["storage"]
        for codec, values in storage["codecs"].items():
            if not values["applicable"]:
                lines.append(
                    f"| {storage['name']} | {codec} | n/a | n/a | n/a | n/a |"
                )
                continue
            coverage = values["canonical_coverage_rate"]
            coverage_text = "n/a" if coverage is None else f"{coverage:.2%}"
            lines.append(
                f"| {storage['name']} | {codec} | {coverage_text} | "
                f"{values['payload_bytes']} | {values['bits_per_character']:.3f} | "
                f"{values['size_change_vs_utf8_percent']:+.2f}% |"
            )
    if any("performance" in entry for entry in report["corpora"]):
        lines.extend(
            [
                "",
                "## Reference Python performance",
                "",
                "Medians include 95% bootstrap confidence intervals. These are host and "
                "implementation measurements, not universal hardware claims.",
                "",
                "| Corpus | Codec | Encode MiB/s | Decode MiB/s |",
                "|---|---|---:|---:|",
            ]
        )
        for entry in report["corpora"]:
            performance = entry.get("performance")
            if not performance:
                continue
            for codec, values in performance["codecs"].items():
                if not values["applicable"]:
                    continue
                lines.append(
                    f"| {performance['name']} | {codec} | "
                    f"{values['encode']['input_mib_per_second']:.3f} | "
                    f"{values['decode']['input_mib_per_second']:.3f} |"
                )
    if any("token_profile" in entry for entry in report["corpora"]):
        lines.extend(
            [
                "",
                "## Cross-validated HVE token profile",
                "",
                "Vocabulary is trained on the declared prefix and measured only on "
                "the held-out suffix. Dictionary cost is reported explicitly.",
                "",
                "| Corpus | Vocab | Chars/token | Pure 15-bit bpc | "
                "Hybrid bpc | Hybrid Δ UTF-8 | Dict bytes | Break-even chars |",
                "|---|---:|---:|---:|---:|---:|---:|---:|",
            ]
        )
        for entry in report["corpora"]:
            token = entry.get("token_profile")
            if not token or not token["applicable"]:
                name = entry["storage"]["name"]
                lines.append(
                    f"| {name} | n/a | n/a | n/a | n/a | n/a | n/a | n/a |"
                )
                continue
            pure = token["pure_token15"]
            pure_bpc = (
                f"{pure['bits_per_character']:.3f}"
                if pure["applicable"]
                else "n/a"
            )
            hybrid = token["hybrid_token_profile"]
            lines.append(
                f"| {entry['storage']['name']} | {token['vocabulary_tokens']} | "
                f"{token['mean_characters_per_piece']:.3f} | {pure_bpc} | "
                f"{hybrid['bits_per_character']:.3f} | "
                f"{hybrid['payload_change_vs_utf8_percent']:+.2f}% | "
                f"{token['vocabulary_serialized_utf8_bytes']} | "
                f"{hybrid['dictionary_break_even_characters'] or 'n/a'} |"
            )
    if any("single_bit_errors" in entry for entry in report["corpora"]):
        lines.extend(
            [
                "",
                "## Single-bit payload errors",
                "",
                "| Corpus | Codec | Detected | Silent | Common CRC detected |",
                "|---|---|---:|---:|---:|",
            ]
        )
        for entry in report["corpora"]:
            name = entry["storage"]["name"]
            for codec, values in entry.get("single_bit_errors", {}).items():
                if not values["applicable"]:
                    continue
                lines.append(
                    f"| {name} | {codec} | {values['detected_error_rate']:.2%} | "
                    f"{values['silent_corruption_rate']:.2%} | "
                    f"{values['common_frame_crc_detection_rate']:.2%} |"
                )
    lines.extend(
        [
            "",
            "## Pattern and semantic evaluation",
            "",
            "| Corpus | Exact pattern identity |",
            "|---|---:|",
        ]
    )
    for entry in report["corpora"]:
        pattern = entry["pattern_search"]
        lines.append(
            f"| {entry['storage']['name']} | "
            f"{'PASS' if pattern['exact_pattern_identity_preserved'] else 'FAIL'} |"
        )
    semantic = report["semantic_evaluation"]
    lines.extend(
        [
            "",
            f"Semantic evaluation status: `{semantic['status']}`.",
            "",
        ]
    )
    if semantic["status"] == "evaluated":
        lines.append(
            "Spearman rank correlation: "
            f"`{semantic['spearman_rank_correlation']}` over "
            f"{semantic['mapped_pairs']} mapped pairs."
        )
        lines.append("")
    else:
        lines.append(semantic["reason"])
        lines.append("")
    harmonic = report.get("harmonic_benchmark")
    if harmonic:
        lines.extend(
            [
                "## Harmonic-domain benchmark",
                "",
                f"- States: {harmonic['states']}",
                f"- HVE shape: `{harmonic['hve_shape']}`",
                "- HVE round-trip max error: "
                f"`{harmonic['hve_roundtrip_max_abs_error']:.3e}`",
                f"- Parseval: {'PASS' if harmonic['hve_parseval_passed'] else 'FAIL'}",
                "- Median HVE FFTN / flat FFT cost ratio: "
                f"`{harmonic['median_cost_ratio_hve_to_flat']:.4f}`",
                "",
                harmonic["boundary"],
                "",
            ]
        )
    lines.extend(
        [
            "",
            "## Interpretation boundary",
            "",
            "- Structural dominance is proved only for the declared functional scope.",
            "- Storage and speed are empirical, corpus-dependent outcomes.",
            "- Binary21 is a fixed Unicode-scalar baseline; raw binary has no intrinsic "
            "character semantics.",
            "- HVE BASE15 is reported only when every input symbol has a canonical mapping.",
            "- HVE hybrid fallback preserves Unicode identity but does not invent HVE geometry "
            "for an unassigned symbol.",
            "",
        ]
    )
    return "\n".join(lines)


def write_comparison_artifacts(
    report: Mapping[str, Any],
    output_directory: str | Path,
) -> dict[str, str]:
    directory = Path(output_directory)
    directory.mkdir(parents=True, exist_ok=True)
    json_path = directory / "hve_comparison_report.json"
    csv_path = directory / "hve_storage_metrics.csv"
    markdown_path = directory / "hve_comparison_report.md"
    json_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    csv_path.write_text(_csv_text(_storage_rows(report)), encoding="utf-8")
    markdown_path.write_text(render_markdown(report), encoding="utf-8")
    return {
        "json": str(json_path),
        "csv": str(csv_path),
        "markdown": str(markdown_path),
    }
