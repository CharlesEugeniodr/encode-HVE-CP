"""Deterministic HVE token-vocabulary experiments.

This module evaluates the 32,400-state token profile proposed in the original
HVE project material.  Training and evaluation are kept separate, and both
payload-only and vocabulary-inclusive costs are reported.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
import hashlib
import json
import math
from typing import Any

from .core import BASE_CARDINALITY, HVEError
from .protocol import pack_base15, unpack_base15


@dataclass(frozen=True, slots=True)
class HVEVocabulary:
    tokens: tuple[str, ...]
    merges: tuple[tuple[str, str], ...]

    def __post_init__(self) -> None:
        if not self.tokens:
            raise HVEError("vocabulary must not be empty")
        if len(self.tokens) > BASE_CARDINALITY:
            raise HVEError("vocabulary exceeds 32,400 HVE states")
        if any(not isinstance(token, str) or not token for token in self.tokens):
            raise HVEError("vocabulary tokens must be nonempty strings")
        if len(set(self.tokens)) != len(self.tokens):
            raise HVEError("vocabulary tokens must be unique")

    @property
    def token_to_index(self) -> dict[str, int]:
        return {token: index for index, token in enumerate(self.tokens)}

    @property
    def sha256(self) -> str:
        content = json.dumps(
            {"tokens": self.tokens, "merges": self.merges},
            ensure_ascii=False,
            separators=(",", ":"),
        ).encode("utf-8")
        return hashlib.sha256(content).hexdigest()

    @property
    def serialized_utf8_bytes(self) -> int:
        # uint32 count + uint16 byte length per token + token bytes.
        return 4 + sum(2 + len(token.encode("utf-8")) for token in self.tokens)


@dataclass(frozen=True, slots=True)
class TokenEncoding:
    token_ids: tuple[int, ...]
    fallback_scalars: tuple[tuple[int, int], ...]
    character_count: int
    pure_payload: bytes | None
    pure_bit_length: int | None
    hybrid_payload: bytes
    hybrid_bit_length: int

    @property
    def token_count(self) -> int:
        return len(self.token_ids) + len(self.fallback_scalars)


class _BitWriter:
    def __init__(self) -> None:
        self.data = bytearray()
        self.current = 0
        self.used = 0
        self.bit_length = 0

    def write(self, value: int, width: int) -> None:
        if value < 0 or value >= 1 << width:
            raise HVEError("value does not fit bit field")
        for shift in range(width - 1, -1, -1):
            self.current = (self.current << 1) | ((value >> shift) & 1)
            self.used += 1
            self.bit_length += 1
            if self.used == 8:
                self.data.append(self.current)
                self.current = 0
                self.used = 0

    def finish(self) -> bytes:
        if self.used:
            self.data.append(self.current << (8 - self.used))
        return bytes(self.data)


class _BitReader:
    def __init__(self, data: bytes, bit_length: int) -> None:
        if bit_length < 0 or bit_length > len(data) * 8:
            raise HVEError("invalid token bit length")
        self.data = data
        self.bit_length = bit_length
        self.position = 0

    def read(self, width: int) -> int:
        if self.position + width > self.bit_length:
            raise HVEError("truncated token bitstream")
        value = 0
        for _ in range(width):
            byte_index = self.position // 8
            bit_index = 7 - self.position % 8
            value = (value << 1) | ((self.data[byte_index] >> bit_index) & 1)
            self.position += 1
        return value


def train_bpe_vocabulary(
    text: str,
    *,
    target_size: int = 512,
    minimum_pair_frequency: int = 2,
    maximum_token_characters: int = 32,
) -> HVEVocabulary:
    """Train a deterministic character BPE vocabulary on the declared split."""

    if not isinstance(text, str) or not text:
        raise HVEError("training text must be a nonempty string")
    if not 1 <= target_size <= BASE_CARDINALITY:
        raise HVEError("target vocabulary size must be in [1, 32400]")
    if minimum_pair_frequency < 2:
        raise HVEError("minimum pair frequency must be at least 2")
    if maximum_token_characters < 2:
        raise HVEError("maximum token length must be at least 2")
    initial_tokens = tuple(sorted(set(text), key=lambda token: (ord(token), token)))
    if len(initial_tokens) > target_size:
        raise HVEError("target size is smaller than the training alphabet")
    vocabulary = list(initial_tokens)
    known = set(vocabulary)
    sequence = list(text)
    merges: list[tuple[str, str]] = []
    while len(vocabulary) < target_size and len(sequence) > 1:
        counts = Counter(
            pair
            for pair in zip(sequence, sequence[1:])
            if len(pair[0]) + len(pair[1]) <= maximum_token_characters
        )
        if not counts:
            break
        best_frequency = max(counts.values())
        if best_frequency < minimum_pair_frequency:
            break
        candidates = sorted(pair for pair, count in counts.items() if count == best_frequency)
        left, right = candidates[0]
        merged = left + right
        if merged in known:
            # The selected pair is already a token; remove its occurrences from
            # further consideration by merging the sequence without growing V.
            pass
        else:
            vocabulary.append(merged)
            known.add(merged)
            merges.append((left, right))
        new_sequence: list[str] = []
        cursor = 0
        merged_any = False
        while cursor < len(sequence):
            if (
                cursor + 1 < len(sequence)
                and sequence[cursor] == left
                and sequence[cursor + 1] == right
            ):
                new_sequence.append(merged)
                cursor += 2
                merged_any = True
            else:
                new_sequence.append(sequence[cursor])
                cursor += 1
        if not merged_any:
            break
        sequence = new_sequence
    return HVEVocabulary(tuple(vocabulary), tuple(merges))


def _token_candidates(vocabulary: HVEVocabulary) -> dict[str, tuple[str, ...]]:
    grouped: dict[str, list[str]] = {}
    for token in vocabulary.tokens:
        grouped.setdefault(token[0], []).append(token)
    return {
        first: tuple(sorted(tokens, key=lambda token: (-len(token), token)))
        for first, tokens in grouped.items()
    }


def encode_with_vocabulary(text: str, vocabulary: HVEVocabulary) -> TokenEncoding:
    """Greedy longest-match encoding with explicit scalar fallback."""

    if not isinstance(text, str):
        raise HVEError("text must be str")
    token_to_index = vocabulary.token_to_index
    candidates = _token_candidates(vocabulary)
    pieces: list[tuple[bool, int]] = []
    token_ids: list[int] = []
    fallback: list[tuple[int, int]] = []
    character_position = 0
    while character_position < len(text):
        match = None
        for token in candidates.get(text[character_position], ()):
            if text.startswith(token, character_position):
                match = token
                break
        if match is None:
            scalar = ord(text[character_position])
            if 0xD800 <= scalar <= 0xDFFF:
                raise HVEError("input contains a surrogate, not a Unicode scalar")
            pieces.append((False, scalar))
            fallback.append((character_position, scalar))
            character_position += 1
        else:
            token_id = token_to_index[match]
            pieces.append((True, token_id))
            token_ids.append(token_id)
            character_position += len(match)

    pure_payload = None
    pure_bits = None
    if not fallback:
        pure_payload = pack_base15([value for is_token, value in pieces if is_token])
        pure_bits = len(pieces) * 15

    writer = _BitWriter()
    for is_token, value in pieces:
        writer.write(0 if is_token else 1, 1)
        writer.write(value, 15 if is_token else 21)
    hybrid_payload = writer.finish()
    return TokenEncoding(
        token_ids=tuple(token_ids),
        fallback_scalars=tuple(fallback),
        character_count=len(text),
        pure_payload=pure_payload,
        pure_bit_length=pure_bits,
        hybrid_payload=hybrid_payload,
        hybrid_bit_length=writer.bit_length,
    )


def decode_pure_token15(
    data: bytes,
    token_count: int,
    vocabulary: HVEVocabulary,
) -> str:
    tokens = vocabulary.tokens
    decoded: list[str] = []
    for token_id in unpack_base15(data, token_count):
        if token_id >= len(tokens):
            raise HVEError("token index is outside the supplied vocabulary")
        decoded.append(tokens[token_id])
    return "".join(decoded)


def decode_hybrid_tokens(
    data: bytes,
    bit_length: int,
    piece_count: int,
    vocabulary: HVEVocabulary,
) -> str:
    reader = _BitReader(data, bit_length)
    decoded: list[str] = []
    for _ in range(piece_count):
        fallback = reader.read(1)
        if fallback:
            scalar = reader.read(21)
            if scalar > 0x10FFFF or 0xD800 <= scalar <= 0xDFFF:
                raise HVEError("invalid fallback Unicode scalar")
            decoded.append(chr(scalar))
        else:
            token_id = reader.read(15)
            if token_id >= len(vocabulary.tokens):
                raise HVEError("token index is outside the supplied vocabulary")
            decoded.append(vocabulary.tokens[token_id])
    if reader.position != bit_length:
        raise HVEError("token payload contains trailing bits")
    return "".join(decoded)


def cross_validated_token_analysis(
    text: str,
    *,
    training_fraction: float = 0.8,
    target_vocabulary_size: int = 512,
    minimum_pair_frequency: int = 2,
    maximum_token_characters: int = 32,
) -> dict[str, Any]:
    """Train on a prefix and evaluate only on the held-out suffix."""

    if len(text) < 2:
        raise HVEError("token analysis requires at least two characters")
    if not 0.1 <= training_fraction <= 0.9:
        raise HVEError("training fraction must be in [0.1, 0.9]")
    split = min(len(text) - 1, max(1, round(len(text) * training_fraction)))
    training = text[:split]
    evaluation = text[split:]
    vocabulary = train_bpe_vocabulary(
        training,
        target_size=target_vocabulary_size,
        minimum_pair_frequency=minimum_pair_frequency,
        maximum_token_characters=maximum_token_characters,
    )
    encoded = encode_with_vocabulary(evaluation, vocabulary)
    piece_count = encoded.token_count
    recovered_hybrid = decode_hybrid_tokens(
        encoded.hybrid_payload,
        encoded.hybrid_bit_length,
        piece_count,
        vocabulary,
    )
    if recovered_hybrid != evaluation:
        raise AssertionError("hybrid token round-trip failure")
    pure: dict[str, Any]
    if encoded.pure_payload is None or encoded.pure_bit_length is None:
        pure = {
            "applicable": False,
            "reason": "held-out text contains scalars absent from the training vocabulary",
        }
    else:
        recovered_pure = decode_pure_token15(
            encoded.pure_payload,
            piece_count,
            vocabulary,
        )
        if recovered_pure != evaluation:
            raise AssertionError("pure token15 round-trip failure")
        pure = {
            "applicable": True,
            "payload_bits": encoded.pure_bit_length,
            "payload_bytes": len(encoded.pure_payload),
            "bits_per_character": encoded.pure_bit_length / len(evaluation),
        }
    utf8_bytes = len(evaluation.encode("utf-8"))
    dictionary_bytes = vocabulary.serialized_utf8_bytes
    hybrid_bytes = len(encoded.hybrid_payload)
    payload_savings = utf8_bytes - hybrid_bytes
    break_even_reuses = (
        math.ceil(dictionary_bytes / payload_savings)
        if payload_savings > 0
        else None
    )
    return {
        "training_characters": len(training),
        "evaluation_characters": len(evaluation),
        "training_fraction": training_fraction,
        "vocabulary_tokens": len(vocabulary.tokens),
        "vocabulary_sha256": vocabulary.sha256,
        "vocabulary_serialized_utf8_bytes": dictionary_bytes,
        "merges_learned": len(vocabulary.merges),
        "evaluation_utf8_bytes": utf8_bytes,
        "pieces": piece_count,
        "mean_characters_per_piece": len(evaluation) / max(piece_count, 1),
        "fallback_scalars": len(encoded.fallback_scalars),
        "pure_token15": pure,
        "hybrid_token_profile": {
            "payload_bits": encoded.hybrid_bit_length,
            "payload_bytes": hybrid_bytes,
            "bits_per_character": encoded.hybrid_bit_length / len(evaluation),
            "payload_savings_vs_utf8_bytes": payload_savings,
            "payload_change_vs_utf8_percent": (
                (len(encoded.hybrid_payload) - utf8_bytes) / utf8_bytes * 100
                if utf8_bytes
                else 0.0
            ),
            "payload_plus_dictionary_bytes": (
                hybrid_bytes + dictionary_bytes
            ),
            "payload_plus_dictionary_change_vs_utf8_percent": (
                (hybrid_bytes + dictionary_bytes - utf8_bytes)
                / utf8_bytes
                * 100
                if utf8_bytes
                else 0.0
            ),
            "dictionary_break_even_evaluation_reuses": break_even_reuses,
            "dictionary_break_even_characters": (
                break_even_reuses * len(evaluation)
                if break_even_reuses is not None
                else None
            ),
        },
        "boundary": (
            "Payload-only gains exclude the one-time vocabulary cost. The "
            "vocabulary-inclusive result charges that full cost to this evaluation "
            "split and is therefore the conservative single-corpus measure."
        ),
        "parameters": {
            "target_vocabulary_size": target_vocabulary_size,
            "minimum_pair_frequency": minimum_pair_frequency,
            "maximum_token_characters": maximum_token_characters,
        },
    }
