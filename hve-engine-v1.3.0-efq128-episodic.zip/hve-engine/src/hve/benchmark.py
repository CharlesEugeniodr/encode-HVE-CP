"""Reproducible host benchmark harness; results are not hardware claims."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import json
import platform
import statistics
import time

from .core import BASE_CARDINALITY, decode_base, encode_base


@dataclass(frozen=True, slots=True)
class BenchmarkResult:
    workload: str
    iterations: int
    repetitions: int
    median_seconds: float
    min_seconds: float
    max_seconds: float
    operations_per_second: float
    platform: str
    python: str


def _run_once(iterations: int) -> None:
    for i in range(iterations):
        idx = i % BASE_CARDINALITY
        state = decode_base(idx)
        if encode_base(state) != idx:
            raise AssertionError("round-trip failure")


def benchmark_core(iterations: int = 100_000, repetitions: int = 7) -> BenchmarkResult:
    samples = []
    for _ in range(repetitions):
        start = time.perf_counter()
        _run_once(iterations)
        samples.append(time.perf_counter() - start)
    median = statistics.median(samples)
    return BenchmarkResult(
        workload="decode+encode BASE round-trip",
        iterations=iterations,
        repetitions=repetitions,
        median_seconds=median,
        min_seconds=min(samples),
        max_seconds=max(samples),
        operations_per_second=iterations / median,
        platform=platform.platform(),
        python=platform.python_version(),
    )


def result_json(result: BenchmarkResult) -> str:
    return json.dumps(asdict(result), indent=2)
