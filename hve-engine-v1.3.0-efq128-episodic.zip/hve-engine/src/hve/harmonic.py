"""Harmonic analysis on G = Z_360 × Z_2 × Z_5 × Z_9."""

from __future__ import annotations

from collections.abc import Sequence
import math
import numpy as np
from numpy.typing import ArrayLike, NDArray

from .core import HVEError, HVEState, THETA_CARD, S_CARD, TAU_CARD, PHI_CARD, validate_state

GROUP_SHAPE = (THETA_CARD, S_CARD, TAU_CARD, PHI_CARD)
GROUP_ORDER = math.prod(GROUP_SHAPE)


def _validate_frequency(k: Sequence[int]) -> tuple[int, int, int, int]:
    if len(k) != 4:
        raise HVEError("frequency index must have four coordinates")
    result = tuple(int(v) for v in k)
    if any(isinstance(v, bool) for v in k):
        raise HVEError("frequency coordinates must be integers")
    for value, modulus, name in zip(result, GROUP_SHAPE, ("k_theta", "k_s", "k_tau", "k_phi")):
        if not 0 <= value < modulus:
            raise HVEError(f"{name} outside its residue-class domain")
    return result  # type: ignore[return-value]


def character(k: Sequence[int], g: HVEState) -> complex:
    kt, ks, ku, kp = _validate_frequency(k)
    validate_state(g)
    phase = kt * g.theta / THETA_CARD + ks * g.s / S_CARD + ku * g.tau / TAU_CARD + kp * g.phi / PHI_CARD
    return complex(np.exp(2j * np.pi * phase))


def _as_group_array(f: ArrayLike) -> NDArray[np.complex128]:
    arr = np.asarray(f, dtype=np.complex128)
    if arr.shape != GROUP_SHAPE:
        raise HVEError(f"array shape must be {GROUP_SHAPE}, got {arr.shape}")
    if not np.all(np.isfinite(arr)):
        raise HVEError("array contains non-finite values")
    return arr


def dft(f: ArrayLike) -> NDArray[np.complex128]:
    """Forward DFT matching f_hat(k)=sum_g f(g) conjugate(chi_k(g))."""
    return np.fft.fftn(_as_group_array(f))


def idft(f_hat: ArrayLike) -> NDArray[np.complex128]:
    return np.fft.ifftn(_as_group_array(f_hat))


def dft_separable(f: ArrayLike) -> NDArray[np.complex128]:
    arr = _as_group_array(f).copy()
    for axis in range(4):
        arr = np.fft.fft(arr, axis=axis)
    return arr


def idft_separable(f_hat: ArrayLike) -> NDArray[np.complex128]:
    arr = _as_group_array(f_hat).copy()
    for axis in reversed(range(4)):
        arr = np.fft.ifft(arr, axis=axis)
    return arr


def dft_reference(f: ArrayLike, *, max_states: int = 4096) -> NDArray[np.complex128]:
    """Direct O(N^2) DFT oracle for reduced test groups.

    This helper accepts any 1-4D array and intentionally refuses large domains.
    Production HVE transforms must use `dft` or `dft_separable`.
    """
    arr = np.asarray(f, dtype=np.complex128)
    if arr.ndim < 1 or arr.ndim > 4:
        raise HVEError("reference DFT accepts 1 to 4 dimensions")
    if arr.size > max_states:
        raise HVEError("direct reference DFT exceeds configured safety limit")
    shape = arr.shape
    out = np.zeros(shape, dtype=np.complex128)
    for k in np.ndindex(shape):
        total = 0j
        for g in np.ndindex(shape):
            phase = sum(ki * gi / ni for ki, gi, ni in zip(k, g, shape))
            total += arr[g] * np.exp(-2j * np.pi * phase)
        out[k] = total
    return out


def convolve(f: ArrayLike, g: ArrayLike) -> NDArray[np.complex128]:
    return np.fft.ifftn(dft(f) * dft(g))


def correlate(f: ArrayLike, g: ArrayLike) -> NDArray[np.complex128]:
    """Circular cross-correlation r(u)=sum_x conjugate(f(x))*g(x+u)."""
    return np.fft.ifftn(np.conjugate(dft(f)) * dft(g))


def spectral_filter(f: ArrayLike, mask: ArrayLike) -> NDArray[np.complex128]:
    m = _as_group_array(mask)
    return idft(dft(f) * m)


def parseval_residual(f: ArrayLike, f_hat: ArrayLike | None = None) -> float:
    arr = _as_group_array(f)
    spectrum = dft(arr) if f_hat is None else _as_group_array(f_hat)
    lhs = float(np.sum(np.abs(arr) ** 2))
    rhs = float(np.sum(np.abs(spectrum) ** 2) / GROUP_ORDER)
    return abs(lhs - rhs)


def parseval_check(f: ArrayLike, f_hat: ArrayLike | None = None, *, atol: float = 1e-10, rtol: float = 1e-10) -> bool:
    arr = _as_group_array(f)
    spectrum = dft(arr) if f_hat is None else _as_group_array(f_hat)
    lhs = np.sum(np.abs(arr) ** 2)
    rhs = np.sum(np.abs(spectrum) ** 2) / GROUP_ORDER
    return bool(np.isclose(lhs, rhs, atol=atol, rtol=rtol))


def character_inner_product(k1: Sequence[int], k2: Sequence[int]) -> complex:
    a = _validate_frequency(k1)
    b = _validate_frequency(k2)
    product = 1 + 0j
    for x, y, n in zip(a, b, GROUP_SHAPE):
        d = (y - x) % n
        if d == 0:
            factor = complex(n)
        else:
            roots = np.exp(2j * np.pi * d * np.arange(n) / n)
            factor = complex(np.sum(roots))
        product *= factor
    return product


def orthogonality_check(k1: Sequence[int], k2: Sequence[int], *, atol: float = 1e-9) -> bool:
    a, b = _validate_frequency(k1), _validate_frequency(k2)
    expected = GROUP_ORDER if a == b else 0.0
    return abs(character_inner_product(a, b) - expected) <= atol


def power_spectrum(f: ArrayLike) -> NDArray[np.float64]:
    return np.abs(dft(f)) ** 2


def laplacian_spectrum(adjacency: ArrayLike | None = None) -> NDArray[np.float64]:
    """Laplacian eigenvalues.

    Without an adjacency matrix, uses the exact Cartesian-product spectrum of
    C_360 □ K_2 □ C_5 □ C_9. A supplied adjacency matrix is handled numerically.
    """
    if adjacency is not None:
        a = np.asarray(adjacency, dtype=float)
        if a.ndim != 2 or a.shape[0] != a.shape[1]:
            raise HVEError("adjacency must be square")
        if not np.allclose(a, a.T):
            raise HVEError("adjacency must be symmetric")
        lap = np.diag(np.sum(a, axis=1)) - a
        return np.linalg.eigvalsh(lap)
    cycle = lambda n: 2.0 - 2.0 * np.cos(2.0 * np.pi * np.arange(n) / n)
    values = (
        cycle(THETA_CARD)[:, None, None, None]
        + np.array([0.0, 2.0])[None, :, None, None]
        + cycle(TAU_CARD)[None, None, :, None]
        + cycle(PHI_CARD)[None, None, None, :]
    )
    return np.sort(values.reshape(-1))


def harmonic_modes(n: int) -> list[NDArray[np.complex128]]:
    if not isinstance(n, int) or isinstance(n, bool) or n < 0:
        raise HVEError("n must be a nonnegative integer")
    eigenvalues = []
    cyc = lambda k, m: 2.0 - 2.0 * math.cos(2.0 * math.pi * k / m)
    for k in np.ndindex(GROUP_SHAPE):
        value = cyc(k[0], THETA_CARD) + (0.0 if k[1] == 0 else 2.0) + cyc(k[2], TAU_CARD) + cyc(k[3], PHI_CARD)
        eigenvalues.append((value, k))
    eigenvalues.sort(key=lambda item: (item[0], item[1]))
    grids = np.indices(GROUP_SHAPE)
    modes = []
    for _, k in eigenvalues[:n]:
        phase = sum(k[i] * grids[i] / GROUP_SHAPE[i] for i in range(4))
        modes.append(np.exp(2j * np.pi * phase) / math.sqrt(GROUP_ORDER))
    return modes

# Public roots of unity for reproducible inspection and optimized downstream code.
ROOTS_360 = np.exp(2j * np.pi * np.arange(THETA_CARD) / THETA_CARD)
ROOTS_2 = np.exp(2j * np.pi * np.arange(S_CARD) / S_CARD)
ROOTS_5 = np.exp(2j * np.pi * np.arange(TAU_CARD) / TAU_CARD)
ROOTS_9 = np.exp(2j * np.pi * np.arange(PHI_CARD) / PHI_CARD)
