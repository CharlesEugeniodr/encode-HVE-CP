"""HVE-128 episodic-context tokens and deterministic similarity.

This module turns the attached CONDESSA episodic-memory prototype into a
profile with explicit validation.  HVE-128 stores the compact context token;
the memory content and timestamp remain ordinary database fields.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import sqrt
import time
from typing import Iterable
import uuid

from .core import HVEError
from .efq128 import HVE128Fields, MODE_HVE128, efq128_from_bytes

EPISODIC_PROFILE = "efq128/episodic-context/v1"
EPISODIC_EXTRA_TAG = 0x45504931  # ASCII "EPI1"
DIRECTION_CARDINALITY = 112
DIRECTION_HALF_CYCLE = DIRECTION_CARDINALITY // 2
MAX_RGB_DISTANCE = sqrt(3 * (255**2))

CARDINAL_DIRECTIONS = {
    "N": 0,
    "NE": 14,
    "E": 28,
    "SE": 42,
    "S": 56,
    "SW": 70,
    "W": 84,
    "NW": 98,
}


def _bounded_float(name: str, value: float, lower: float, upper: float) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise HVEError(f"{name} must be numeric")
    result = float(value)
    if not lower <= result <= upper:
        raise HVEError(f"{name} must be in [{lower}, {upper}]")
    return result


def map_direction_to_hve(cardinal_direction: str) -> int:
    if not isinstance(cardinal_direction, str):
        raise HVEError("cardinal direction must be a string")
    key = cardinal_direction.strip().upper()
    try:
        return CARDINAL_DIRECTIONS[key]
    except KeyError as exc:
        supported = ", ".join(CARDINAL_DIRECTIONS)
        raise HVEError(f"unsupported direction; expected one of: {supported}") from exc


def map_valence_arousal_to_rgb(valence: float, arousal: float) -> int:
    """Reproduce the attached deterministic CONDESSA RGB heuristic."""

    valence = _bounded_float("valence", valence, -1.0, 1.0)
    arousal = _bounded_float("arousal", arousal, 0.0, 1.0)
    if valence > 0:
        red = int(255 * valence)
        green = int(255 * arousal)
        blue = 0
    elif valence < 0:
        red = 0
        green = int(255 * arousal)
        blue = int(255 * abs(valence))
    else:
        red = green = blue = int(255 * (1.0 - arousal))
    return (red << 16) | (green << 8) | blue


def rgb_channels(rgb: int) -> tuple[int, int, int]:
    if not isinstance(rgb, int) or isinstance(rgb, bool) or not 0 <= rgb < (1 << 24):
        raise HVEError("rgb must be a 24-bit integer")
    return (rgb >> 16) & 0xFF, (rgb >> 8) & 0xFF, rgb & 0xFF


def direction_similarity(a: int, b: int) -> float:
    """Continuous similarity on the 112-position direction cycle."""

    for name, value in (("direction a", a), ("direction b", b)):
        if not isinstance(value, int) or isinstance(value, bool):
            raise HVEError(f"{name} must be an integer")
        if not 0 <= value < DIRECTION_CARDINALITY:
            raise HVEError(f"{name} must be in [0, 111]")
    delta = abs(a - b)
    circular_distance = min(delta, DIRECTION_CARDINALITY - delta)
    return 1.0 - (circular_distance / DIRECTION_HALF_CYCLE)


def rgb_similarity(a: int, b: int) -> float:
    """One minus normalized Euclidean distance in the RGB cube."""

    ar, ag, ab = rgb_channels(a)
    br, bg, bb = rgb_channels(b)
    distance = sqrt((ar - br) ** 2 + (ag - bg) ** 2 + (ab - bb) ** 2)
    return 1.0 - (distance / MAX_RGB_DISTANCE)


def encode_episodic_context(
    cardinal_direction: str,
    valence: float,
    arousal: float,
) -> bytes:
    fields = HVE128Fields(
        mode=MODE_HVE128,
        theta=0,
        micro=0,
        sigma=1,
        tau=0,
        direction=map_direction_to_hve(cardinal_direction),
        rgb=map_valence_arousal_to_rgb(valence, arousal),
        extra=EPISODIC_EXTRA_TAG,
    )
    return fields.to_bytes()


def decode_episodic_context(data: bytes) -> HVE128Fields:
    fields = efq128_from_bytes(data)
    if (
        fields.mode != MODE_HVE128
        or fields.theta != 0
        or fields.micro != 0
        or fields.sigma != 1
        or fields.tau != 0
        or fields.extra != EPISODIC_EXTRA_TAG
        or fields.reserved_a
        or fields.reserved_c
        or fields.reserved_b
    ):
        raise HVEError("token is not canonical HVE-128 episodic-context/v1")
    return fields


def episodic_similarity(
    query: bytes,
    candidate: bytes,
    *,
    direction_weight: float = 0.5,
) -> float:
    weight = _bounded_float("direction_weight", direction_weight, 0.0, 1.0)
    query_fields = decode_episodic_context(query)
    candidate_fields = decode_episodic_context(candidate)
    return (
        weight * direction_similarity(query_fields.direction, candidate_fields.direction)
        + (1.0 - weight) * rgb_similarity(query_fields.rgb, candidate_fields.rgb)
    )


@dataclass(frozen=True, slots=True)
class EpisodicMemoryRecord:
    memory_id: str
    content: str
    hve_vector: bytes
    timestamp: float
    internal_state_id: str | None = None


@dataclass(frozen=True, slots=True)
class EpisodicSearchResult:
    record: EpisodicMemoryRecord
    similarity_score: float
    direction_similarity: float
    rgb_similarity: float


class EpisodicMemory:
    """Dependency-free reference store for the episodic token profile."""

    def __init__(self) -> None:
        self._memories: dict[str, EpisodicMemoryRecord] = {}

    def store_memory(
        self,
        content: str,
        *,
        cardinal_direction: str,
        valence: float,
        arousal: float,
        internal_state_id: str | None = None,
        memory_id: str | None = None,
        timestamp: float | None = None,
    ) -> str:
        if not isinstance(content, str):
            raise HVEError("content must be a string")
        resolved_id = memory_id or str(uuid.uuid4())
        if resolved_id in self._memories:
            raise HVEError(f"memory id already exists: {resolved_id}")
        resolved_timestamp = time.time() if timestamp is None else float(timestamp)
        record = EpisodicMemoryRecord(
            memory_id=resolved_id,
            content=content,
            hve_vector=encode_episodic_context(
                cardinal_direction,
                valence,
                arousal,
            ),
            timestamp=resolved_timestamp,
            internal_state_id=internal_state_id,
        )
        self._memories[resolved_id] = record
        return resolved_id

    def records(self) -> tuple[EpisodicMemoryRecord, ...]:
        return tuple(self._memories.values())

    def retrieve_by_hve_similarity(
        self,
        query_hve_vector: bytes,
        *,
        limit: int = 5,
        direction_weight: float = 0.5,
    ) -> list[EpisodicSearchResult]:
        if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
            raise HVEError("limit must be a positive integer")
        weight = _bounded_float("direction_weight", direction_weight, 0.0, 1.0)
        query = decode_episodic_context(query_hve_vector)
        results: list[EpisodicSearchResult] = []
        for record in self._memories.values():
            candidate = decode_episodic_context(record.hve_vector)
            direction_score = direction_similarity(query.direction, candidate.direction)
            rgb_score = rgb_similarity(query.rgb, candidate.rgb)
            results.append(
                EpisodicSearchResult(
                    record=record,
                    similarity_score=(
                        weight * direction_score + (1.0 - weight) * rgb_score
                    ),
                    direction_similarity=direction_score,
                    rgb_similarity=rgb_score,
                )
            )
        results.sort(
            key=lambda result: (-result.similarity_score, result.record.memory_id)
        )
        return results[:limit]

    def extend(self, records: Iterable[EpisodicMemoryRecord]) -> None:
        for record in records:
            if not isinstance(record, EpisodicMemoryRecord):
                raise HVEError("all records must be EpisodicMemoryRecord instances")
            decode_episodic_context(record.hve_vector)
            if record.memory_id in self._memories:
                raise HVEError(f"memory id already exists: {record.memory_id}")
            self._memories[record.memory_id] = record

