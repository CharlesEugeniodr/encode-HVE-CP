from __future__ import annotations

import json
import click

from . import __version__
from .angular import circular_distance, neighborhood, shortest_path
from .benchmark import benchmark_core
from .chromatic import HVEColor, decode_chi, encode_chi
from .comparative import (
    load_corpora,
    load_semantic_pairs,
    run_comparison,
    write_comparison_artifacts,
)
from .core import BASE_CARDINALITY, BASE_RESERVED_WORDS, HVEError, HVEState, decode_base, encode_base
from .protocol import pack_chi40
from .visualize import angular_map, harmonic_plot


@click.group()
@click.version_option(__version__)
def main() -> None:
    """HVE Engine command-line interface."""


@main.command()
def validate() -> None:
    seen = bytearray(BASE_CARDINALITY)
    failures = 0
    for index in range(BASE_CARDINALITY):
        state = decode_base(index)
        recovered = encode_base(state)
        if recovered != index or seen[recovered]:
            failures += 1
        seen[recovered] = 1
    reserved_rejected = 0
    for index in range(BASE_CARDINALITY, 1 << 15):
        try:
            decode_base(index)
        except HVEError:
            reserved_rejected += 1
    result = {
        "valid_states": sum(seen),
        "reserved_rejected": reserved_rejected,
        "expected_reserved": BASE_RESERVED_WORDS,
        "failures": failures,
    }
    click.echo(json.dumps(result, indent=2))
    if failures or reserved_rejected != BASE_RESERVED_WORDS:
        raise click.ClickException("validation failed")


@main.command()
@click.option("--theta", type=int, required=True)
@click.option("--s", type=int, required=True)
@click.option("--tau", type=int, required=True)
@click.option("--phi", type=int, required=True)
@click.option("--color", type=str, default=None, help="RGB as R,G,B")
def encode(theta: int, s: int, tau: int, phi: int, color: str | None) -> None:
    try:
        state = HVEState(theta, s, tau, phi)
        if color is None:
            click.echo(str(encode_base(state)))
            return
        parts = [int(x.strip()) for x in color.split(",")]
        if len(parts) != 3:
            raise HVEError("color must be R,G,B")
        c = HVEColor.rgb(*parts)
        click.echo(json.dumps({"chi_index": encode_chi(state, c), "chi40_hex": pack_chi40(state, c).hex()}))
    except (HVEError, ValueError) as exc:
        raise click.ClickException(str(exc)) from exc


@main.command(name="decode")
@click.argument("index", type=int)
@click.option("--chi", is_flag=True, help="Decode an HVE-chi monolithic index")
def decode_cmd(index: int, chi: bool) -> None:
    try:
        if chi:
            state, color = decode_chi(index)
            click.echo(json.dumps({"state": state.__dict__ if hasattr(state, "__dict__") else {"theta": state.theta, "s": state.s, "tau": state.tau, "phi": state.phi}, "color": {"present": color.present, "r": color.r, "g": color.g, "b": color.b}}, indent=2))
        else:
            state = decode_base(index)
            click.echo(json.dumps({"theta": state.theta, "s": state.s, "tau": state.tau, "phi": state.phi}))
    except HVEError as exc:
        raise click.ClickException(str(exc)) from exc


@main.command(name="angular-distance")
@click.argument("theta1", type=int)
@click.argument("theta2", type=int)
def angular_distance_cmd(theta1: int, theta2: int) -> None:
    path = shortest_path(theta1, theta2)
    click.echo(json.dumps({"distance": circular_distance(theta1, theta2), "direction": path.direction, "clockwise": path.clockwise, "counterclockwise": path.counterclockwise}))


@main.command(name="neighborhood")
@click.argument("theta", type=int)
@click.option("--radius", type=int, default=1)
def neighborhood_cmd(theta: int, radius: int) -> None:
    click.echo(json.dumps(sorted(neighborhood(theta, radius))))


@main.command()
@click.option("--iterations", type=int, default=100_000, show_default=True)
@click.option("--repetitions", type=int, default=7, show_default=True)
def benchmark(iterations: int, repetitions: int) -> None:
    result = benchmark_core(iterations, repetitions)
    click.echo(json.dumps(result.__dict__ if hasattr(result, "__dict__") else {k: getattr(result, k) for k in result.__dataclass_fields__}, indent=2))


@main.command(name="compare")
@click.argument(
    "corpus",
    nargs=-1,
    type=click.Path(exists=True, dir_okay=False, path_type=str),
)
@click.option(
    "--output-dir",
    type=click.Path(file_okay=False, path_type=str),
    default="comparison-results",
    show_default=True,
)
@click.option("--repetitions", type=click.IntRange(min=1), default=9, show_default=True)
@click.option(
    "--target-characters",
    type=click.IntRange(min=1),
    default=100_000,
    show_default=True,
)
@click.option(
    "--bootstrap-resamples",
    type=click.IntRange(min=0),
    default=1_000,
    show_default=True,
)
@click.option("--error-trials", type=click.IntRange(min=1), default=256, show_default=True)
@click.option("--seed", type=int, default=20260728, show_default=True)
@click.option(
    "--token-vocabulary-size",
    type=click.IntRange(min=1, max=32_400),
    default=None,
    help="Enable held-out BPE token analysis with this target vocabulary size.",
)
@click.option(
    "--token-training-fraction",
    type=click.FloatRange(min=0.1, max=0.9),
    default=0.8,
    show_default=True,
)
@click.option(
    "--token-minimum-pair-frequency",
    type=click.IntRange(min=2),
    default=2,
    show_default=True,
)
@click.option(
    "--token-maximum-characters",
    type=click.IntRange(min=2),
    default=32,
    show_default=True,
)
@click.option(
    "--semantic-pairs",
    type=click.Path(exists=True, dir_okay=False, path_type=str),
    default=None,
)
@click.option("--no-timings", is_flag=True)
@click.option("--no-error-analysis", is_flag=True)
@click.option("--no-harmonic-benchmark", is_flag=True)
def compare_cmd(
    corpus: tuple[str, ...],
    output_dir: str,
    repetitions: int,
    target_characters: int,
    bootstrap_resamples: int,
    error_trials: int,
    seed: int,
    token_vocabulary_size: int | None,
    token_training_fraction: float,
    token_minimum_pair_frequency: int,
    token_maximum_characters: int,
    semantic_pairs: str | None,
    no_timings: bool,
    no_error_analysis: bool,
    no_harmonic_benchmark: bool,
) -> None:
    """Compare HVE, UTF-8, and fixed 21-bit binary on identical corpora."""

    try:
        corpora = load_corpora(corpus) if corpus else None
        pairs = load_semantic_pairs(semantic_pairs) if semantic_pairs else None
        report = run_comparison(
            corpora,
            semantic_pairs=pairs,
            token_vocabulary_size=token_vocabulary_size,
            token_training_fraction=token_training_fraction,
            token_minimum_pair_frequency=token_minimum_pair_frequency,
            token_maximum_characters=token_maximum_characters,
            repetitions=repetitions,
            target_characters=target_characters,
            bootstrap_resamples=bootstrap_resamples,
            error_trials=error_trials,
            seed=seed,
            include_timings=not no_timings,
            include_error_analysis=not no_error_analysis,
            include_harmonic_benchmark=not no_harmonic_benchmark,
        )
        paths = write_comparison_artifacts(report, output_dir)
    except (HVEError, OSError, UnicodeError) as exc:
        raise click.ClickException(str(exc)) from exc
    click.echo(
        json.dumps(
            {
                "dominance_certificate": report["dominance_certificate"]["passed"],
                "corpora": len(report["corpora"]),
                "artifacts": paths,
            },
            indent=2,
        )
    )


@main.command()
@click.option("--mode", type=click.Choice(["angular", "harmonic"]), required=True)
@click.option("--output", type=click.Path(), required=True)
def visualize(mode: str, output: str) -> None:
    path = angular_map(output) if mode == "angular" else harmonic_plot(output)
    click.echo(str(path))


if __name__ == "__main__":
    main()
