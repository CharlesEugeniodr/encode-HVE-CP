"""Canonical BASE positions and conservative symbol assignments.

The architecture defines 720 symbolic positions independently of a complete Unicode
mapping. Version 1.0 exposes all positions and assigns only mappings established by
the public category layout: digits, basic Latin letters, and three spacing controls.
Additional mappings must be introduced by a versioned canonical-table release.
"""

from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path

from .core import HVEError, HVEState


@dataclass(frozen=True, slots=True)
class CanonicalPosition:
    theta: int
    s: int
    category: str
    symbol: str | None

    @property
    def state(self) -> HVEState:
        return HVEState(self.theta, self.s, 0, 0)


CATEGORY_RANGES_T_PLUS = (
    (0, 9, "digits"),
    (10, 35, "uppercase_latin"),
    (36, 61, "lowercase_latin"),
    (62, 92, "punctuation"),
    (93, 118, "portuguese_extension"),
    (119, 121, "spacing"),
    (122, 145, "currencies"),
    (146, 193, "greek"),
    (194, 213, "arrows"),
    (214, 233, "geometric_symbols"),
    (234, 253, "typographic_symbols"),
    (254, 293, "extended_latin"),
    (294, 333, "cyrillic"),
    (334, 349, "superscripts_subscripts"),
    (350, 359, "pictograms"),
)


def _category(theta: int, s: int) -> str:
    if s == 1:
        return "t_minus_unassigned"
    for start, end, name in CATEGORY_RANGES_T_PLUS:
        if start <= theta <= end:
            return name
    raise AssertionError("uncovered theta")


def _confirmed_symbol(theta: int, s: int) -> str | None:
    if s != 0:
        return None
    if 0 <= theta <= 9:
        return str(theta)
    if 10 <= theta <= 35:
        return chr(ord("A") + theta - 10)
    if 36 <= theta <= 61:
        return chr(ord("a") + theta - 36)
    if theta == 119:
        return " "
    if theta == 120:
        return "\t"
    if theta == 121:
        return "\n"
    return None


def canonical_positions() -> tuple[CanonicalPosition, ...]:
    return tuple(
        CanonicalPosition(theta, s, _category(theta, s), _confirmed_symbol(theta, s))
        for theta in range(360)
        for s in range(2)
    )


def symbol_to_position() -> dict[str, CanonicalPosition]:
    return {position.symbol: position for position in canonical_positions() if position.symbol is not None}


def position_for_symbol(symbol: str) -> CanonicalPosition:
    try:
        return symbol_to_position()[symbol]
    except KeyError as exc:
        raise HVEError("symbol is not assigned in canonical table version 1.0") from exc


def export_json(path: str | Path) -> None:
    records = [
        {
            "theta": p.theta,
            "s": p.s,
            "tau": 0,
            "phi": 0,
            "category": p.category,
            "symbol": p.symbol,
        }
        for p in canonical_positions()
    ]
    Path(path).write_text(json.dumps(records, ensure_ascii=False, indent=2), encoding="utf-8")
