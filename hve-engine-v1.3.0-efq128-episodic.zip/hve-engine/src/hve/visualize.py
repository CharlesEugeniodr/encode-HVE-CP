"""Optional visualizations. Matplotlib is imported lazily."""

from __future__ import annotations

from pathlib import Path
import numpy as np

from .core import HVEError
from .harmonic import ROOTS_360


def _plt():
    try:
        import matplotlib.pyplot as plt
    except ImportError as exc:
        raise HVEError("install hve-engine[visualization] to use visualization") from exc
    return plt


def angular_map(output: str | Path) -> Path:
    plt = _plt()
    theta = np.linspace(0, 2 * np.pi, 360, endpoint=False)
    fig = plt.figure(figsize=(8, 8))
    ax = fig.add_subplot(111, projection="polar")
    ax.scatter(theta, np.ones_like(theta), s=8)
    ax.set_title("HVE-720 angular factor C360")
    path = Path(output)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path


def harmonic_plot(output: str | Path, k: int = 4) -> Path:
    plt = _plt()
    values = ROOTS_360 ** k
    fig, ax = plt.subplots(figsize=(10, 4))
    ax.plot(np.arange(360), values.real)
    ax.set_xlabel("theta")
    ax.set_ylabel(f"Re chi_{k}(theta)")
    ax.set_title("Angular harmonic character")
    path = Path(output)
    fig.savefig(path, dpi=180, bbox_inches="tight")
    plt.close(fig)
    return path
