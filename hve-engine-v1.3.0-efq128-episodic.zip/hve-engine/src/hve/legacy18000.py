"""Compatibility model for the legacy 18,000-state HVE-Lang v1.1 table."""

from __future__ import annotations

import csv
from dataclasses import dataclass
import hashlib
from math import ceil, log2
from pathlib import Path
from typing import Iterator

from .core import HVEError, HVEState, s_to_sigma, sigma_to_s
from .profile_6480 import from_semantic, to_semantic

LEGACY_THETA_CARD = 360
LEGACY_SIGMA_CARD = 2
LEGACY_TAU_LEVELS = (-2, -1, 0, 1, 2)
LEGACY_PHI_LEVELS = (0, 1, 2, 3, 4)
LEGACY18000_CARDINALITY = (
    LEGACY_THETA_CARD
    * LEGACY_SIGMA_CARD
    * len(LEGACY_TAU_LEVELS)
    * len(LEGACY_PHI_LEVELS)
)
LEGACY18000_MIN_BITS = ceil(log2(LEGACY18000_CARDINALITY))

EXPECTED_HEADER = (
    "ID_Angular",
    "Estado_Angular",
    "θ (Theta)",
    "σ (Sigma)",
    "τ (Tau)",
    "φ (Phi)",
    "Estado_Encoder",
    "Bits_Angular",
    "Bits_Cromatico",
    "Bits_Total_Minimo",
    "Tamanho_HVE_Bytes",
    "Simbolos_em_200_Bytes",
    "Projeto",
    "Autor",
    "Empresa",
    "CNPJ",
)


@dataclass(frozen=True, slots=True)
class Legacy18000State:
    theta: int
    sigma: int
    tau_level: int
    phi_level: int

    def validate(self) -> None:
        if not 0 <= self.theta < LEGACY_THETA_CARD:
            raise HVEError("legacy theta must be in [0, 359]")
        sigma_to_s(self.sigma)
        if self.tau_level not in LEGACY_TAU_LEVELS:
            raise HVEError(f"legacy tau_level must be one of {LEGACY_TAU_LEVELS}")
        if self.phi_level not in LEGACY_PHI_LEVELS:
            raise HVEError(f"legacy phi_level must be one of {LEGACY_PHI_LEVELS}")


@dataclass(frozen=True, slots=True)
class Legacy18000CsvAudit:
    rows: int
    unique_states: int
    sequential_indices: bool
    state_labels_match: bool
    sha256: str
    warnings: tuple[str, ...]

    @property
    def passed(self) -> bool:
        return (
            self.rows == LEGACY18000_CARDINALITY
            and self.unique_states == LEGACY18000_CARDINALITY
            and self.sequential_indices
            and self.state_labels_match
        )


def encode_legacy18000(state: Legacy18000State) -> int:
    state.validate()
    s = sigma_to_s(state.sigma)
    tau = LEGACY_TAU_LEVELS.index(state.tau_level)
    phi = LEGACY_PHI_LEVELS.index(state.phi_level)
    return (
        phi * (len(LEGACY_TAU_LEVELS) * LEGACY_SIGMA_CARD * LEGACY_THETA_CARD)
        + tau * (LEGACY_SIGMA_CARD * LEGACY_THETA_CARD)
        + s * LEGACY_THETA_CARD
        + state.theta
    )


def decode_legacy18000(index: int) -> Legacy18000State:
    if not isinstance(index, int) or isinstance(index, bool):
        raise HVEError("legacy index must be an integer")
    if not 0 <= index < LEGACY18000_CARDINALITY:
        raise HVEError("legacy index must be in [0, 17999]")
    theta = index % LEGACY_THETA_CARD
    q1 = index // LEGACY_THETA_CARD
    s = q1 % LEGACY_SIGMA_CARD
    q2 = q1 // LEGACY_SIGMA_CARD
    tau_index = q2 % len(LEGACY_TAU_LEVELS)
    phi_index = q2 // len(LEGACY_TAU_LEVELS)
    return Legacy18000State(
        theta=theta,
        sigma=s_to_sigma(s),
        tau_level=LEGACY_TAU_LEVELS[tau_index],
        phi_level=LEGACY_PHI_LEVELS[phi_index],
    )


def migrate_to_hve32400(state: Legacy18000State) -> HVEState:
    """Inject the legacy table into the nonnegative-plane subset of HVE-32,400.

    A legacy tau level is interpreted in 15-degree increments.  Thus -2..2 maps
    to -30, -15, 0, +15, +30 degrees.  Legacy phi levels 0..4 map to
    base, +15, +30, +45, +60 degrees.
    """

    state.validate()
    return from_semantic(
        theta=state.theta,
        sigma=state.sigma,
        tau_degrees=state.tau_level * 15,
        phi_degrees=state.phi_level * 15,
    )


def migrate_from_hve32400(state: HVEState) -> Legacy18000State:
    semantic = to_semantic(state)
    if semantic.tau_degrees % 15 != 0:
        raise HVEError("HVE tau state is outside the legacy 15-degree grid")
    tau_level = semantic.tau_degrees // 15
    if tau_level not in LEGACY_TAU_LEVELS:
        raise HVEError("HVE tau state is outside the legacy range")
    if semantic.phi_degrees not in (0, 15, 30, 45, 60):
        raise HVEError("negative HVE phi planes do not exist in the legacy table")
    return Legacy18000State(
        theta=semantic.theta,
        sigma=semantic.sigma,
        tau_level=tau_level,
        phi_level=semantic.phi_degrees // 15,
    )


def _rows_from_wrapped_csv(path: str | Path) -> Iterator[dict[str, str]]:
    """Read the uploaded CSV, whose semicolon rows were wrapped by a CSV exporter."""

    with Path(path).open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.reader(handle)
        first = next(reader)
        header = tuple(first[0].split(";"))
        if header != EXPECTED_HEADER:
            raise HVEError("unexpected legacy HVE-Lang CSV header")
        for raw in reader:
            nonempty = [field for field in raw if field]
            if not nonempty:
                continue
            reconstructed = ",".join(nonempty)
            values = reconstructed.split(";")
            if len(values) != len(header):
                raise HVEError("malformed wrapped legacy CSV row")
            yield dict(zip(header, values))


def validate_legacy18000_csv(path: str | Path) -> Legacy18000CsvAudit:
    source = Path(path)
    digest = hashlib.sha256(source.read_bytes()).hexdigest()
    seen: set[Legacy18000State] = set()
    sequential = True
    labels_match = True
    rows = 0
    declared_angular_bits: set[str] = set()
    declared_color_bits: set[str] = set()
    declared_total_bits: set[str] = set()
    declared_bytes: set[str] = set()

    for rows, row in enumerate(_rows_from_wrapped_csv(source), start=1):
        state = Legacy18000State(
            theta=int(row["θ (Theta)"]),
            sigma=int(row["σ (Sigma)"]),
            tau_level=int(row["τ (Tau)"]),
            phi_level=int(row["φ (Phi)"]),
        )
        state.validate()
        index = int(row["ID_Angular"])
        sequential = sequential and index == rows - 1 and encode_legacy18000(state) == index
        expected_label = (
            f"({state.theta}°,{state.sigma},{state.tau_level}, {state.phi_level})"
        )
        labels_match = labels_match and row["Estado_Angular"] == expected_label
        seen.add(state)
        declared_angular_bits.add(row["Bits_Angular"])
        declared_color_bits.add(row["Bits_Cromatico"])
        declared_total_bits.add(row["Bits_Total_Minimo"])
        declared_bytes.add(row["Tamanho_HVE_Bytes"])

    warnings: list[str] = []
    if declared_angular_bits != {"70"}:
        warnings.append("Bits_Angular is not constant at the declared value 70.")
    if declared_angular_bits == {"70"} and LEGACY18000_MIN_BITS == 15:
        warnings.append(
            "The 18,000-state angular index needs 15 bits, not 70 bits, "
            "when Bits_Angular is interpreted as a minimum state index width."
        )
    if declared_color_bits == {"41"} and declared_total_bits == {"40,34"}:
        warnings.append(
            "Bits_Total_Minimo=40.34 is smaller than the declared 41-bit color "
            "field and cannot be their combined fixed-width minimum."
        )
    if declared_bytes == {"25"} and declared_angular_bits == {"70"} and declared_color_bits == {"41"}:
        warnings.append(
            "25 bytes equals 200 bits, which is not derived from the declared "
            "70+41=111 fixed bits without an additional framing specification."
        )

    audit = Legacy18000CsvAudit(
        rows=rows,
        unique_states=len(seen),
        sequential_indices=sequential,
        state_labels_match=labels_match,
        sha256=digest,
        warnings=tuple(warnings),
    )
    if not audit.passed:
        raise HVEError(f"legacy HVE-Lang CSV validation failed: {audit}")
    return audit
