# Contributing

1. Open an issue describing the proposed change.
2. Preserve backward compatibility unless a protocol-version change is declared.
3. Add tests for every behavioral change.
4. Do not describe deterministic or rule-based mapping as trained artificial intelligence.
5. Do not assign semantic meaning to `theta`, `s`, `tau`, or `phi` without a versioned mapping specification.
6. Run `pytest -q` and `hve validate` before submitting a pull request.
