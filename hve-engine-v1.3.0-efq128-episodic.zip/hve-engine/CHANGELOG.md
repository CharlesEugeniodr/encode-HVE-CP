# Changelog

## 1.3.0 — 2026-07-28

- Audited the subsequently supplied historical `hve_toolkit_128.py`.
- Proved with a golden vector that its effective wire layout is not compatible
  with canonical EFQ128: direction is at 87..81, RGB high at 80..65, and bit 64
  is an unused gap.
- Added an exact legacy decoder/encoder and explicit semantic transcode rather
  than silently changing historical bytes.
- Isolated the historical signed-tau masking and non-injective `EXTRA`
  `(phi,tau)` packing defects.
- Confirmed that the supplied toolkit file contains no HVE-Zeta implementation;
  the independent 137,000-state engine mapping remains separately versioned.
- Added a namespaced HVE-128 episodic-context profile, circular direction
  similarity, normalized Euclidean RGB similarity, and reference memory store.
- Replaced the SQL similarity placeholder with a legacy-aware PostgreSQL
  migration and real deterministic ranking.

## 1.2.0 — 2026-07-28

- Validated the supplied 32,400-row HVE-6480+tau table against the document
  mixed-radix layout.
- Formalized `6480 = 360 * 2 * 9` and `32400 = 6480 * 5`.
- Added semantic degree labels for tau `(0, +15, -15, +30, -30)` and phi
  `(base, +15, +30, +45, +60, -15, -30, -45, -60)`.
- Added an exact parser for the wrapped 18,000-row HVE-Lang v1.1 CSV and an
  injective migration into the nonnegative-plane subset of HVE-32,400.
- Added HVE-128 EFQ v1 pack/unpack.  The source's 7-bit direction field is
  normalized to bits 86..80 and the otherwise missing bit 87 is explicit.
- Corrected the HVE-128 semantic payload statement: the declared field product
  has entropy between 62 and 63 bits and therefore requires a 63-bit minimum
  fixed word, while the complete EFQ envelope remains 128 bits.
- Added a versioned HVE-Zeta Sigma-0 micro-fast mapping for 137,000 concepts,
  independently testable without the unavailable historical toolkit.
- Added exhaustive dependency-light profile validation.

## 1.1.0 — 2026-07-28

- Reproducible HVE × UTF-8 × Binary21 comparison engine.
- Versioned LAB-720 v0 profile with 169 scalar assignments transcribed from the
  original `HVE.docx` tables; reserve labels are not misclassified as symbols.
- Universal HVE text profile with explicit Unicode-scalar fallback.
- Lossless raw-binary and Unicode embeddings with common CRC-32 framing.
- Corpus coverage, payload/framing cost, zlib reference cost, deterministic
  timing, bootstrap confidence intervals, and single-bit error propagation.
- Executable structural-dominance certificate with delimited claim scope.
- Explicit crosswalk between Engine 1.0 and 2025-document mixed-radix layouts.
- CLI and standalone runner producing JSON, CSV, and Markdown evidence.

## 1.0.0 — 2026-07-19

- Canonical HVE-720 BASE state model and mixed-radix bijection.
- Finite Abelian group operations on `Z_360 × Z_2 × Z_5 × Z_9`.
- Circular Angular State Engine on `C_360`.
- Harmonic Engine with characters, separable DFT/IDFT, convolution, Parseval checks, and analytic graph-Laplacian spectrum.
- HVE-χ pointed chromatic extension and BASE15/CHI39/CHI40 serialization.
- HVE1 framed protocol with CRC-32.
- Deterministic and rule-based mapping interfaces; no trained AI model.
- CLI, examples, tests, benchmark harness, documentation, C reference core, and CI workflow.

The validated core was reorganized from the earlier HVE Embedded Reference implementation. Historical archives remain separate from this canonical repository.
