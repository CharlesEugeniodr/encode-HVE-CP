# HVE Engine 1.3

HVE Engine is the canonical executable implementation of HVE-720, a finite symbolic-state architecture over

`G = Z_360 × Z_2 × Z_5 × Z_9`.

It includes:

- exact BASE encoding and decoding for 32,400 states;
- explicit rejection of the 368 unused 15-bit words;
- modular group operations;
- circular geometry on `C_360`;
- finite-group characters and DFT/IDFT over `G`;
- HVE-χ, which distinguishes no color from RGB black;
- BASE15, CHI39, CHI40, and HVE1 framing;
- deterministic/rule-based mapping interfaces;
- a reproducible HVE × UTF-8 × fixed Binary21 comparison engine;
- versioned support for the original LAB-720 v0 scalar assignments;
- an explicit crosswalk for the two documented BASE mixed-radix layouts;
- a validated semantic HVE-6480+tau profile proving `6480 * 5 = 32400`;
- an injective migration from the legacy 18,000-state HVE-Lang table;
- an executable HVE-128 EFQ v1 layout with the formerly unaccounted bit 87
  explicitly reserved;
- exact decoding and semantic transcoding for the incompatible wire layout
  actually emitted by the attached historical `hve_toolkit_128.py`;
- a canonical HVE-128 episodic-context profile with cyclic-direction and RGB
  similarity plus a PostgreSQL migration;
- an independently versioned HVE-Zeta Sigma-0 injection for 137,000 symbols;
- CLI, tests, examples, benchmark scripts, and a portable C core.

## Scientific boundary

The core is a finite computational architecture. The angular coordinate is a position in `Z_360`; it is not latitude or longitude. The word “geodesic” means shortest-path distance on the cycle graph `C_360`. The mapping layer contains no trained AI model in version 1.0.

## Install

```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -e ".[dev,visualization]"
```

## Quick start

```bash
hve validate
hve encode --theta 45 --s 0 --tau 2 --phi 3
hve decode 4071
hve angular-distance 359 0
hve neighborhood 0 --radius 3
hve benchmark --iterations 10000
hve compare --output-dir comparison-results
hve compare corpus-a.txt corpus-b.txt --output-dir comparison-results
PYTHONPATH=src python benchmarks/selftest_profiles.py \
  --hve6480-csv datasets/canonical/hve6480_tau_states_document_v3.csv
```

Python:

```python
from hve import HVEState, encode_base, decode_base

state = HVEState(45, 0, 2, 3)
index = encode_base(state)
assert decode_base(index) == state
```

Harmonic transform:

```python
import numpy as np
from hve.harmonic import dft, idft

f = np.zeros((360, 2, 5, 9), dtype=np.complex128)
f[0, 0, 0, 0] = 1
assert np.allclose(idft(dft(f)), f)
```

## Repository status

Version 1.3 implements the computational MVP, comparison laboratory, validated
profile bridges, historical EFQ128 wire compatibility, and an executable
episodic-memory context layer.
Hardware-specific performance claims remain outside this release unless
separately measured on physical targets.

## Profile boundary

The profiles are related but not interchangeable:

- `HVE-720` is the visible theta/sigma layer.
- `HVE-6480` is `360 * 2 * 9` after adding the nine phi planes.
- `HVE-6480+tau` is `6480 * 5 = 32400`, exactly the BASE state space.
- `HVE-128 EFQ` is a separate 128-bit envelope with micro-angle, fine torsion,
  direction, RGB, metadata, and reserved fields.
- `EFQ128 canonical-v1` and `attached-toolkit legacy-v1` are distinct wire
  layouts. They must be tagged and transcoded; decoding one as the other changes
  direction and RGB.
- `HVE-128 episodic-context/v1` is a namespaced EFQ token. It ranks memories by
  circular direction and normalized Euclidean RGB similarity; it is not itself
  a learned embedding.
- `HVE-Zeta Sigma-0` is a versioned injection into the `(micro, tau)` subspace
  of HVE-128. The attached toolkit contains no Zeta implementation despite the
  separate note claiming one, so byte compatibility with that missing Zeta
  artifact is still not claimed.

## Comparison boundary

The comparison engine never collapses size, speed, coverage, error behaviour,
and structural capability into an arbitrary score. It reports:

- UTF-8;
- a fixed 21-bit Unicode-scalar binary baseline;
- LAB-720 v0 at 10 bits per mapped symbol;
- HVE-4D BASE15 at 15 bits per mapped state;
- HVE hybrid with explicit Unicode fallback.

The executable certificate proves strict HVE extension only within the declared
scope of lossless embeddings and native algebraic/geometric/harmonic structure.
It does not claim that HVE is always smaller, faster, byte-aligned, or more
widely interoperable than UTF-8.
