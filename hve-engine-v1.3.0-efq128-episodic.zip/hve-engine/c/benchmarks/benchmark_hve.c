#define _POSIX_C_SOURCE 200809L
#include "hve.h"

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

static double now_seconds(void) {
    struct timespec ts;
    if (clock_gettime(CLOCK_MONOTONIC, &ts) != 0) {
        return 0.0;
    }
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

int main(int argc, char **argv) {
    uint64_t iterations = UINT64_C(10000000);
    uint64_t i;
    volatile uint64_t checksum = 0u;
    double start, elapsed;
    hve_state_t state = {0u, 0u, 0u, 0u};
    hve_state_t decoded;
    hve_color_t color = {1u, 12u, 34u, 56u};
    hve_color_t decoded_color;

    if (argc > 1) {
        char *end = NULL;
        unsigned long long parsed = strtoull(argv[1], &end, 10);
        if (end == argv[1] || *end != '\0' || parsed == 0u) {
            fprintf(stderr, "usage: %s [iterations]\n", argv[0]);
            return EXIT_FAILURE;
        }
        iterations = (uint64_t)parsed;
    }

    start = now_seconds();
    for (i = 0u; i < iterations; ++i) {
        uint16_t index;
        state.theta = (uint16_t)(i % 360u);
        state.s = (uint8_t)(i % 2u);
        state.tau = (uint8_t)(i % 5u);
        state.phi = (uint8_t)(i % 9u);
        if (hve_base_encode(&state, &index) != HVE_OK || hve_base_decode(index, &decoded) != HVE_OK) {
            return EXIT_FAILURE;
        }
        checksum += (uint64_t)index + (uint64_t)decoded.theta + (uint64_t)decoded.s + (uint64_t)decoded.tau + (uint64_t)decoded.phi;
    }
    elapsed = now_seconds() - start;
    printf("BASE encode+decode: iterations=%" PRIu64 ", elapsed=%.6f s, %.2f Mstate/s, checksum=%" PRIu64 "\n",
           iterations, elapsed, (double)iterations / elapsed / 1e6, checksum);

    checksum = 0u;
    start = now_seconds();
    for (i = 0u; i < iterations; ++i) {
        uint64_t index;
        state.theta = (uint16_t)(i % 360u);
        state.s = (uint8_t)(i % 2u);
        state.tau = (uint8_t)(i % 5u);
        state.phi = (uint8_t)(i % 9u);
        color.r = (uint8_t)i;
        color.g = (uint8_t)(i >> 8);
        color.b = (uint8_t)(i >> 16);
        if (hve_chi_encode(&state, &color, &index) != HVE_OK ||
            hve_chi_decode(index, &decoded, &decoded_color) != HVE_OK) {
            return EXIT_FAILURE;
        }
        checksum += index + (uint64_t)decoded_color.r + (uint64_t)decoded_color.g + (uint64_t)decoded_color.b;
    }
    elapsed = now_seconds() - start;
    printf("CHI encode+decode:  iterations=%" PRIu64 ", elapsed=%.6f s, %.2f Mstate/s, checksum=%" PRIu64 "\n",
           iterations, elapsed, (double)iterations / elapsed / 1e6, checksum);

    return EXIT_SUCCESS;
}
