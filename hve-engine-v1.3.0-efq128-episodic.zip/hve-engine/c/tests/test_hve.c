#include "hve.h"

#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define CHECK(cond) do { \
    if (!(cond)) { \
        fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
        return 1; \
    } \
} while (0)

#define CHECK_STATUS(expr, expected) do { \
    hve_status_t _status = (expr); \
    if (_status != (expected)) { \
        fprintf(stderr, "FAIL %s:%d: %s returned %s, expected %s\n", \
                __FILE__, __LINE__, #expr, hve_status_string(_status), hve_status_string(expected)); \
        return 1; \
    } \
} while (0)

static int state_equal(const hve_state_t *a, const hve_state_t *b) {
    return a->theta == b->theta && a->s == b->s && a->tau == b->tau && a->phi == b->phi;
}

static int color_equal(const hve_color_t *a, const hve_color_t *b) {
    return a->present == b->present && a->r == b->r && a->g == b->g && a->b == b->b;
}

static uint32_t rng_state = UINT32_C(0xC0FFEE42);
static uint32_t rng_next(void) {
    uint32_t x = rng_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    rng_state = x;
    return x;
}

static int test_constants(void) {
    CHECK(HVE_BASE_CARDINALITY == 360u * 2u * 5u * 9u);
    CHECK(HVE_BASE_WORD_CAPACITY - HVE_BASE_CARDINALITY == HVE_BASE_RESERVED_WORDS);
    CHECK(HVE_COLOR_POINTED_CARDINALITY == HVE_COLOR_RGB_CARDINALITY + 1u);
    CHECK(HVE_CHI_CARDINALITY == (uint64_t)HVE_BASE_CARDINALITY * HVE_COLOR_POINTED_CARDINALITY);
    CHECK(HVE_CHI_MAX_INDEX + 1u == HVE_CHI_CARDINALITY);
    return 0;
}

static int test_exhaustive_base_roundtrip(void) {
    uint8_t *seen = (uint8_t *)calloc(HVE_BASE_CARDINALITY, 1u);
    uint32_t count = 0u;
    uint16_t theta;
    CHECK(seen != NULL);

    for (theta = 0u; theta < 360u; ++theta) {
        uint8_t s;
        for (s = 0u; s < 2u; ++s) {
            uint8_t tau;
            for (tau = 0u; tau < 5u; ++tau) {
                uint8_t phi;
                for (phi = 0u; phi < 9u; ++phi) {
                    hve_state_t in = {theta, s, tau, phi};
                    hve_state_t out;
                    uint16_t index;
                    CHECK_STATUS(hve_base_encode(&in, &index), HVE_OK);
                    CHECK(index < HVE_BASE_CARDINALITY);
                    CHECK(seen[index] == 0u);
                    seen[index] = 1u;
                    CHECK_STATUS(hve_base_decode(index, &out), HVE_OK);
                    CHECK(state_equal(&in, &out));
                    ++count;
                }
            }
        }
    }

    CHECK(count == HVE_BASE_CARDINALITY);
    for (count = 0u; count < HVE_BASE_CARDINALITY; ++count) {
        CHECK(seen[count] == 1u);
    }
    free(seen);
    return 0;
}

static int test_reserved_words(void) {
    uint16_t index;
    hve_state_t out;
    uint32_t rejected = 0u;
    for (index = HVE_BASE_CARDINALITY; index < HVE_BASE_WORD_CAPACITY; ++index) {
        CHECK_STATUS(hve_base_decode(index, &out), HVE_ERR_INVALID_WORD);
        ++rejected;
    }
    CHECK(rejected == HVE_BASE_RESERVED_WORDS);
    return 0;
}

static int test_state_validation(void) {
    hve_state_t valid = {359u, 1u, 4u, 8u};
    hve_state_t bad_theta = {360u, 0u, 0u, 0u};
    hve_state_t bad_s = {0u, 2u, 0u, 0u};
    hve_state_t bad_tau = {0u, 0u, 5u, 0u};
    hve_state_t bad_phi = {0u, 0u, 0u, 9u};
    uint16_t index;
    CHECK_STATUS(hve_state_validate(&valid), HVE_OK);
    CHECK_STATUS(hve_base_encode(&bad_theta, &index), HVE_ERR_RANGE);
    CHECK_STATUS(hve_base_encode(&bad_s, &index), HVE_ERR_RANGE);
    CHECK_STATUS(hve_base_encode(&bad_tau, &index), HVE_ERR_RANGE);
    CHECK_STATUS(hve_base_encode(&bad_phi, &index), HVE_ERR_RANGE);
    CHECK_STATUS(hve_state_validate(NULL), HVE_ERR_NULL);
    return 0;
}

static int test_sigma(void) {
    uint8_t s;
    int sigma;
    CHECK_STATUS(hve_sigma_to_s(1, &s), HVE_OK);
    CHECK(s == 0u);
    CHECK_STATUS(hve_sigma_to_s(-1, &s), HVE_OK);
    CHECK(s == 1u);
    CHECK_STATUS(hve_sigma_to_s(0, &s), HVE_ERR_RANGE);
    CHECK_STATUS(hve_s_to_sigma(0u, &sigma), HVE_OK);
    CHECK(sigma == 1);
    CHECK_STATUS(hve_s_to_sigma(1u, &sigma), HVE_OK);
    CHECK(sigma == -1);
    CHECK_STATUS(hve_s_to_sigma(2u, &sigma), HVE_ERR_RANGE);
    return 0;
}

static int test_group_operations(void) {
    hve_state_t zero = {0u, 0u, 0u, 0u};
    unsigned i;
    for (i = 0u; i < 10000u; ++i) {
        hve_state_t a = {(uint16_t)(rng_next() % 360u), (uint8_t)(rng_next() % 2u),
                         (uint8_t)(rng_next() % 5u), (uint8_t)(rng_next() % 9u)};
        hve_state_t b = {(uint16_t)(rng_next() % 360u), (uint8_t)(rng_next() % 2u),
                         (uint8_t)(rng_next() % 5u), (uint8_t)(rng_next() % 9u)};
        hve_state_t c = {(uint16_t)(rng_next() % 360u), (uint8_t)(rng_next() % 2u),
                         (uint8_t)(rng_next() % 5u), (uint8_t)(rng_next() % 9u)};
        hve_state_t inv, sum, ab, bc, left, right;
        CHECK_STATUS(hve_group_inverse(&a, &inv), HVE_OK);
        CHECK_STATUS(hve_group_add(&a, &inv, &sum), HVE_OK);
        CHECK(state_equal(&sum, &zero));
        CHECK_STATUS(hve_group_add(&a, &b, &ab), HVE_OK);
        CHECK_STATUS(hve_group_add(&ab, &c, &left), HVE_OK);
        CHECK_STATUS(hve_group_add(&b, &c, &bc), HVE_OK);
        CHECK_STATUS(hve_group_add(&a, &bc, &right), HVE_OK);
        CHECK(state_equal(&left, &right));
    }
    return 0;
}

static int test_base15_pack_unpack(void) {
    size_t counts[] = {0u, 1u, 2u, 7u, 8u, 9u, 31u, 257u};
    size_t ci;
    for (ci = 0u; ci < sizeof(counts) / sizeof(counts[0]); ++ci) {
        size_t count = counts[ci];
        size_t bytes = hve_base15_packed_size(count);
        uint16_t *input = count ? (uint16_t *)malloc(count * sizeof(uint16_t)) : NULL;
        uint16_t *output = count ? (uint16_t *)malloc(count * sizeof(uint16_t)) : NULL;
        uint8_t *packed = bytes ? (uint8_t *)malloc(bytes) : NULL;
        size_t written = 999u;
        size_t states = 999u;
        size_t i;
        CHECK((count == 0u) || (input != NULL && output != NULL));
        CHECK((bytes == 0u) || packed != NULL);
        for (i = 0u; i < count; ++i) {
            input[i] = (uint16_t)((i * 7919u + 17u) % HVE_BASE_CARDINALITY);
        }
        CHECK_STATUS(hve_base15_pack(input, count, packed, bytes, &written), HVE_OK);
        CHECK(written == bytes);
        CHECK_STATUS(hve_base15_unpack(packed, bytes, count, output, count, &states), HVE_OK);
        CHECK(states == count);
        for (i = 0u; i < count; ++i) {
            CHECK(input[i] == output[i]);
        }
        if (bytes > 0u && (count * 15u) % 8u != 0u) {
            uint8_t saved = packed[bytes - 1u];
            packed[bytes - 1u] |= 1u;
            CHECK_STATUS(hve_base15_unpack(packed, bytes, count, output, count, &states), HVE_ERR_INVALID_PADDING);
            packed[bytes - 1u] = saved;
        }
        free(input);
        free(output);
        free(packed);
    }
    return 0;
}

static int test_color_mapping(void) {
    hve_color_t colors[] = {
        {0u, 0u, 0u, 0u},
        {1u, 0u, 0u, 0u},
        {1u, 255u, 255u, 255u},
        {1u, 1u, 2u, 3u},
        {1u, 255u, 0u, 128u}
    };
    size_t i;
    for (i = 0u; i < sizeof(colors) / sizeof(colors[0]); ++i) {
        uint32_t k;
        hve_color_t out;
        CHECK_STATUS(hve_color_kappa(&colors[i], &k), HVE_OK);
        CHECK_STATUS(hve_color_kappa_inverse(k, &out), HVE_OK);
        CHECK(color_equal(&colors[i], &out));
    }
    {
        hve_color_t invalid = {0u, 1u, 0u, 0u};
        uint32_t k;
        CHECK_STATUS(hve_color_kappa(&invalid, &k), HVE_ERR_INVALID_COLOR);
        CHECK_STATUS(hve_color_kappa_inverse((uint32_t)HVE_COLOR_POINTED_CARDINALITY, &invalid), HVE_ERR_INVALID_COLOR);
    }
    return 0;
}

static int test_chi_boundaries_and_random(void) {
    hve_state_t states[] = {
        {0u, 0u, 0u, 0u},
        {359u, 1u, 4u, 8u},
        {123u, 1u, 2u, 7u}
    };
    hve_color_t colors[] = {
        {0u, 0u, 0u, 0u},
        {1u, 0u, 0u, 0u},
        {1u, 255u, 255u, 255u},
        {1u, 10u, 20u, 30u}
    };
    size_t si, ci;
    for (si = 0u; si < sizeof(states) / sizeof(states[0]); ++si) {
        for (ci = 0u; ci < sizeof(colors) / sizeof(colors[0]); ++ci) {
            uint64_t index;
            hve_state_t state_out;
            hve_color_t color_out;
            uint8_t p40[5];
            uint8_t p39[5];
            uint64_t index39;
            CHECK_STATUS(hve_chi_encode(&states[si], &colors[ci], &index), HVE_OK);
            CHECK(index <= HVE_CHI_MAX_INDEX);
            CHECK_STATUS(hve_chi_decode(index, &state_out, &color_out), HVE_OK);
            CHECK(state_equal(&states[si], &state_out));
            CHECK(color_equal(&colors[ci], &color_out));
            CHECK_STATUS(hve_chi40_pack(&states[si], &colors[ci], p40), HVE_OK);
            CHECK_STATUS(hve_chi40_unpack(p40, &state_out, &color_out), HVE_OK);
            CHECK(state_equal(&states[si], &state_out));
            CHECK(color_equal(&colors[ci], &color_out));
            CHECK_STATUS(hve_chi39_pack_index(index, p39), HVE_OK);
            CHECK_STATUS(hve_chi39_unpack_index(p39, &index39), HVE_OK);
            CHECK(index39 == index);
        }
    }

    for (si = 0u; si < 100000u; ++si) {
        hve_state_t in = {(uint16_t)(rng_next() % 360u), (uint8_t)(rng_next() % 2u),
                          (uint8_t)(rng_next() % 5u), (uint8_t)(rng_next() % 9u)};
        hve_color_t color = {1u, (uint8_t)rng_next(), (uint8_t)rng_next(), (uint8_t)rng_next()};
        hve_state_t out;
        hve_color_t color_out;
        uint64_t index;
        CHECK_STATUS(hve_chi_encode(&in, &color, &index), HVE_OK);
        CHECK_STATUS(hve_chi_decode(index, &out, &color_out), HVE_OK);
        CHECK(state_equal(&in, &out));
        CHECK(color_equal(&color, &color_out));
    }

    {
        hve_state_t state;
        hve_color_t color;
        CHECK_STATUS(hve_chi_decode(HVE_CHI_MAX_INDEX + 1u, &state, &color), HVE_ERR_INVALID_WORD);
    }
    return 0;
}

static int test_chi40_invalid_absence(void) {
    hve_state_t state;
    hve_color_t color;
    uint8_t bytes[5] = {0u, 0u, 1u, 0u, 0u}; /* P=0, R=1 */
    CHECK_STATUS(hve_chi40_unpack(bytes, &state, &color), HVE_ERR_INVALID_COLOR);
    return 0;
}

static int test_crc_and_frame(void) {
    static const uint8_t check[] = "123456789";
    uint16_t indices[9];
    uint8_t payload[17];
    uint8_t frame[HVE_FRAME_HEADER_SIZE + sizeof(payload)];
    uint8_t header[HVE_FRAME_HEADER_SIZE];
    hve_frame_info_t info;
    const uint8_t *payload_ptr;
    size_t payload_size = hve_base15_packed_size(9u);
    size_t written;
    size_t i;

    CHECK(hve_crc32(check, 9u) == UINT32_C(0xCBF43926));
    CHECK(payload_size == sizeof(payload));
    for (i = 0u; i < 9u; ++i) {
        indices[i] = (uint16_t)(i * 100u);
    }
    CHECK_STATUS(hve_base15_pack(indices, 9u, payload, sizeof(payload), &written), HVE_OK);
    CHECK(written == sizeof(payload));
    CHECK_STATUS(hve_frame_write_header(HVE_PROFILE_BASE15, 0x1234u, 9u,
                                        payload, sizeof(payload), header), HVE_OK);
    memcpy(frame, header, sizeof(header));
    memcpy(frame + sizeof(header), payload, sizeof(payload));
    CHECK_STATUS(hve_frame_parse(frame, sizeof(frame), &info, &payload_ptr), HVE_OK);
    CHECK(info.version_major == HVE_VERSION_MAJOR);
    CHECK(info.profile == HVE_PROFILE_BASE15);
    CHECK(info.flags == 0x1234u);
    CHECK(info.state_count == 9u);
    CHECK(info.payload_size == sizeof(payload));
    CHECK(payload_ptr == frame + HVE_FRAME_HEADER_SIZE);
    frame[sizeof(frame) - 1u] ^= 0x01u;
    CHECK_STATUS(hve_frame_parse(frame, sizeof(frame), &info, &payload_ptr), HVE_ERR_CRC_MISMATCH);
    return 0;
}

int main(void) {
    int (*tests[])(void) = {
        test_constants,
        test_exhaustive_base_roundtrip,
        test_reserved_words,
        test_state_validation,
        test_sigma,
        test_group_operations,
        test_base15_pack_unpack,
        test_color_mapping,
        test_chi_boundaries_and_random,
        test_chi40_invalid_absence,
        test_crc_and_frame
    };
    const char *names[] = {
        "constants",
        "exhaustive base round-trip",
        "reserved words",
        "state validation",
        "sigma conversion",
        "group operations",
        "15-bit packing",
        "color mapping",
        "chi boundaries/random",
        "chi40 invalid absence",
        "CRC and frame"
    };
    size_t i;
    for (i = 0u; i < sizeof(tests) / sizeof(tests[0]); ++i) {
        if (tests[i]() != 0) {
            fprintf(stderr, "Test suite stopped at: %s\n", names[i]);
            return EXIT_FAILURE;
        }
        printf("PASS: %s\n", names[i]);
    }
    printf("ALL TESTS PASSED\n");
    return EXIT_SUCCESS;
}
