"""Run the reproducible HVE × UTF-8 × Binary21 comparison."""

from __future__ import annotations

import argparse

from hve.comparative import (
    load_corpora,
    load_semantic_pairs,
    run_comparison,
    write_comparison_artifacts,
)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("corpus", nargs="*", help="UTF-8 text files; defaults to fixtures")
    parser.add_argument("--output-dir", default="comparison-results")
    parser.add_argument("--repetitions", type=int, default=9)
    parser.add_argument("--target-characters", type=int, default=100_000)
    parser.add_argument("--bootstrap-resamples", type=int, default=1_000)
    parser.add_argument("--error-trials", type=int, default=256)
    parser.add_argument("--seed", type=int, default=20260728)
    parser.add_argument("--token-vocabulary-size", type=int)
    parser.add_argument("--token-training-fraction", type=float, default=0.8)
    parser.add_argument("--token-minimum-pair-frequency", type=int, default=2)
    parser.add_argument("--token-maximum-characters", type=int, default=32)
    parser.add_argument("--semantic-pairs")
    parser.add_argument("--no-timings", action="store_true")
    parser.add_argument("--no-error-analysis", action="store_true")
    parser.add_argument("--no-harmonic-benchmark", action="store_true")
    args = parser.parse_args()

    corpora = load_corpora(args.corpus) if args.corpus else None
    pairs = load_semantic_pairs(args.semantic_pairs) if args.semantic_pairs else None
    report = run_comparison(
        corpora,
        semantic_pairs=pairs,
        token_vocabulary_size=args.token_vocabulary_size,
        token_training_fraction=args.token_training_fraction,
        token_minimum_pair_frequency=args.token_minimum_pair_frequency,
        token_maximum_characters=args.token_maximum_characters,
        repetitions=args.repetitions,
        target_characters=args.target_characters,
        bootstrap_resamples=args.bootstrap_resamples,
        error_trials=args.error_trials,
        seed=args.seed,
        include_timings=not args.no_timings,
        include_error_analysis=not args.no_error_analysis,
        include_harmonic_benchmark=not args.no_harmonic_benchmark,
    )
    for kind, path in write_comparison_artifacts(report, args.output_dir).items():
        print(f"{kind}: {path}")


if __name__ == "__main__":
    main()
