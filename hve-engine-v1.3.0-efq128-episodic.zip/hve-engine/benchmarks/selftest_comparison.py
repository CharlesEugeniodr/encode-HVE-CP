"""Dependency-light executable self-test for the HVE comparison code."""

from __future__ import annotations

import json
from pathlib import Path
import tempfile

from hve.comparative import (
    CODEC_BINARY21,
    CODEC_HVE_BASE15,
    CODEC_HVE_HYBRID,
    CODEC_HVE_LAB10,
    CODEC_UTF8,
    DECODERS,
    ENCODERS,
    analyze_corpus,
    analyze_pattern_search,
    analyze_single_bit_errors,
    benchmark_harmonic_domain,
    embed_binary,
    embed_unicode,
    evaluate_semantic_pairs,
    pack_reference_frame,
    recover_binary,
    recover_unicode,
    run_comparison,
    unpack_reference_frame,
    verify_dominance_certificate,
    write_comparison_artifacts,
)
from hve.core import (
    BASE_CARDINALITY,
    BASE_LAYOUTS,
    HVEError,
    decode_base_with_layout,
    encode_base_with_layout,
)
from hve.tokenization import cross_validated_token_analysis


def main() -> None:
    checks = 0

    for layout in BASE_LAYOUTS:
        seen = bytearray(BASE_CARDINALITY)
        for index in range(BASE_CARDINALITY):
            state = decode_base_with_layout(index, layout)
            recovered = encode_base_with_layout(state, layout)
            assert recovered == index and not seen[recovered]
            seen[recovered] = 1
        assert all(seen)
        checks += 1

    universal_texts = (
        "",
        "HVE720",
        "ação",
        "Ελληνικά Кириллица العربية 中文 😀",
        "\x00\t\n",
        chr(0x10FFFF),
    )
    for codec in (CODEC_UTF8, CODEC_BINARY21, CODEC_HVE_HYBRID):
        for text in universal_texts:
            payload = ENCODERS[codec](text)
            assert DECODERS[codec](payload) == text
            framed = unpack_reference_frame(pack_reference_frame(payload))
            assert framed.data == payload.data
            checks += 1

    lab_text = "HVE720ação∑"
    lab_payload = ENCODERS[CODEC_HVE_LAB10](lab_text)
    assert lab_payload.bit_length == len(lab_text) * 10
    assert DECODERS[CODEC_HVE_LAB10](lab_payload) == lab_text
    checks += 1
    try:
        ENCODERS[CODEC_HVE_LAB10](" ")
    except HVEError:
        checks += 1
    else:
        raise AssertionError("LAB10 accepted an unassigned space")

    base_text = "HVE 720\n"
    base_payload = ENCODERS[CODEC_HVE_BASE15](base_text)
    assert DECODERS[CODEC_HVE_BASE15](base_payload) == base_text
    checks += 1

    binary = bytes(range(256)) * 2
    unicode_text = "HVE, português, 中文 e 😀"
    assert recover_binary(embed_binary(binary)) == binary
    assert recover_unicode(embed_unicode(unicode_text)) == unicode_text
    checks += 2

    storage = analyze_corpus("selftest", lab_text)
    assert storage["codecs"][CODEC_HVE_LAB10]["payload_bits"] == len(lab_text) * 10
    checks += 1

    patterns = analyze_pattern_search("HVE HVE", ("HVE",))
    assert patterns["exact_pattern_identity_preserved"]
    assert patterns["cases"][0]["occurrences"] == [0, 4]
    checks += 1

    semantics = evaluate_semantic_pairs(
        (("a", "b", 0.9), ("a", "∑", 0.1), ("x", "😀", 0.2))
    )
    assert semantics["status"] == "evaluated"
    assert semantics["mapped_pairs"] == 2
    checks += 1

    errors = analyze_single_bit_errors(
        CODEC_HVE_HYBRID,
        lab_text,
        trials=16,
    )
    assert errors.common_frame_crc_detection_rate == 1.0
    checks += 1

    token_text = ("a estrutura harmônica preserva padrões e relações. " * 40).strip()
    token_result = cross_validated_token_analysis(
        token_text,
        training_fraction=0.8,
        target_vocabulary_size=128,
    )
    assert token_result["evaluation_characters"] > 0
    assert token_result["vocabulary_tokens"] <= 128
    assert token_result["hybrid_token_profile"]["payload_bits"] > 0
    checks += 1

    harmonic = benchmark_harmonic_domain(repetitions=1, bootstrap_resamples=0)
    assert harmonic["hve_parseval_passed"]
    assert harmonic["hve_roundtrip_max_abs_error"] < 1e-10
    checks += 1

    certificate = verify_dominance_certificate()
    assert certificate["passed"]
    assert certificate["base_states_verified"] == 32_400
    assert certificate["reserved_words_rejected"] == 368
    checks += 1

    report = run_comparison(
        {"selftest": lab_text},
        repetitions=1,
        target_characters=10,
        bootstrap_resamples=0,
        error_trials=4,
    )
    with tempfile.TemporaryDirectory() as directory:
        paths = write_comparison_artifacts(report, directory)
        for path in paths.values():
            assert Path(path).is_file()
            checks += 1

    print(
        json.dumps(
            {
                "status": "PASS",
                "checks": checks,
                "base_states_per_layout": BASE_CARDINALITY,
                "layouts": sorted(BASE_LAYOUTS),
                "dominance_certificate": certificate["passed"],
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
