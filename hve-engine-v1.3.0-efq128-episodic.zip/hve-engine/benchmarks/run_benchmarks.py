from hve.benchmark import benchmark_core, result_json
print(result_json(benchmark_core()))
