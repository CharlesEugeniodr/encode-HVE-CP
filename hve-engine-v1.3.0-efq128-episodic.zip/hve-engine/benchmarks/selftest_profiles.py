#!/usr/bin/env python3
"""Dependency-light source and profile validation for HVE Engine 1.3."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from hve.efq128 import (
    FIELD_WIDTHS,
    HVE128Fields,
    MODE_HVE128,
    SEMANTIC_PAYLOAD_ENTROPY_BITS,
    SEMANTIC_PAYLOAD_MIN_WORD_BITS,
    efq128_from_bytes,
)
from hve.episodic import (
    EpisodicMemory,
    encode_episodic_context,
    episodic_similarity,
)
from hve.legacy18000 import (
    LEGACY18000_CARDINALITY,
    decode_legacy18000,
    encode_legacy18000,
    migrate_from_hve32400,
    migrate_to_hve32400,
    validate_legacy18000_csv,
)
from hve.profile_6480 import (
    HVE6480_CARDINALITY,
    HVE6480_TAU_CARDINALITY,
    from_semantic,
    to_semantic,
    validate_hve6480_csv,
)
from hve.legacy_efq128 import (
    LegacyHVE128Fields,
    legacy_bytes_to_canonical_bytes,
    unpack_legacy_efq128,
)
from hve.zeta import ZETA_SYMBOLS, pack_zeta, unpack_zeta


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--hve6480-csv", type=Path)
    parser.add_argument("--legacy18000-csv", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    checks: dict[str, object] = {}
    checks["hve6480_factorization"] = {
        "base": HVE6480_CARDINALITY,
        "with_tau": HVE6480_TAU_CARDINALITY,
        "passed": HVE6480_CARDINALITY == 6480 and HVE6480_TAU_CARDINALITY == 32400,
    }

    legacy_migrated = set()
    for index in range(LEGACY18000_CARDINALITY):
        legacy = decode_legacy18000(index)
        assert encode_legacy18000(legacy) == index
        current = migrate_to_hve32400(legacy)
        assert migrate_from_hve32400(current) == legacy
        semantic = to_semantic(current)
        assert (
            from_semantic(
                semantic.theta,
                semantic.sigma,
                semantic.tau_degrees,
                semantic.phi_degrees,
            )
            == current
        )
        legacy_migrated.add(current)
    checks["legacy18000_migration"] = {
        "states": len(legacy_migrated),
        "injective": len(legacy_migrated) == LEGACY18000_CARDINALITY,
    }

    sample = HVE128Fields(
        mode=MODE_HVE128,
        theta=359,
        micro=999,
        sigma=1,
        tau=3599,
        direction=111,
        rgb=0xFFFFFF,
        extra=0x12345678,
    )
    checks["efq128"] = {
        "field_width_sum": sum(FIELD_WIDTHS.values()),
        "sample_roundtrip": efq128_from_bytes(sample.to_bytes()) == sample,
        "semantic_entropy_bits": SEMANTIC_PAYLOAD_ENTROPY_BITS,
        "semantic_min_word_bits": SEMANTIC_PAYLOAD_MIN_WORD_BITS,
    }

    legacy_sample = LegacyHVE128Fields(
        mode=MODE_HVE128,
        theta=12,
        micro=94,
        sigma=1,
        tau_raw=2,
        direction=2,
        rgb=0xFF0000,
        extra=12,
    )
    legacy_bytes = legacy_sample.to_bytes()
    canonical_bytes = legacy_bytes_to_canonical_bytes(legacy_bytes)
    canonical_sample = efq128_from_bytes(canonical_bytes)
    checks["efq128_legacy_wire"] = {
        "golden_hex": legacy_bytes.hex(),
        "golden_match": (
            legacy_bytes.hex() == "80060bd00205fe00000000000c000000"
        ),
        "self_roundtrip": unpack_legacy_efq128(legacy_bytes) == legacy_sample,
        "differs_from_canonical_wire": legacy_bytes != canonical_bytes,
        "semantic_transcode": (
            canonical_sample.theta,
            canonical_sample.micro,
            canonical_sample.sigma,
            canonical_sample.tau,
            canonical_sample.direction,
            canonical_sample.rgb,
            canonical_sample.extra,
        )
        == (12, 94, 1, 2, 2, 0xFF0000, 12),
    }

    memory = EpisodicMemory()
    memory.store_memory(
        "east-positive",
        cardinal_direction="E",
        valence=0.8,
        arousal=0.9,
        memory_id="east-positive",
        timestamp=1.0,
    )
    memory.store_memory(
        "west-negative",
        cardinal_direction="W",
        valence=-0.7,
        arousal=0.5,
        memory_id="west-negative",
        timestamp=2.0,
    )
    episodic_query = encode_episodic_context("E", 0.95, 0.95)
    episodic_results = memory.retrieve_by_hve_similarity(episodic_query, limit=2)
    checks["episodic_memory"] = {
        "token_bytes": len(episodic_query),
        "identity_similarity": episodic_similarity(
            episodic_query,
            episodic_query,
        ),
        "top_match": episodic_results[0].record.memory_id,
        "ordered": (
            episodic_results[0].similarity_score
            > episodic_results[1].similarity_score
        ),
    }

    zeta_tokens = set()
    for index in range(ZETA_SYMBOLS):
        token = pack_zeta(index)
        assert unpack_zeta(token) == index
        zeta_tokens.add(token)
    checks["zeta"] = {
        "states": len(zeta_tokens),
        "injective": len(zeta_tokens) == ZETA_SYMBOLS,
    }

    if args.hve6480_csv:
        audit = validate_hve6480_csv(args.hve6480_csv)
        checks["hve6480_csv"] = {
            "rows": audit.rows,
            "unique_states": audit.unique_states,
            "sequential_indices": audit.sequential_indices,
            "semantic_indices_match": audit.semantic_indices_match,
            "sha256": audit.sha256,
            "passed": audit.passed,
        }
    if args.legacy18000_csv:
        audit = validate_legacy18000_csv(args.legacy18000_csv)
        checks["legacy18000_csv"] = {
            "rows": audit.rows,
            "unique_states": audit.unique_states,
            "sequential_indices": audit.sequential_indices,
            "state_labels_match": audit.state_labels_match,
            "sha256": audit.sha256,
            "warnings": audit.warnings,
            "passed": audit.passed,
        }

    result = {
        "profile": "HVE Engine 1.3 EFQ compatibility and episodic memory",
        "checks": checks,
    }
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    print(payload)


if __name__ == "__main__":
    main()
