from hve.angular import shortest_path
print(shortest_path(359, 2))
