from hve.ai_mapping.rule_based_mapper import MappingRule, RuleBasedMapper
from hve.core import HVEState
mapper = RuleBasedMapper([MappingRule("question", lambda x: x == "?", lambda x: HVEState(62,0,0,0))], canonical_fallback=False)
print(mapper.map("?"))
