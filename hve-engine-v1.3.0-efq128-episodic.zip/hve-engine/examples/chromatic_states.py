from hve import HVEState
from hve.chromatic import HVEColor, encode_chi, decode_chi
s = HVEState(10,0,0,0)
for c in (HVEColor.no_color(), HVEColor.rgb(0,0,0)):
    i = encode_chi(s,c)
    print(i, decode_chi(i))
