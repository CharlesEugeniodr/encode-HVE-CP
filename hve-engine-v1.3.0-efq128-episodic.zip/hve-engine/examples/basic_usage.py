from hve import HVEState, encode_base, decode_base

state = HVEState(45, 0, 2, 3)
index = encode_base(state)
print(index, decode_base(index))
