"""Decode an attached-toolkit token and transcode it to canonical EFQ128."""

from hve.efq128 import efq128_from_bytes
from hve.legacy_efq128 import (
    legacy_bytes_to_canonical_bytes,
    unpack_legacy_efq128,
)

historical = bytes.fromhex("80060bd00205fe00000000000c000000")
legacy_fields = unpack_legacy_efq128(historical)
canonical_bytes = legacy_bytes_to_canonical_bytes(historical)
canonical_fields = efq128_from_bytes(canonical_bytes)

print("legacy:", legacy_fields)
print("canonical hex:", canonical_bytes.hex())
print("canonical:", canonical_fields)

