"""Store and rank canonical HVE-128 episodic-context records."""

from hve.episodic import EpisodicMemory, encode_episodic_context

memory = EpisodicMemory()
memory.store_memory(
    "Encontro feliz no Leste.",
    cardinal_direction="E",
    valence=0.8,
    arousal=0.9,
)
memory.store_memory(
    "Discussão triste no Oeste.",
    cardinal_direction="W",
    valence=-0.7,
    arousal=0.5,
)
memory.store_memory(
    "Observação neutra no Norte.",
    cardinal_direction="N",
    valence=0.0,
    arousal=0.1,
)

query = encode_episodic_context("E", 0.95, 0.95)
for result in memory.retrieve_by_hve_similarity(query):
    print(f"{result.similarity_score:.6f} {result.record.content}")
