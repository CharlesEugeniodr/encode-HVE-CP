import numpy as np
from hve.harmonic import GROUP_SHAPE, dft, idft, parseval_check
f = np.zeros(GROUP_SHAPE, dtype=complex)
f[0,0,0,0] = 1
F = dft(f)
print("roundtrip", np.max(np.abs(idft(F)-f)))
print("parseval", parseval_check(f,F))
