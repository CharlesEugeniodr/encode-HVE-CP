from hve.comparative import run_comparison, write_comparison_artifacts

report = run_comparison(
    {"example": "HVE 720 preserva estrutura, identidade e reversibilidade."},
    token_vocabulary_size=128,
    repetitions=3,
    target_characters=10_000,
    bootstrap_resamples=200,
    error_trials=64,
)
print(write_comparison_artifacts(report, "comparison-results"))
