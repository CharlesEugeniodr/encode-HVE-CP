# HVE × UTF-8 × Binary21 — Comparative Report

Generated: `2026-07-28T03:30:00Z`

## Structural result

**Certificate:** PASS

HVE Universal is a strict functional and structural extension of raw binary and UTF-8 within the declared dominance scope.

Not claimed: universal superiority in storage size, execution speed, byte alignment, or deployed interoperability.

| Proof obligation | Result |
|---|---:|
| base_bijection_32400 | PASS |
| reserved_words_rejected_368 | PASS |
| binary_embedding_roundtrips | PASS |
| unicode_embedding_roundtrips | PASS |
| layout_crosswalk_32400 | PASS |
| lab720_scalar_assignments_169 | PASS |
| strict_added_structure | PASS |

## Storage by corpus

| Corpus | Codec | Coverage | Payload bytes | Bits/char | Δ vs UTF-8 |
|---|---|---:|---:|---:|---:|
| conclusao_hve_pt | utf8 | n/a | 7522 | 8.437 | +0.00% |
| conclusao_hve_pt | binary21 | n/a | 18722 | 21.000 | +148.90% |
| conclusao_hve_pt | hve_hybrid | 85.04% | 11274 | 12.646 | +49.88% |
| conclusao_hve_pt | hve_lab720_v0 | n/a | n/a | n/a | n/a |
| conclusao_hve_pt | hve_base15 | n/a | n/a | n/a | n/a |

## Cross-validated HVE token profile

Vocabulary is trained on the declared prefix and measured only on the held-out suffix. Dictionary cost is reported explicitly.

| Corpus | Vocab | Chars/token | Pure 15-bit bpc | Hybrid bpc | Hybrid Δ UTF-8 | Dict bytes | Break-even chars |
|---|---:|---:|---:|---:|---:|---:|---:|
| conclusao_hve_pt | 512 | 2.597 | n/a | 6.168 | -26.12% | 3105 | 11408 |

## Pattern and semantic evaluation

| Corpus | Exact pattern identity |
|---|---:|
| conclusao_hve_pt | PASS |

Semantic evaluation status: `not_evaluated`.

No independent labelled similarity pairs were supplied; numeric proximity is not treated as automatic semantic evidence.


## Interpretation boundary

- Structural dominance is proved only for the declared functional scope.
- Storage and speed are empirical, corpus-dependent outcomes.
- Binary21 is a fixed Unicode-scalar baseline; raw binary has no intrinsic character semantics.
- HVE BASE15 is reported only when every input symbol has a canonical mapping.
- HVE hybrid fallback preserves Unicode identity but does not invent HVE geometry for an unassigned symbol.
