# HVE Engine 1.3 — Implementation Status

## Completed

- [x] New canonical `hve-engine` repository layout
- [x] MIT license, citation metadata, changelog, contribution and security policies
- [x] HVE-720 BASE mixed-radix bijection and inverse
- [x] Exhaustive validation of all 32,400 BASE states
- [x] Rejection of all 368 reserved 15-bit words
- [x] Finite Abelian group operations
- [x] Angular State Engine on `C_360`
- [x] Discrete geodesic distance, neighborhoods, arcs, shortest paths, circular mean, sectors
- [x] BASE/MICRO/NANO integer resolution coordinates and projections
- [x] Finite-group character evaluation
- [x] Full separable DFT/IDFT on shape `(360, 2, 5, 9)`
- [x] Direct reduced-domain DFT oracle
- [x] Convolution, correlation, spectral filters, Parseval checks
- [x] Exact Cartesian-product Laplacian spectrum
- [x] HVE-chi pointed chromatic extension
- [x] BASE15, CHI39, CHI40 and HVE1/CRC-32 protocol
- [x] 720 canonical positions generated
- [x] Conservative confirmed symbol subset only; no invented full Unicode table
- [x] Deterministic and rule-based mapping interfaces
- [x] No trained AI model claimed or included
- [x] CLI, examples, host benchmark, documentation and GitHub Actions CI
- [x] Portable C11 reference core imported from the validated Part I implementation
- [x] Versioned crosswalk between Engine 1.0 and document-2025 mixed-radix layouts
- [x] LAB-720 v0 10-bit codec with 169 verified scalar assignments
- [x] Binary21 fixed Unicode-scalar comparison baseline
- [x] Universal HVE text and raw-binary embeddings
- [x] Common HVC1 comparison frame with equal CRC-32 overhead
- [x] Coverage, storage, zlib, timing, bootstrap CI and error-propagation metrics
- [x] Exact-pattern preservation checks and semantic-evaluation hook
- [x] Structured HVE FFTN versus flat FFT cost baseline
- [x] Deterministic BPE token profile with held-out evaluation
- [x] Vocabulary cost and amortization break-even calculation
- [x] Executable structural-dominance certificate
- [x] JSON, CSV and Markdown evidence reports
- [x] HVE-6480+tau semantic profile validated against all 32,400 supplied CSV rows
- [x] Legacy HVE-Lang 18,000-state parser and injective migration
- [x] HVE-128 EFQ v1 exact 128-bit layout with explicit reserved bit 87
- [x] Exact attached-toolkit legacy EFQ128 wire decoder and semantic transcode
- [x] HVE-128 episodic-context profile with cyclic direction and RGB similarity
- [x] Legacy-aware PostgreSQL episodic migration with real ranking
- [x] HVE-Zeta Sigma-0 137,000-state injective engine profile
- [x] Source hashes, profile boundaries, and executable source audit

## Deliberate scientific limits

- The Angular Engine performs geometry on the state cycle; it does not perform terrestrial geolocation.
- The AI Mapping package is an extensibility contract and non-learning mapping layer.
- The canonical table does not invent unverified Unicode assignments.
- Host benchmark values are implementation diagnostics, not embedded-hardware claims.
- No cryptographic-security claim is made.
- Semantic proximity is not claimed without independent labelled pairs.
- Token compression reports payload and complete vocabulary cost separately.
- The document-2025 layout is supported explicitly; Engine 1.0 remains the
  default wire layout for backward compatibility.
- The attached `hve_toolkit_128.py` contains no HVE-Zeta implementation, so it
  cannot establish Zeta byte compatibility with the separate v5 note.
- The attached episodic RGB mapping is a deterministic heuristic, not a learned
  or clinically validated emotional representation.
- PostgreSQL similarity is an exact scan; no ANN claim is made for raw `BYTEA`.
- The radial numeral-zero image is treated as a visualization, not proof of a
  fractal construction.

## Validation performed in the build environment

- Dependency-light comparison self-test: 35 checks passed.
- Both BASE layouts: 32,400/32,400 exhaustive round-trips passed.
- CLI validation logic: 32,400 valid states, 368 reserved words rejected, zero failures.
- Full HVE harmonic round-trip and Parseval tests: passed.
- Portable C11 strict-warning build and exhaustive test: passed directly with GCC.
- Supplied HVE-6480+tau CSV: 32,400 unique rows and indices matched.
- Legacy HVE-Lang CSV: 18,000 unique rows and migration remained injective.
- HVE-Zeta: 137,000/137,000 pack/unpack round-trips passed.
- HVE-128 EFQ: exact field-width sum 128 and binary round-trip passed.
- Attached-toolkit EFQ128 golden vector: exact reproduction and semantic
  transcode passed.
- Episodic context: 16-byte round-trip, identity similarity, and expected
  retrieval ranking passed.
- Source-document held-out token payload: 26.12% smaller than UTF-8; full
  vocabulary cost amortizes after 11,408 evaluated characters in this run.
