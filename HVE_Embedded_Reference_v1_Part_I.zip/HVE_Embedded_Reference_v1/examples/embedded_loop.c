/*
 * Minimal allocation-free integration example for an embedded main loop.
 * Replace uart_write() and obtain_state() with platform-specific functions.
 */
#include "hve.h"

#include <stddef.h>
#include <stdint.h>

static int uart_write(const uint8_t *data, size_t size) {
    (void)data;
    return (int)size; /* platform stub */
}

static hve_state_t obtain_state(void) {
    hve_state_t state = {42u, 0u, 1u, 3u};
    return state;
}

int main(void) {
    hve_state_t state = obtain_state();
    uint16_t index;
    uint8_t payload[2];

    if (hve_base_encode(&state, &index) != HVE_OK) {
        return 1;
    }

    /* Demonstration byte-aligned wrapper for a single word. The canonical
     * stream profile is hve_base15_pack(); this wrapper leaves bit 15 zero. */
    payload[0] = (uint8_t)(index >> 8);
    payload[1] = (uint8_t)index;
    return uart_write(payload, sizeof(payload)) == (int)sizeof(payload) ? 0 : 2;
}
