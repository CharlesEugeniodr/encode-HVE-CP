# Implementation status and evidence boundary

## Implemented and executed

1. HVE-720 BASE state validation.
2. Direct mixed-radix encoding.
3. Exact inverse decoding.
4. Group addition and inverse.
5. MSB-first 15-bit packing/unpacking.
6. Rejection of the 368 reserved words.
7. HVE-χ pointed-color mapping κ and κ⁻¹.
8. HVE-χ monolithic bijection and inverse.
9. Compact 39-bit single-state representation.
10. Aligned 40-bit state representation.
11. Deterministic frame header and CRC-32 validation.
12. C11 static library, Python executable specification, test suite, and cross-language verification.

## Authored but not physically executed

1. Verilog BASE encoder/decoder.
2. Verilog CHI40 packer/unpacker.
3. Exhaustive Verilog testbench.
4. Embedded integration stub.

Reason: the build environment did not provide a Verilog simulator, vendor FPGA tools, an MCU board, or power-measurement hardware.

## Not claimed

- measured MCU cycles per state;
- real-time schedulability;
- FPGA frequency, LUT count, or energy;
- compression superiority;
- semantic superiority over Unicode;
- application-level robustness beyond the tested profile invariants.
