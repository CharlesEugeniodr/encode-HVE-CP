# License decision pending

This source package is prepared for scientific validation and author review. No public software license has been selected.

Before publication in a public repository, the author should choose one of the following paths:

- Apache License 2.0: permissive, with explicit patent terms;
- MIT License: short and permissive;
- dual licensing: open research implementation plus separate commercial terms;
- proprietary/all-rights-reserved distribution.

This file is not a license grant.
