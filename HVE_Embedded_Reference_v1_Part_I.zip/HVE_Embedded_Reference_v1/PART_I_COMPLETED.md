# HVE Embedded Reference 1.0 — Part I completed

This package converts the mathematical HVE-720/HVE-χ definitions into a versioned, executable, testable, and documented reference architecture.

## Delivered

- normative embedded profile in Portuguese;
- allocation-free C11 reference library;
- independent Python executable specification;
- exhaustive BASE verification over all 32,400 valid states;
- exhaustive rejection of all 368 reserved 15-bit words;
- BASE15 stream packing with canonical zero padding;
- HVE-χ monolithic 39-bit and aligned 40-bit representations;
- formal distinction between NoColor and RGB black;
- HVE1 fixed frame header with version, profile, count, and CRC-32;
- C/Python conformance tests and deterministic golden vectors;
- AddressSanitizer/UndefinedBehaviorSanitizer execution evidence;
- reference Verilog modules and testbench;
- embedded integration example;
- host benchmark harness;
- physical MCU/FPGA experimental protocol;
- technical architecture report;
- Journal of Systems Architecture-oriented article draft.

## Evidence boundary

The C and Python paths were executed successfully. Reference RTL was authored but not simulated or synthesized because no HDL simulator, FPGA vendor tools, target boards, or laboratory power instrumentation were available. No physical MCU/FPGA latency, area, energy, or real-time claim is made.

## Required Part II

Part II is the physical validation phase: port to declared MCU and FPGA targets, execute the frozen experimental protocol, preserve raw measurements, run statistical analysis, and replace the article draft's unclaimed result placeholders with reproducible hardware evidence.
