# HVE Embedded Reference 1.0

Reference implementation and executable specification for HVE-720 BASE and the HVE-χ chromatic extension.

## Status

This package is **Part I — software, protocol, validation, and reference RTL**. The C and Python implementations were compiled/executed in the build environment and passed:

- exhaustive BASE round-trip for all 32,400 states;
- rejection of all 368 reserved 15-bit words;
- group identity/inverse and randomized associativity tests;
- 15-bit stream packing tests, including nonzero-padding rejection;
- NoColor/black/white chromatic boundary tests;
- 100,000 deterministic randomized HVE-χ round-trips;
- aligned 40-bit and compact 39-bit round-trips;
- CRC-32 frame validation and corruption detection;
- exhaustive C/Python cross-check for all 32,400 BASE states.

The Verilog files are architectural reference RTL. No HDL simulator or FPGA synthesis tool was available in the execution environment, so the package does not claim measured FPGA results.

## Directory map

- `include/`, `src/`: allocation-free C11 implementation;
- `tests/`: exhaustive tests and golden vectors;
- `python/`: executable Python specification;
- `tools/`: vector generator and C/Python cross-check;
- `hdl/`: Verilog reference encoder, decoder, CHI40 serializer, and testbench;
- `benchmarks/`: host benchmark harness;
- `examples/`: minimal embedded integration example;
- `docs/`: normative specification, architecture report, measurement protocol, and execution logs;
- `article/`: JSA-oriented article draft, with physical results explicitly left unclaimed.

## Build and validate

### CMake

```sh
cmake -S . -B cmake-build -DCMAKE_BUILD_TYPE=Release
cmake --build cmake-build
ctest --test-dir cmake-build --output-on-failure
```

### Make

```sh
make test
make benchmark
```

### Python

```sh
PYTHONPATH=python python -m unittest -v python/test_hve_ref.py
python tools/crosscheck_ctypes.py
```

## Normative serialization choices in Profile 1.0

- BASE words are 15 bits and valid only in `[0, 32399]`;
- stream packing is MSB-first;
- unused final-byte padding bits are zero and are validated;
- HVE-χ aligned profile is exactly 40 bits: `[index:15][P:1][R:8][G:8][B:8]`;
- `P=0` means NoColor and requires `R=G=B=0`;
- `P=1, RGB=(0,0,0)` means explicit black;
- the compact monolithic HVE-χ value occupies 39 significant bits;
- frame integers use network byte order;
- frame payload integrity uses CRC-32/ISO-HDLC;
- the frame carries profile, version, flags, and state count.

## Scientific limits

The package proves and tests implementation correctness relative to the HVE definitions. It does not yet provide measured MCU/FPGA latency, power, memory, timing closure, or application-level superiority. Those require declared physical targets and reproducible laboratory execution.

## Authorship and license

Scientific authorship: Charles de Paula Eugênio.

No open-source license is assigned in this package. The author should select a license before public repository release. Until then, the code should be treated as all rights reserved.
