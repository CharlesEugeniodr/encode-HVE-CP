// HVE-720 BASE decoder, combinational reference RTL.
// Constant division/modulo operators are synthesizable in common FPGA tools;
// implementation cost must be measured for the selected target.

`timescale 1ns/1ps

module hve_base_decoder (
    input  wire [14:0] index,
    output wire [8:0]  theta,
    output wire        s,
    output wire [2:0]  tau,
    output wire [3:0]  phi,
    output wire        valid
);
    wire [14:0] q1;
    wire [14:0] q2;

    assign valid = (index < 15'd32400);
    assign phi = valid ? (index % 15'd9) : 4'd0;
    assign q1 = index / 15'd9;
    assign tau = valid ? (q1 % 15'd5) : 3'd0;
    assign q2 = q1 / 15'd5;
    assign s = valid ? (q2 % 15'd2) : 1'b0;
    assign theta = valid ? (q2 / 15'd2) : 9'd0;
endmodule
