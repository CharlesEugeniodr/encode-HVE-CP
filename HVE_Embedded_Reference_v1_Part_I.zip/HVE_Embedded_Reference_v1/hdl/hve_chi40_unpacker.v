`timescale 1ns/1ps

module hve_chi40_unpacker (
    input  wire [39:0] word,
    output wire [14:0] base_index,
    output wire        color_present,
    output wire [7:0]  red,
    output wire [7:0]  green,
    output wire [7:0]  blue,
    output wire        valid
);
    assign base_index = word[39:25];
    assign color_present = word[24];
    assign red = word[23:16];
    assign green = word[15:8];
    assign blue = word[7:0];
    assign valid = (base_index < 15'd32400) &&
                   (color_present || ((red == 8'd0) && (green == 8'd0) && (blue == 8'd0)));
endmodule
