// HVE-chi aligned 40-bit profile.
// word[39:25] = BASE index
// word[24]    = color-present P
// word[23:16] = R
// word[15:8]  = G
// word[7:0]   = B
// P=0 requires RGB=0.

`timescale 1ns/1ps

module hve_chi40_packer (
    input  wire [14:0] base_index,
    input  wire        color_present,
    input  wire [7:0]  red,
    input  wire [7:0]  green,
    input  wire [7:0]  blue,
    output wire [39:0] word,
    output wire        valid
);
    assign valid = (base_index < 15'd32400) &&
                   (color_present || ((red == 8'd0) && (green == 8'd0) && (blue == 8'd0)));
    assign word = valid ? {base_index, color_present, red, green, blue} : 40'd0;
endmodule
