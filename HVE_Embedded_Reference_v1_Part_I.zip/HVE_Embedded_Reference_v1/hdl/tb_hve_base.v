`timescale 1ns/1ps

module tb_hve_base;
    reg  [8:0] theta;
    reg        s;
    reg  [2:0] tau;
    reg  [3:0] phi;
    wire [14:0] encoded_index;
    wire        enc_valid;

    reg  [14:0] decode_index;
    wire [8:0] decoded_theta;
    wire       decoded_s;
    wire [2:0] decoded_tau;
    wire [3:0] decoded_phi;
    wire       dec_valid;

    integer i;
    integer failures;

    hve_base_encoder encoder (
        .theta(theta), .s(s), .tau(tau), .phi(phi),
        .index(encoded_index), .valid(enc_valid)
    );

    hve_base_decoder decoder (
        .index(decode_index), .theta(decoded_theta), .s(decoded_s),
        .tau(decoded_tau), .phi(decoded_phi), .valid(dec_valid)
    );

    initial begin
        failures = 0;
        theta = 0; s = 0; tau = 0; phi = 0; decode_index = 0;
        #1;

        for (i = 0; i < 32400; i = i + 1) begin
            decode_index = i[14:0];
            #1;
            if (!dec_valid) begin
                $display("FAIL invalid decode index %0d", i);
                failures = failures + 1;
            end
            theta = decoded_theta;
            s = decoded_s;
            tau = decoded_tau;
            phi = decoded_phi;
            #1;
            if (!enc_valid || encoded_index !== decode_index) begin
                $display("FAIL round-trip index=%0d got=%0d state=(%0d,%0d,%0d,%0d)",
                         i, encoded_index, theta, s, tau, phi);
                failures = failures + 1;
            end
        end

        for (i = 32400; i < 32768; i = i + 1) begin
            decode_index = i[14:0];
            #1;
            if (dec_valid) begin
                $display("FAIL reserved index accepted: %0d", i);
                failures = failures + 1;
            end
        end

        if (failures == 0) begin
            $display("ALL HDL BASE TESTS PASSED");
        end else begin
            $display("HDL TESTS FAILED: %0d", failures);
        end
        $finish;
    end
endmodule
