# HVE RTL reference

This directory contains deliberately small, auditable Verilog-2001 reference modules:

- `hve_base_encoder.v`: combinational HVE-720 BASE encoder;
- `hve_base_decoder.v`: combinational inverse using constant division/modulo;
- `hve_chi40_packer.v`: aligned 40-bit HVE-chi packer;
- `hve_chi40_unpacker.v`: aligned 40-bit HVE-chi unpacker;
- `tb_hve_base.v`: exhaustive BASE round-trip and reserved-word testbench.

The RTL is a functional architectural reference, not a claim of target-specific optimality. Before publication, synthesize it for at least one FPGA family and report:

- LUT/ALM usage;
- registers;
- maximum clock frequency;
- combinational path delay;
- dynamic/static power under a declared activity model;
- latency and throughput;
- exact synthesis tool and version.

The current execution environment did not contain Icarus Verilog, Verilator, or a vendor synthesis tool. Therefore the RTL has been manually reviewed but is not represented as simulator- or synthesis-verified in this package. The C and Python implementations are executed and tested.
