// HVE-720 BASE encoder, combinational reference RTL.
// E(theta,s,tau,phi) = (((theta*2+s)*5+tau)*9+phi)
// Inputs outside their mathematical domains produce valid=0.

`timescale 1ns/1ps

module hve_base_encoder (
    input  wire [8:0] theta,
    input  wire       s,
    input  wire [2:0] tau,
    input  wire [3:0] phi,
    output wire [14:0] index,
    output wire        valid
);
    wire [9:0] stage1;
    wire [12:0] stage2;
    wire [16:0] stage3;

    assign valid = (theta < 9'd360) && (tau < 3'd5) && (phi < 4'd9);
    assign stage1 = ({1'b0, theta} << 1) + {{9{1'b0}}, s};
    assign stage2 = stage1 * 4'd5 + {{10{1'b0}}, tau};
    assign stage3 = stage2 * 5'd9 + {{13{1'b0}}, phi};
    assign index = valid ? stage3[14:0] : 15'd0;
endmodule
