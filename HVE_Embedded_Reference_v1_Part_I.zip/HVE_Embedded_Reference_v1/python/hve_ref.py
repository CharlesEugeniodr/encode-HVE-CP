"""HVE-720 / HVE-chi reference implementation, Embedded Profile 1.0.

This module intentionally uses only Python's standard library. It mirrors the C
reference implementation and serves as an executable specification.
"""

from __future__ import annotations

from dataclasses import dataclass
import binascii
import struct
from typing import Iterable, Sequence

THETA_CARDINALITY = 360
S_CARDINALITY = 2
TAU_CARDINALITY = 5
PHI_CARDINALITY = 9
BASE_CARDINALITY = 32_400
BASE_WORD_BITS = 15
BASE_WORD_CAPACITY = 32_768
BASE_RESERVED_WORDS = 368
COLOR_RGB_CARDINALITY = 1 << 24
COLOR_POINTED_CARDINALITY = COLOR_RGB_CARDINALITY + 1
CHI_CARDINALITY = BASE_CARDINALITY * COLOR_POINTED_CARDINALITY
CHI_MAX_INDEX = CHI_CARDINALITY - 1

PROFILE_BASE15 = 0x01
PROFILE_CHI40 = 0x02
FRAME_HEADER_SIZE = 16
FRAME_MAGIC = b"HVE1"
FRAME_VERSION_MAJOR = 1


class HVEError(ValueError):
    """Raised when an HVE value or serialized stream violates the profile."""


@dataclass(frozen=True, slots=True)
class HVEState:
    theta: int
    s: int
    tau: int
    phi: int

    def validate(self) -> None:
        if not 0 <= self.theta < THETA_CARDINALITY:
            raise HVEError("theta must be in [0, 359]")
        if not 0 <= self.s < S_CARDINALITY:
            raise HVEError("s must be in {0, 1}")
        if not 0 <= self.tau < TAU_CARDINALITY:
            raise HVEError("tau must be in [0, 4]")
        if not 0 <= self.phi < PHI_CARDINALITY:
            raise HVEError("phi must be in [0, 8]")


@dataclass(frozen=True, slots=True)
class HVEColor:
    present: bool
    r: int = 0
    g: int = 0
    b: int = 0

    def validate(self) -> None:
        for name, value in (("r", self.r), ("g", self.g), ("b", self.b)):
            if not 0 <= value <= 255:
                raise HVEError(f"{name} must be in [0, 255]")
        if not self.present and (self.r != 0 or self.g != 0 or self.b != 0):
            raise HVEError("NoColor requires r=g=b=0")

    @staticmethod
    def no_color() -> "HVEColor":
        return HVEColor(False, 0, 0, 0)

    @staticmethod
    def rgb(r: int, g: int, b: int) -> "HVEColor":
        color = HVEColor(True, r, g, b)
        color.validate()
        return color


def sigma_to_s(sigma: int) -> int:
    if sigma == 1:
        return 0
    if sigma == -1:
        return 1
    raise HVEError("sigma must be +1 or -1")


def s_to_sigma(s: int) -> int:
    if s == 0:
        return 1
    if s == 1:
        return -1
    raise HVEError("s must be 0 or 1")


def encode_base(state: HVEState) -> int:
    state.validate()
    index = (((state.theta * 2 + state.s) * 5 + state.tau) * 9 + state.phi)
    if not 0 <= index < BASE_CARDINALITY:
        raise AssertionError("internal BASE index overflow")
    return index


def decode_base(index: int) -> HVEState:
    if not 0 <= index < BASE_CARDINALITY:
        raise HVEError("BASE index must be in [0, 32399]")
    phi = index % 9
    q1 = index // 9
    tau = q1 % 5
    q2 = q1 // 5
    s = q2 % 2
    theta = q2 // 2
    return HVEState(theta, s, tau, phi)


def group_add(a: HVEState, b: HVEState) -> HVEState:
    a.validate()
    b.validate()
    return HVEState(
        (a.theta + b.theta) % 360,
        (a.s + b.s) % 2,
        (a.tau + b.tau) % 5,
        (a.phi + b.phi) % 9,
    )


def group_inverse(a: HVEState) -> HVEState:
    a.validate()
    return HVEState((-a.theta) % 360, (-a.s) % 2, (-a.tau) % 5, (-a.phi) % 9)


def base15_packed_size(state_count: int) -> int:
    if state_count < 0:
        raise HVEError("state_count cannot be negative")
    return (state_count * 15 + 7) // 8


def pack_base15(indices: Sequence[int]) -> bytes:
    output = bytearray(base15_packed_size(len(indices)))
    bit_pos = 0
    for word in indices:
        if not 0 <= word < BASE_CARDINALITY:
            raise HVEError("invalid or reserved 15-bit word")
        for bit in range(14, -1, -1):
            byte_index = bit_pos // 8
            bit_in_byte = 7 - (bit_pos % 8)
            output[byte_index] |= ((word >> bit) & 1) << bit_in_byte
            bit_pos += 1
    return bytes(output)


def unpack_base15(data: bytes, state_count: int) -> list[int]:
    required = base15_packed_size(state_count)
    if len(data) != required:
        raise HVEError(f"payload length must be exactly {required} bytes")
    result: list[int] = []
    bit_pos = 0
    for _ in range(state_count):
        word = 0
        for bit in range(14, -1, -1):
            byte_index = bit_pos // 8
            bit_in_byte = 7 - (bit_pos % 8)
            word |= ((data[byte_index] >> bit_in_byte) & 1) << bit
            bit_pos += 1
        if word >= BASE_CARDINALITY:
            raise HVEError("decoded word belongs to the reserved interval")
        result.append(word)
    if required and (state_count * 15) % 8:
        padding_bits = 8 - ((state_count * 15) % 8)
        if data[-1] & ((1 << padding_bits) - 1):
            raise HVEError("nonzero padding bits")
    return result


def color_kappa(color: HVEColor) -> int:
    color.validate()
    if not color.present:
        return 0
    return 1 + (color.r << 16) + (color.g << 8) + color.b


def color_kappa_inverse(kappa: int) -> HVEColor:
    if not 0 <= kappa < COLOR_POINTED_CARDINALITY:
        raise HVEError("kappa outside pointed chromatic space")
    if kappa == 0:
        return HVEColor.no_color()
    u = kappa - 1
    return HVEColor.rgb((u >> 16) & 0xFF, (u >> 8) & 0xFF, u & 0xFF)


def encode_chi(state: HVEState, color: HVEColor) -> int:
    return encode_base(state) * COLOR_POINTED_CARDINALITY + color_kappa(color)


def decode_chi(index: int) -> tuple[HVEState, HVEColor]:
    if not 0 <= index <= CHI_MAX_INDEX:
        raise HVEError("HVE-chi index outside valid interval")
    base_index, kappa = divmod(index, COLOR_POINTED_CARDINALITY)
    return decode_base(base_index), color_kappa_inverse(kappa)


def pack_chi40(state: HVEState, color: HVEColor) -> bytes:
    base_index = encode_base(state)
    color.validate()
    word = (
        (base_index << 25)
        | (int(color.present) << 24)
        | (color.r << 16)
        | (color.g << 8)
        | color.b
    )
    return word.to_bytes(5, "big")


def unpack_chi40(data: bytes) -> tuple[HVEState, HVEColor]:
    if len(data) != 5:
        raise HVEError("CHI40 state must occupy exactly five bytes")
    word = int.from_bytes(data, "big")
    base_index = (word >> 25) & 0x7FFF
    color = HVEColor(bool((word >> 24) & 1), (word >> 16) & 0xFF, (word >> 8) & 0xFF, word & 0xFF)
    color.validate()
    return decode_base(base_index), color


def pack_chi39_index(index: int) -> bytes:
    if not 0 <= index <= CHI_MAX_INDEX:
        raise HVEError("HVE-chi index outside valid interval")
    return index.to_bytes(5, "big")


def unpack_chi39_index(data: bytes) -> int:
    if len(data) != 5:
        raise HVEError("CHI39 representation must occupy five bytes")
    if data[0] & 0x80:
        raise HVEError("bit 39 is reserved and must be zero")
    index = int.from_bytes(data, "big")
    if index > CHI_MAX_INDEX:
        raise HVEError("HVE-chi index outside valid interval")
    return index


def frame_payload_size(profile: int, state_count: int) -> int:
    if state_count < 0 or state_count > 0xFFFFFFFF:
        raise HVEError("state_count must fit uint32")
    if profile == PROFILE_BASE15:
        return base15_packed_size(state_count)
    if profile == PROFILE_CHI40:
        return state_count * 5
    raise HVEError("unsupported profile")


def make_frame(profile: int, state_count: int, payload: bytes, flags: int = 0) -> bytes:
    expected = frame_payload_size(profile, state_count)
    if len(payload) != expected:
        raise HVEError(f"payload must contain exactly {expected} bytes")
    if not 0 <= flags <= 0xFFFF:
        raise HVEError("flags must fit uint16")
    crc = binascii.crc32(payload) & 0xFFFFFFFF
    header = FRAME_MAGIC + bytes((FRAME_VERSION_MAJOR, profile)) + struct.pack(">HII", flags, state_count, crc)
    if len(header) != FRAME_HEADER_SIZE:
        raise AssertionError("invalid frame header size")
    return header + payload


def parse_frame(frame: bytes) -> tuple[int, int, int, bytes]:
    if len(frame) < FRAME_HEADER_SIZE:
        raise HVEError("truncated frame")
    if frame[:4] != FRAME_MAGIC:
        raise HVEError("invalid frame magic")
    version = frame[4]
    profile = frame[5]
    if version != FRAME_VERSION_MAJOR:
        raise HVEError("unsupported frame version")
    flags, state_count, stored_crc = struct.unpack(">HII", frame[6:16])
    expected_payload = frame_payload_size(profile, state_count)
    if len(frame) != FRAME_HEADER_SIZE + expected_payload:
        raise HVEError("frame length mismatch")
    payload = frame[FRAME_HEADER_SIZE:]
    actual_crc = binascii.crc32(payload) & 0xFFFFFFFF
    if actual_crc != stored_crc:
        raise HVEError("CRC mismatch")
    return profile, flags, state_count, payload


def encode_states_base15(states: Iterable[HVEState]) -> bytes:
    indices = [encode_base(state) for state in states]
    return pack_base15(indices)
