from __future__ import annotations

import random
import unittest

import hve_ref as hve


class HVEReferenceTests(unittest.TestCase):
    def test_exhaustive_base_roundtrip(self) -> None:
        seen = bytearray(hve.BASE_CARDINALITY)
        count = 0
        for theta in range(360):
            for s in range(2):
                for tau in range(5):
                    for phi in range(9):
                        state = hve.HVEState(theta, s, tau, phi)
                        index = hve.encode_base(state)
                        self.assertEqual(seen[index], 0)
                        seen[index] = 1
                        self.assertEqual(hve.decode_base(index), state)
                        count += 1
        self.assertEqual(count, 32_400)
        self.assertTrue(all(seen))

    def test_reserved_words(self) -> None:
        for index in range(32_400, 32_768):
            with self.assertRaises(hve.HVEError):
                hve.decode_base(index)

    def test_pack_base15(self) -> None:
        for count in (0, 1, 2, 7, 8, 9, 31, 257):
            indices = [(i * 7919 + 17) % hve.BASE_CARDINALITY for i in range(count)]
            packed = hve.pack_base15(indices)
            self.assertEqual(len(packed), hve.base15_packed_size(count))
            self.assertEqual(hve.unpack_base15(packed, count), indices)

    def test_color_special_states(self) -> None:
        no_color = hve.HVEColor.no_color()
        black = hve.HVEColor.rgb(0, 0, 0)
        white = hve.HVEColor.rgb(255, 255, 255)
        self.assertEqual(hve.color_kappa(no_color), 0)
        self.assertEqual(hve.color_kappa(black), 1)
        self.assertEqual(hve.color_kappa(white), 1 << 24)
        self.assertNotEqual(no_color, black)

    def test_chi_roundtrip_random(self) -> None:
        rng = random.Random(0xC0FFEE42)
        for _ in range(100_000):
            state = hve.HVEState(rng.randrange(360), rng.randrange(2), rng.randrange(5), rng.randrange(9))
            color = hve.HVEColor.rgb(rng.randrange(256), rng.randrange(256), rng.randrange(256))
            index = hve.encode_chi(state, color)
            self.assertEqual(hve.decode_chi(index), (state, color))
            chi40 = hve.pack_chi40(state, color)
            self.assertEqual(hve.unpack_chi40(chi40), (state, color))
            chi39 = hve.pack_chi39_index(index)
            self.assertEqual(hve.unpack_chi39_index(chi39), index)

    def test_chi40_rejects_invalid_no_color(self) -> None:
        with self.assertRaises(hve.HVEError):
            hve.unpack_chi40(bytes((0, 0, 1, 0, 0)))

    def test_frame_roundtrip(self) -> None:
        indices = [i * 100 for i in range(9)]
        payload = hve.pack_base15(indices)
        frame = hve.make_frame(hve.PROFILE_BASE15, len(indices), payload, flags=0x1234)
        profile, flags, count, decoded_payload = hve.parse_frame(frame)
        self.assertEqual(profile, hve.PROFILE_BASE15)
        self.assertEqual(flags, 0x1234)
        self.assertEqual(count, len(indices))
        self.assertEqual(hve.unpack_base15(decoded_payload, count), indices)
        damaged = bytearray(frame)
        damaged[-1] ^= 1
        with self.assertRaises(hve.HVEError):
            hve.parse_frame(bytes(damaged))


if __name__ == "__main__":
    unittest.main(verbosity=2)
