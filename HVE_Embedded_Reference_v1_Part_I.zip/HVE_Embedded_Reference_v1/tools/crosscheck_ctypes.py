#!/usr/bin/env python3
"""Compile the C reference as a shared object and cross-check it against Python."""
from __future__ import annotations

import ctypes
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
import hve_ref as pyhve  # noqa: E402


class CState(ctypes.Structure):
    _fields_ = [
        ("theta", ctypes.c_uint16),
        ("s", ctypes.c_uint8),
        ("tau", ctypes.c_uint8),
        ("phi", ctypes.c_uint8),
    ]


class CColor(ctypes.Structure):
    _fields_ = [
        ("present", ctypes.c_uint8),
        ("r", ctypes.c_uint8),
        ("g", ctypes.c_uint8),
        ("b", ctypes.c_uint8),
    ]


def build_library() -> Path:
    output = ROOT / "build" / "libhve_crosscheck.so"
    output.parent.mkdir(exist_ok=True)
    command = [
        "cc", "-shared", "-fPIC", "-O2", "-std=c11", "-Wall", "-Wextra", "-Wpedantic", "-Werror",
        "-I", str(ROOT / "include"), str(ROOT / "src" / "hve.c"), "-o", str(output),
    ]
    subprocess.run(command, check=True)
    return output


def main() -> None:
    lib = ctypes.CDLL(str(build_library()))
    lib.hve_base_encode.argtypes = [ctypes.POINTER(CState), ctypes.POINTER(ctypes.c_uint16)]
    lib.hve_base_encode.restype = ctypes.c_int
    lib.hve_base_decode.argtypes = [ctypes.c_uint16, ctypes.POINTER(CState)]
    lib.hve_base_decode.restype = ctypes.c_int
    lib.hve_chi_encode.argtypes = [ctypes.POINTER(CState), ctypes.POINTER(CColor), ctypes.POINTER(ctypes.c_uint64)]
    lib.hve_chi_encode.restype = ctypes.c_int

    checked = 0
    for theta in range(360):
        for s in range(2):
            for tau in range(5):
                for phi in range(9):
                    py_state = pyhve.HVEState(theta, s, tau, phi)
                    c_state = CState(theta, s, tau, phi)
                    c_index = ctypes.c_uint16()
                    status = lib.hve_base_encode(ctypes.byref(c_state), ctypes.byref(c_index))
                    if status != 0 or c_index.value != pyhve.encode_base(py_state):
                        raise SystemExit(f"BASE mismatch at {py_state}")
                    decoded = CState()
                    status = lib.hve_base_decode(c_index.value, ctypes.byref(decoded))
                    if status != 0 or (decoded.theta, decoded.s, decoded.tau, decoded.phi) != (theta, s, tau, phi):
                        raise SystemExit(f"decode mismatch at {py_state}")
                    checked += 1

    samples = [
        pyhve.HVEColor.no_color(),
        pyhve.HVEColor.rgb(0, 0, 0),
        pyhve.HVEColor.rgb(1, 2, 3),
        pyhve.HVEColor.rgb(255, 255, 255),
    ]
    for base_index in (0, 1, 17, 12_345, 32_399):
        py_state = pyhve.decode_base(base_index)
        c_state = CState(py_state.theta, py_state.s, py_state.tau, py_state.phi)
        for color in samples:
            c_color = CColor(int(color.present), color.r, color.g, color.b)
            c_index = ctypes.c_uint64()
            status = lib.hve_chi_encode(ctypes.byref(c_state), ctypes.byref(c_color), ctypes.byref(c_index))
            expected = pyhve.encode_chi(py_state, color)
            if status != 0 or c_index.value != expected:
                raise SystemExit(f"CHI mismatch at {py_state}, {color}")

    print(f"C/Python cross-check passed for {checked} BASE states and CHI boundary samples")


if __name__ == "__main__":
    main()
