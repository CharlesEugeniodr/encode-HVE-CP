#!/usr/bin/env python3
from __future__ import annotations

import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
import hve_ref as hve  # noqa: E402


def main() -> None:
    state_cases = [
        hve.HVEState(0, 0, 0, 0),
        hve.HVEState(0, 0, 0, 8),
        hve.HVEState(0, 1, 0, 0),
        hve.HVEState(123, 1, 2, 7),
        hve.HVEState(359, 1, 4, 8),
    ]
    colors = [
        hve.HVEColor.no_color(),
        hve.HVEColor.rgb(0, 0, 0),
        hve.HVEColor.rgb(1, 2, 3),
        hve.HVEColor.rgb(255, 255, 255),
    ]
    vectors: dict[str, object] = {
        "profile": "HVE Embedded Profile 1.0",
        "base": [],
        "chi": [],
    }
    for state in state_cases:
        index = hve.encode_base(state)
        vectors["base"].append({
            "state": state.__dict__ if hasattr(state, "__dict__") else {
                "theta": state.theta, "s": state.s, "tau": state.tau, "phi": state.phi
            },
            "index": index,
            "word15_hex": f"{index:04x}",
        })
        for color in colors:
            chi_index = hve.encode_chi(state, color)
            vectors["chi"].append({
                "state": {"theta": state.theta, "s": state.s, "tau": state.tau, "phi": state.phi},
                "color": {"present": color.present, "r": color.r, "g": color.g, "b": color.b},
                "kappa": hve.color_kappa(color),
                "chi_index": chi_index,
                "chi39_hex": hve.pack_chi39_index(chi_index).hex(),
                "chi40_hex": hve.pack_chi40(state, color).hex(),
            })
    output = ROOT / "tests" / "golden_vectors.json"
    output.write_text(json.dumps(vectors, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(output)


if __name__ == "__main__":
    main()
