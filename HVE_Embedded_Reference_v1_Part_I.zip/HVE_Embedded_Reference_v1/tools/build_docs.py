from __future__ import annotations

from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Cm, Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_BREAK

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
ARTICLE = ROOT / "article"


def set_cell_shading(cell, fill="D9E2F3"):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell_text(cell, text, bold=False, size=9):
    cell.text = ""
    p = cell.paragraphs[0]
    r = p.add_run(str(text))
    r.bold = bold
    r.font.name = "Times New Roman"
    r.font.size = Pt(size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, headers, rows, widths=None, font_size=9):
    table = doc.add_table(rows=1, cols=len(headers))
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    hdr = table.rows[0].cells
    for i, h in enumerate(headers):
        set_cell_text(hdr[i], h, bold=True, size=font_size)
        set_cell_shading(hdr[i])
        if widths:
            hdr[i].width = widths[i]
    for row in rows:
        table_row = table.add_row()
        trPr = table_row._tr.get_or_add_trPr()
        cant_split = OxmlElement("w:cantSplit")
        trPr.append(cant_split)
        cells = table_row.cells
        for i, value in enumerate(row):
            set_cell_text(cells[i], value, size=font_size)
            if widths:
                cells[i].width = widths[i]
    return table


def configure_doc(doc: Document, title: str, lang="pt-BR"):
    sec = doc.sections[0]
    sec.top_margin = Cm(2.2)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.4)
    sec.right_margin = Cm(2.2)
    sec.header_distance = Cm(1.0)
    sec.footer_distance = Cm(1.0)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(11)
    normal.paragraph_format.space_after = Pt(5)
    normal.paragraph_format.line_spacing = 1.08

    for name, size in [("Title", 20), ("Subtitle", 12), ("Heading 1", 15), ("Heading 2", 13), ("Heading 3", 11)]:
        st = styles[name]
        st.font.name = "Times New Roman"
        st.font.size = Pt(size)
        st.font.color.rgb = RGBColor(0, 0, 0)
        if "Heading" in name:
            st.font.bold = True
            st.paragraph_format.space_before = Pt(12)
            st.paragraph_format.space_after = Pt(5)

    if "Code Block" not in [s.name for s in styles]:
        code = styles.add_style("Code Block", WD_STYLE_TYPE.PARAGRAPH)
        code.font.name = "Courier New"
        code.font.size = Pt(8.5)
        code.paragraph_format.left_indent = Cm(0.6)
        code.paragraph_format.right_indent = Cm(0.3)
        code.paragraph_format.space_before = Pt(3)
        code.paragraph_format.space_after = Pt(6)
        code.paragraph_format.line_spacing = 1.0
    if "Normative" not in [s.name for s in styles]:
        norm = styles.add_style("Normative", WD_STYLE_TYPE.PARAGRAPH)
        norm.font.name = "Times New Roman"
        norm.font.size = Pt(10.5)
        norm.font.bold = False
        norm.paragraph_format.left_indent = Cm(0.5)
        norm.paragraph_format.border_top = None

    core = doc.core_properties
    core.title = title
    core.author = "Charles de Paula Eugênio"
    core.subject = "HVE-720 Embedded Profile"
    core.keywords = "HVE-720, HVE-chi, embedded systems, finite Abelian group, serialization"

    header = sec.header.paragraphs[0]
    header.text = title
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in header.runs:
        run.font.name = "Times New Roman"
        run.font.size = Pt(8)

    footer = sec.footer.paragraphs[0]
    footer.text = "Charles de Paula Eugênio — Reference Draft 1.0"
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in footer.runs:
        run.font.name = "Times New Roman"
        run.font.size = Pt(8)


def add_title_page(doc, title, subtitle, status, author="Charles de Paula Eugênio"):
    p = doc.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(title)
    p = doc.add_paragraph(style="Subtitle")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(subtitle)
    doc.add_paragraph("")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(author)
    r.bold = True
    r.font.size = Pt(12)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Independent Researcher — Parauapebas, Pará, Brazil")
    doc.add_paragraph("")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(status)
    r.bold = True
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Version 1.0 — July 2026")
    doc.add_page_break()


def add_bullets(doc, items, level=0):
    for item in items:
        p = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
        p.add_run(item)


def add_numbered(doc, items):
    for idx, item in enumerate(items, start=1):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Cm(0.55)
        p.paragraph_format.first_line_indent = Cm(-0.45)
        p.add_run(f"{idx}. ").bold = False
        p.add_run(item)


def add_code(doc, text):
    p = doc.add_paragraph(style="Code Block")
    p.add_run(text)


def add_equation(doc, text, number=None):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(text)
    r.font.name = "Cambria Math"
    r.font.size = Pt(11)
    if number:
        p.add_run(f"    ({number})")


def build_spec():
    title = "HVE Embedded Profile 1.0"
    doc = Document()
    configure_doc(doc, title)
    add_title_page(doc, title, "Especificação normativa, serialização e conformidade", "EXECUTABLE NORMATIVE DRAFT")

    doc.add_heading("Resumo executivo", level=1)
    doc.add_paragraph(
        "Este documento congela uma primeira especificação executável para o núcleo HVE-720 e para a extensão cromática HVE-χ. "
        "Ele não modifica os objetos matemáticos do manuscrito-base. O objetivo é eliminar ambiguidades de implementação: tipos, limites, ordem de bits, "
        "empacotamento, perfis, validação, enquadramento, integridade, erros e critérios de conformidade. A implementação de referência em C11 e a "
        "especificação executável em Python acompanham este documento."
    )
    doc.add_paragraph(
        "As palavras DEVE, NÃO DEVE, DEVERÁ, PODE e RECOMENDA-SE são normativas. Uma implementação só é conforme quando satisfaz integralmente "
        "os requisitos do perfil que declara."
    )

    doc.add_heading("1. Escopo", level=1)
    add_bullets(doc, [
        "Representação do estado BASE g = (θ, s, τ, φ).",
        "Bijeção HVE-720 entre o domínio coordenado e os índices 0 a 32.399.",
        "Operações de grupo necessárias à biblioteca de referência.",
        "Empacotamento MSB-first de palavras BASE de 15 bits.",
        "Extensão cromática apontada C* = {NoColor} ⊔ RGB.",
        "Bijeção monolítica HVE-χ e perfis de 39 e 40 bits.",
        "Frame determinístico com versão, perfil, contagem e CRC-32.",
        "Semântica de rejeição, testes mínimos e níveis de conformidade."
    ])
    doc.add_paragraph(
        "Ficam fora deste perfil: a tabela canônica de símbolos, normalização Unicode, fallback de caracteres não representáveis, compressão, segurança criptográfica, "
        "ontologia dos campos τ e φ, perfis colorimétricos além do RGB de 8 bits e desempenho específico de plataforma."
    )

    doc.add_heading("2. Modelo matemático imutável", level=1)
    add_equation(doc, "G = Z₃₆₀ × Z₂ × Z₅ × Z₉", 1)
    add_equation(doc, "|G| = 360 × 2 × 5 × 9 = 32.400", 2)
    doc.add_paragraph("Um estado BASE é a tupla g = (θ, s, τ, φ) com os domínios abaixo.")
    add_table(doc, ["Campo", "Domínio", "Bits de armazenamento", "Regra"], [
        ("θ", "0…359", "9", "posição angular"),
        ("s", "0…1", "1", "polaridade; σ = (−1)^s"),
        ("τ", "0…4", "3", "estado auxiliar"),
        ("φ", "0…8", "4", "estado auxiliar"),
    ])
    doc.add_paragraph("Os tamanhos individuais não definem o formato serializado. O formato BASE normativo é o índice bijetivo de 15 bits.")

    doc.add_heading("3. Tipos abstratos e invariantes", level=1)
    add_table(doc, ["Tipo", "Campos", "Invariantes"], [
        ("HVEState", "theta, s, tau, phi", "todos os campos nos domínios da Seção 2"),
        ("NoColor", "nenhum", "estado cromático nulo, distinto de preto"),
        ("RGBColor", "r, g, b", "cada canal em 0…255"),
        ("HVEColor", "present, r, g, b", "present=0 implica r=g=b=0"),
    ])
    doc.add_paragraph("Uma implementação NÃO DEVE usar RGB(0,0,0) como marcador de ausência. Preto é uma cor válida e distinta de NoColor.")

    doc.add_heading("4. Bijeção BASE", level=1)
    add_equation(doc, "E(θ,s,τ,φ) = (((θ·2 + s)·5 + τ)·9 + φ)", 3)
    doc.add_paragraph("O codificador DEVE validar o estado antes do cálculo. O resultado DEVE pertencer a [0, 32.399].")
    doc.add_heading("4.1. Inversa", level=2)
    add_code(doc, "phi  = n mod 9\nq1   = floor(n / 9)\ntau  = q1 mod 5\nq2   = floor(q1 / 5)\ns    = q2 mod 2\ntheta= floor(q2 / 2)")
    doc.add_paragraph("O decodificador DEVE rejeitar n ≥ 32.400. Os índices 32.400…32.767 são reservados e não representam estados BASE.")

    doc.add_heading("5. Operações de grupo", level=1)
    add_equation(doc, "g ⊕ h = ((θ+θ′) mod 360, (s+s′) mod 2, (τ+τ′) mod 5, (φ+φ′) mod 9)", 4)
    add_equation(doc, "−g = ((−θ) mod 360, (−s) mod 2, (−τ) mod 5, (−φ) mod 9)", 5)
    doc.add_paragraph("Essas operações pertencem à API matemática. Elas não alteram o formato de serialização e não constituem criptografia.")

    doc.add_heading("6. Perfil BASE15", level=1)
    doc.add_paragraph("Cada estado é transformado em um índice de 15 bits. A capacidade bruta é 2¹⁵ = 32.768 palavras; 32.400 são válidas e 368 são reservadas.")
    add_table(doc, ["Intervalo", "Status", "Ação do decodificador"], [
        ("0…32.399", "válido", "decodificar"),
        ("32.400…32.767", "reservado", "rejeitar"),
    ])
    doc.add_heading("6.1. Ordem de bits", level=2)
    doc.add_paragraph("O fluxo BASE15 DEVE ser MSB-first. O primeiro bit transmitido é o bit 14 da primeira palavra. Não há alinhamento por palavra.")
    doc.add_heading("6.2. Comprimento", level=2)
    add_equation(doc, "bytes(N) = ceil(15N / 8)", 6)
    doc.add_paragraph("O número N de estados é informação externa ao payload ou é obtido do frame da Seção 10.")
    doc.add_heading("6.3. Padding", level=2)
    doc.add_paragraph("Se 15N não for múltiplo de 8, os bits menos significativos não utilizados do último byte DEVEM ser zero. O decodificador DEVE rejeitar padding não nulo.")

    doc.add_heading("7. Espaço cromático apontado", level=1)
    add_equation(doc, "C* = {NoColor} ⊔ {0,…,255}³", 7)
    add_equation(doc, "|C*| = 2²⁴ + 1 = 16.777.217", 8)
    doc.add_heading("7.1. Ordenação κ", level=2)
    add_equation(doc, "κ(NoColor) = 0", 9)
    add_equation(doc, "κ(r,g,b) = 1 + 65.536r + 256g + b", 10)
    add_table(doc, ["Estado", "κ"], [
        ("NoColor", "0"),
        ("RGB(0,0,0) — preto", "1"),
        ("RGB(255,255,255) — branco", "16.777.216"),
    ])

    doc.add_heading("8. Bijeção HVE-χ", level=1)
    add_equation(doc, "Gχ = G × C*", 11)
    add_equation(doc, "|Gχ| = 32.400 × 16.777.217 = 543.581.830.800", 12)
    add_equation(doc, "Eχ(g,c) = E(g)·16.777.217 + κ(c)", 13)
    doc.add_paragraph("O intervalo monolítico válido é 0…543.581.830.799. Valores superiores DEVEM ser rejeitados.")

    doc.add_heading("9. Perfis cromáticos", level=1)
    doc.add_heading("9.1. CHI39", level=2)
    doc.add_paragraph("O índice Eχ usa 39 bits significativos. Na representação unitária em cinco bytes, o bit mais significativo do primeiro byte DEVE ser zero. "
                      "O valor inteiro é armazenado em ordem de rede. O perfil compacto contínuo pode eliminar esse bit entre estados, desde que a contagem esteja disponível.")
    doc.add_heading("9.2. CHI40 alinhado", level=2)
    doc.add_picture(str(DOCS / "hve_chi40_layout.png"), width=Inches(6.4))
    p = doc.paragraphs[-1]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph("Layout normativo: bits 39…25 = índice BASE; bit 24 = P; bits 23…16 = R; bits 15…8 = G; bits 7…0 = B.")
    add_table(doc, ["Condição", "Significado", "Validade"], [
        ("P=0, RGB=0", "NoColor", "válido"),
        ("P=0, RGB≠0", "estado não canônico", "inválido; rejeitar"),
        ("P=1, RGB=qualquer", "cor explícita", "válido"),
    ])

    doc.add_heading("10. Frame HVE1", level=1)
    doc.add_paragraph("O frame transporta um payload BASE15 ou CHI40 sem alocação dinâmica obrigatória. Todos os inteiros multibyte usam big-endian.")
    add_table(doc, ["Offset", "Tamanho", "Campo", "Regra"], [
        ("0", "4", "Magic", "ASCII HVE1"),
        ("4", "1", "Versão principal", "1"),
        ("5", "1", "Perfil", "0x01 BASE15; 0x02 CHI40"),
        ("6", "2", "Flags", "reservadas; big-endian"),
        ("8", "4", "State count", "uint32; big-endian"),
        ("12", "4", "CRC-32", "CRC-32/ISO-HDLC do payload"),
        ("16", "variável", "Payload", "comprimento derivado"),
    ])
    add_equation(doc, "payload(BASE15,N) = ceil(15N/8)", 14)
    add_equation(doc, "payload(CHI40,N) = 5N", 15)
    doc.add_paragraph("O parser DEVE verificar magic, versão, perfil, comprimento exato e CRC antes de entregar o payload à aplicação.")

    doc.add_heading("11. Semântica de erros", level=1)
    add_table(doc, ["Erro", "Causa mínima"], [
        ("NULL", "ponteiro obrigatório ausente"),
        ("RANGE", "coordenada fora do domínio"),
        ("BUFFER_TOO_SMALL", "buffer insuficiente"),
        ("INVALID_WORD", "índice reservado ou fora do intervalo"),
        ("INVALID_COLOR", "cor ou marcador NoColor inconsistente"),
        ("INVALID_PADDING", "bits reservados não nulos"),
        ("INVALID_FRAME", "magic, versão ou comprimento inválido"),
        ("CRC_MISMATCH", "integridade do payload falhou"),
        ("UNSUPPORTED_PROFILE", "perfil desconhecido"),
        ("OVERFLOW", "cálculo de tamanho não representável"),
    ])
    doc.add_paragraph("A implementação NÃO DEVE corrigir silenciosamente estados inválidos. Rejeição explícita é parte da interoperabilidade.")

    h = doc.add_heading("12. Critérios de conformidade", level=1)
    h.paragraph_format.page_break_before = True
    add_table(doc, ["Nível", "Requisitos"], [
        ("Core", "validação, E, E⁻¹, rejeição 368, testes exaustivos"),
        ("Serialization", "Core + BASE15 MSB-first + padding zero"),
        ("Chromatic", "Serialization + κ + Eχ + CHI39/CHI40 + distinção NoColor/preto"),
        ("Framed", "Chromatic + frame HVE1 + CRC-32"),
        ("Embedded", "Framed + execução em alvo declarado + limites de memória/tempo documentados"),
        ("Hardware", "Framed + RTL simulado/sintetizado + recursos, frequência e potência documentados"),
    ])

    doc.add_heading("13. Testes normativos mínimos", level=1)
    add_numbered(doc, [
        "Enumerar os 32.400 estados BASE e provar computacionalmente unicidade e round-trip.",
        "Rejeitar individualmente os 368 índices reservados.",
        "Testar limites inferiores e superiores de todas as coordenadas.",
        "Testar grupo: identidade e inverso para todos os estados; associatividade por amostragem determinística.",
        "Testar BASE15 para contagens que cruzem fronteiras de byte e bloco, incluindo padding corrompido.",
        "Testar NoColor, preto, branco e cores de fronteira.",
        "Testar Eχ e inversa em limites e por amostragem pseudoaleatória reprodutível.",
        "Testar CHI40 com P=0 e RGB não nulo, que deve ser rejeitado.",
        "Testar CRC com vetor conhecido '123456789' = 0xCBF43926 e corrupção de payload.",
        "Comparar ao menos duas implementações independentes por vetores dourados."
    ])

    doc.add_heading("14. Segurança e limites", level=1)
    add_bullets(doc, [
        "CRC detecta corrupção acidental; não fornece autenticidade.",
        "Aritmética modular e permutações HVE não são, isoladamente, criptografia.",
        "O frame não define confidencialidade, nonce, MAC ou assinatura.",
        "A tabela simbólica e a semântica de τ/φ devem ser versionadas separadamente.",
        "Comparações com UTF-8 exigem cobertura e função equivalentes.",
        "O perfil não declara superioridade de compressão, semântica ou energia sem experimento."
    ])

    doc.add_heading("15. Compatibilidade e evolução", level=1)
    doc.add_paragraph("A versão principal muda somente quando um decodificador 1.x não puder interpretar corretamente o frame. Novos perfis devem receber novos códigos. "
                      "Os 368 códigos BASE reservados não podem ser atribuídos informalmente: qualquer uso futuro exige versão ou perfil normativo.")

    h = doc.add_heading("Apêndice A — API C mínima", level=1)
    h.paragraph_format.page_break_before = True
    add_code(doc, "hve_base_encode(state, &index)\nhve_base_decode(index, &state)\nhve_base15_pack(indices, count, out, out_size, &written)\nhve_base15_unpack(in, in_size, count, indices, capacity, &written)\nhve_chi_encode(state, color, &index64)\nhve_chi_decode(index64, &state, &color)\nhve_chi40_pack(state, color, bytes5)\nhve_chi40_unpack(bytes5, &state, &color)\nhve_frame_write_header(profile, flags, count, payload, size, header)\nhve_frame_parse(frame, frame_size, &info, &payload)")

    doc.add_heading("Apêndice B — Evidência da implementação de referência", level=1)
    add_bullets(doc, [
        "C11 compilado com avisos estritos tratados como erro.",
        "Suite C executada com validação exaustiva BASE e 100.000 casos HVE-χ.",
        "Suite C executada adicionalmente sob AddressSanitizer e UndefinedBehaviorSanitizer.",
        "Suite Python executada com validação exaustiva BASE e 100.000 casos HVE-χ.",
        "Cross-check C/Python executado para todos os 32.400 estados BASE.",
        "Vetores dourados gerados em JSON.",
        "RTL Verilog fornecido como referência, sem alegação de síntese física nesta etapa."
    ])

    output = DOCS / "HVE_Embedded_Profile_1_0_Especificacao_Normativa_PT.docx"
    doc.save(output)
    return output


def build_report():
    title = "HVE Embedded Reference Architecture 1.0"
    doc = Document()
    configure_doc(doc, title)
    add_title_page(doc, title, "Relatório técnico de implementação, validação e transição para sistemas embarcados", "TECHNICAL IMPLEMENTATION REPORT")

    doc.add_heading("Resumo", level=1)
    doc.add_paragraph(
        "O trabalho converte a formulação HVE-720/HVE-χ em uma arquitetura executável e auditável. Foi construída uma biblioteca C11 sem alocação dinâmica, "
        "uma especificação executável Python, empacotadores BASE15, CHI39 e CHI40, enquadramento com CRC-32, testes exaustivos, vetores dourados, cross-check "
        "entre linguagens, benchmark de host e módulos RTL de referência. O núcleo foi mantido independente de aplicações, plataformas e semânticas externas."
    )
    doc.add_paragraph(
        "A etapa concluída demonstra correção funcional de software em ambiente host. Resultados de microcontrolador, FPGA, energia e tempo real não são inventados: "
        "estão especificados como próxima fase física, com protocolo de medição reproduzível."
    )

    doc.add_heading("1. Objetivo de engenharia", level=1)
    doc.add_paragraph("O risco central de uma arquitetura matemática inédita é permanecer apenas como definição. A implementação de referência reduz esse risco por quatro mecanismos:")
    add_numbered(doc, [
        "congela decisões de serialização que a matemática não determina sozinha;",
        "fornece duas implementações independentes;",
        "transforma propriedades matemáticas em testes executáveis;",
        "separa evidência concluída de resultados físicos ainda pendentes."
    ])

    doc.add_heading("2. Arquitetura em camadas", level=1)
    doc.add_picture(str(DOCS / "hve_embedded_architecture.png"), width=Inches(6.0))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_table(doc, ["Camada", "Responsabilidade", "Não deve conter"], [
        ("Core", "tipos, limites, E/E⁻¹, grupo, κ/Eχ", "I/O, rede, tabela semântica"),
        ("Serialization", "BASE15, CHI39, CHI40", "política de aplicação"),
        ("Frame", "versão, perfil, contagem, CRC", "criptografia implícita"),
        ("Platform adapter", "UART/SPI/CAN/TCP, buffers, RTOS", "alteração do modelo"),
        ("Application", "semântica de símbolos, τ, φ e cor", "redefinição silenciosa do protocolo"),
    ])

    doc.add_heading("3. Decisões arquiteturais", level=1)
    doc.add_heading("3.1. C11 sem alocação dinâmica", level=2)
    doc.add_paragraph("A API usa buffers fornecidos pelo chamador. Isso favorece microcontroladores, análise estática, limites previsíveis de memória e integração com RTOS.")
    doc.add_heading("3.2. Validação antes da transformação", level=2)
    doc.add_paragraph("Estados inválidos são rejeitados. A biblioteca não aplica módulo automaticamente a coordenadas de entrada, porque isso esconderia erros e destruiria interoperabilidade.")
    doc.add_heading("3.3. Ordem de rede e MSB-first", level=2)
    doc.add_paragraph("Uma única ordem elimina divergência entre plataformas little-endian e big-endian. BASE15 usa fluxo MSB-first; CHI40 usa cinco bytes big-endian.")
    doc.add_heading("3.4. NoColor como tipo distinto", level=2)
    doc.add_paragraph("NoColor não é codificado como preto. No perfil CHI40, a regra P=0 ⇒ RGB=0 cria uma representação canônica única e permite rejeição de estados redundantes.")
    doc.add_heading("3.5. CRC separado de segurança", level=2)
    doc.add_paragraph("CRC-32 detecta corrupção acidental. O relatório não o classifica como autenticação ou criptografia.")

    doc.add_heading("4. Componentes implementados", level=1)
    add_table(doc, ["Componente", "Arquivo principal", "Status"], [
        ("C API", "include/hve.h", "construído"),
        ("C core", "src/hve.c", "compilado e testado"),
        ("C tests", "tests/test_hve.c", "executado"),
        ("Python reference", "python/hve_ref.py", "executado"),
        ("Python tests", "python/test_hve_ref.py", "executado"),
        ("Cross-check", "tools/crosscheck_ctypes.py", "executado"),
        ("Golden vectors", "tests/golden_vectors.json", "gerado"),
        ("Benchmark", "benchmarks/benchmark_hve.c", "executado em host"),
        ("RTL", "hdl/*.v", "autoria concluída; simulação física pendente"),
        ("Embedded stub", "examples/embedded_loop.c", "integração demonstrativa"),
    ])

    h = doc.add_heading("5. Evidência de correção", level=1)
    h.paragraph_format.page_break_before = True
    add_table(doc, ["Teste", "Cobertura executada", "Resultado"], [
        ("BASE bijection", "32.400 estados", "zero colisões e zero erros de round-trip"),
        ("Reserved words", "368 índices", "todos rejeitados"),
        ("Group operations", "10.000 triplas pseudoaleatórias + inversos", "aprovado"),
        ("BASE15 packing", "contagens 0,1,2,7,8,9,31,257", "round-trip e padding aprovados"),
        ("HVE-χ C", "limites + 100.000 amostras", "aprovado"),
        ("HVE-χ Python", "limites + 100.000 amostras", "aprovado"),
        ("C/Python", "32.400 estados BASE + fronteiras χ", "equivalência aprovada"),
        ("Sanitizers", "suite C completa", "sem erro detectado"),
        ("CRC", "vetor padrão e corrupção", "aprovado"),
    ])

    doc.add_heading("6. Benchmark preliminar de host", level=1)
    doc.add_paragraph(
        "O benchmark serve somente para verificar que a instrumentação funciona. Em uma execução de host Linux com GCC 14.2.0, cinco milhões de pares "
        "encode+decode produziram aproximadamente 147 milhões de estados BASE/s e 135 milhões de estados HVE-χ/s. Esses números não são resultados "
        "de microcontrolador, não são comparativos e não devem ser usados no artigo final sem repetição controlada, intervalos e descrição completa do hardware."
    )

    doc.add_heading("7. Tradução para microcontrolador", level=1)
    add_bullets(doc, [
        "Nenhuma função principal requer heap.",
        "O estado BASE ocupa poucos bytes na estrutura C; o índice ocupa 16 bits em memória e 15 bits no fluxo.",
        "Divisões são por constantes pequenas; o compilador pode substituí-las por multiplicação, deslocamento ou rotinas determinísticas.",
        "O frame permite processar payload por blocos e validar CRC antes da aplicação.",
        "A API pode ser chamada em bare metal ou protegida por filas em RTOS."
    ])
    doc.add_heading("7.1. Alvos mínimos sugeridos", level=2)
    add_table(doc, ["Classe", "Exemplo de papel experimental", "Métrica central"], [
        ("Cortex-M0+/M3", "custo mínimo", "ciclos, flash, RAM"),
        ("Cortex-M4/M7", "throughput e RTOS", "latência, jitter, energia"),
        ("ESP32/RISC-V", "rede/edge", "throughput fim a fim"),
        ("Linux ARM", "gateway", "integração e concorrência"),
    ])

    doc.add_heading("8. Tradução para FPGA", level=1)
    doc.add_paragraph("O encoder é um encadeamento de multiplicações por constantes e somas. O decoder de referência usa divisão e módulo por 9, 5 e 2. Para otimização física, há três estratégias:")
    add_numbered(doc, [
        "operadores constantes deixados ao sintetizador;",
        "recíprocos multiplicativos e correção;",
        "máquina sequencial de divisões reduzidas, trocando latência por área."
    ])
    doc.add_paragraph("O RTL incluído é intencionalmente legível. A versão de publicação deve reportar síntese em uma família declarada e comparar ao menos duas microarquiteturas.")

    doc.add_heading("9. Protocolo de medição física", level=1)
    add_table(doc, ["Métrica", "Procedimento mínimo", "Unidade"], [
        ("Latência", "GPIO de início/fim + analisador lógico; 10⁴ repetições", "ns ou ciclos"),
        ("Throughput", "lote ≥10⁶ estados, excluindo setup", "estado/s"),
        ("Jitter", "distribuição p50, p95, p99 e máximo", "ns ou ciclos"),
        ("Flash", "map file do linker", "bytes"),
        ("RAM", "estática + pico de stack medido", "bytes"),
        ("Energia", "shunt/medidor, potência integrada por lote", "nJ/estado"),
        ("FPGA area", "relatório pós-síntese", "LUT, FF, BRAM, DSP"),
        ("FPGA timing", "pior slack e Fmax", "ns, MHz"),
    ])
    doc.add_paragraph("Cada resultado deve declarar compilador, flags, clock, tensão, temperatura, placa, revisão de silício, sistema operacional/RTOS e estado de cache.")

    doc.add_heading("10. Desenho experimental para a JSA", level=1)
    doc.add_paragraph("O artigo de arquitetura de sistemas deve usar um caso real, não apenas o codec isolado. O caso recomendado é uma cadeia edge com estados simbólicos, auxiliares e cromáticos:")
    add_numbered(doc, [
        "nó sensor ou interface produz HVEState;",
        "firmware codifica BASE15 ou CHI40;",
        "frame HVE1 é transmitido por UART/SPI/CAN/TCP;",
        "gateway valida CRC, decodifica e registra;",
        "aplicação usa τ/φ e cor como metadados versionados."
    ])
    doc.add_paragraph("Baselines: estrutura binária equivalente, CBOR/MessagePack para objetos estruturados e UTF-8 somente quando a função comparada for texto. Não se compara cobertura desigual como se fosse função idêntica.")

    doc.add_heading("11. Riscos e controles", level=1)
    add_table(doc, ["Risco", "Controle"], [
        ("confundir novidade arquitetural com novidade de cada operação", "seção explícita de contribuição integrada"),
        ("overclaim de desempenho", "separar host preliminar de hardware medido"),
        ("semântica indefinida de τ/φ", "perfil de aplicação versionado"),
        ("incompatibilidade de packing", "vetores dourados e ordem normativa"),
        ("black/NoColor colidirem", "tipo distinto e validação P=0"),
        ("CRC ser tratado como segurança", "ameaças e não-claims explícitos"),
        ("FPGA não otimizado", "duas arquiteturas e relatório pós-síntese"),
    ], font_size=8)

    h12 = doc.add_heading("12. Próxima fase obrigatória", level=1)
    h12.paragraph_format.page_break_before = True
    add_numbered(doc, [
        "Selecionar duas placas MCU e uma FPGA.",
        "Portar a biblioteca e congelar toolchains.",
        "Executar o protocolo físico e armazenar dados brutos.",
        "Gerar scripts estatísticos e intervalos de confiança.",
        "Completar o artigo JSA com resultados reais e comparação justa.",
        "Publicar repositório versionado e arquivar release com DOI."
    ])

    doc.add_heading("Conclusão", level=1)
    doc.add_paragraph(
        "O HVE deixou de ser apenas uma formulação abstrata: existe agora uma especificação de perfil, código executável em duas linguagens, testes exaustivos, "
        "serialização, enquadramento e RTL de referência. O limite preservado é científico: desempenho embarcado e hardware não foi presumido. A arquitetura está "
        "tecnicamente pronta para a fase física e para a construção de um artigo orientado à Journal of Systems Architecture."
    )

    output = DOCS / "HVE_Embedded_Reference_Architecture_Relatorio_Tecnico_PT.docx"
    doc.save(output)
    return output


def build_article():
    title = "HVE-720 Embedded: A Deterministic Modular Encoding Architecture for Structured Symbolic and Chromatic States"
    doc = Document()
    configure_doc(doc, "HVE-720 Embedded — JSA Draft")
    add_title_page(doc, title, "Journal of Systems Architecture-oriented research manuscript", "DRAFT — NOT READY FOR SUBMISSION UNTIL HARDWARE RESULTS ARE INSERTED")

    doc.add_heading("Abstract", level=1)
    doc.add_paragraph(
        "This paper presents HVE-720 Embedded, a deterministic software and serialization architecture derived from a finite modular state model. "
        "The core state space is G = Z360 × Z2 × Z5 × Z9, containing 32,400 states and admitting an exact mixed-radix bijection to 15-bit indices. "
        "The architecture separates the mathematical core, serialization profiles, integrity framing, platform adapters, and application semantics. "
        "A pointed chromatic extension distinguishes the absence of color from RGB black and supports both a compact 39-bit monolithic index and a byte-aligned 40-bit profile. "
        "We provide an allocation-free C11 implementation, an independent Python executable specification, exhaustive verification of all BASE states, rejection tests for all reserved words, deterministic randomized chromatic tests, cross-language conformance, and reference RTL. "
        "The current work establishes functional correctness and an auditable embedded architecture. Physical MCU and FPGA measurements are specified as a reproducible protocol and must be completed before submission."
    )
    doc.add_paragraph("Keywords: embedded encoding; finite Abelian group; deterministic serialization; software architecture; symbolic states; chromatic metadata; FPGA; reproducibility")

    doc.add_heading("1. Introduction", level=1)
    doc.add_paragraph(
        "Conventional character encodings prioritize symbol identity and interoperability. Embedded applications may additionally require compact auxiliary state, deterministic validation, "
        "fixed representations, explicit invalid regions, and optional multimodal attributes. HVE-720 was formulated as a finite symbolic-state architecture rather than as a replacement for Unicode. "
        "The systems problem addressed here is how to turn that formal object into a portable, testable, and platform-independent embedded architecture without weakening its mathematical invariants."
    )
    doc.add_paragraph(
        "The contribution is not the isolated use of cyclic groups, mixed-radix arithmetic, CRCs, or bit packing. It is the coordinated architecture that binds a finite state model, a reversible index, "
        "explicit invalid words, distinct color absence, byte- and bit-level profiles, deterministic framing, allocation-free software, independent conformance implementations, and a path to hardware realization."
    )
    doc.add_heading("1.1. Contributions", level=2)
    add_bullets(doc, [
        "a layered embedded architecture that preserves the HVE mathematical core;",
        "a normative BASE15 stream profile and two HVE-chi profiles;",
        "a canonical distinction between NoColor and RGB black;",
        "a fixed HVE1 frame with exact length derivation and CRC validation;",
        "an allocation-free C11 implementation and independent Python specification;",
        "exhaustive BASE verification and cross-language conformance;",
        "reference Verilog modules and a hardware measurement protocol."
    ])

    doc.add_heading("2. Formal state model", level=1)
    add_equation(doc, "G = Z₃₆₀ × Z₂ × Z₅ × Z₉,    |G| = 32,400", 1)
    add_equation(doc, "E(θ,s,τ,φ) = (((θ·2+s)·5+τ)·9+φ)", 2)
    doc.add_paragraph("The inverse is obtained by successive Euclidean divisions by 9, 5, and 2. The valid index interval is [0, 32399]; the remaining 368 words in the 15-bit space are invalid or reserved.")

    doc.add_heading("3. Architectural separation", level=1)
    doc.add_picture(str(DOCS / "hve_embedded_architecture.png"), width=Inches(6.7))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(
        "The architecture enforces a strict boundary between formal state validity and application meaning. The core does not know UART, TCP, Unicode mappings, display semantics, or an ontology for auxiliary coordinates. "
        "Conversely, platform adapters cannot redefine valid states or bit order."
    )

    doc.add_heading("4. Serialization profiles", level=1)
    doc.add_heading("4.1. BASE15", level=2)
    doc.add_paragraph("BASE indices are concatenated MSB-first. The payload length for N states is ceil(15N/8). Unused least-significant bits in the last byte are zero and validated.")
    doc.add_heading("4.2. Pointed chromatic extension", level=2)
    add_equation(doc, "C* = {NoColor} ⊔ {0,…,255}³", 3)
    add_equation(doc, "Eχ(g,c) = E(g)(2²⁴+1) + κ(c)", 4)
    doc.add_paragraph("κ(NoColor)=0 and κ(r,g,b)=1+65536r+256g+b. Consequently, NoColor and black are distinct states.")
    doc.add_heading("4.3. CHI39 and CHI40", level=2)
    doc.add_picture(str(DOCS / "hve_chi40_layout.png"), width=Inches(6.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph("CHI40 uses a 15-bit BASE index, one presence bit, and 24 RGB bits. P=0 with nonzero RGB is rejected to preserve a unique representation.")

    doc.add_heading("5. HVE1 framing", level=1)
    add_table(doc, ["Field", "Bytes", "Purpose"], [
        ("Magic", "4", "HVE1"),
        ("Version", "1", "major compatibility"),
        ("Profile", "1", "BASE15 or CHI40"),
        ("Flags", "2", "profile extensions"),
        ("State count", "4", "exact payload derivation"),
        ("CRC-32", "4", "accidental corruption detection"),
    ])
    doc.add_paragraph("The parser validates all header fields, exact frame size, and CRC before exposing the payload. CRC is not presented as authentication.")

    doc.add_heading("6. Reference software architecture", level=1)
    doc.add_paragraph(
        "The C implementation uses caller-owned buffers and no mandatory dynamic allocation. Error codes distinguish invalid coordinates, reserved words, insufficient buffers, invalid color states, padding violations, malformed frames, CRC failures, unsupported profiles, and size overflow. "
        "The Python implementation mirrors the same invariants and serves as an executable specification rather than a wrapper around the C code."
    )
    add_code(doc, "hve_base_encode / hve_base_decode\nhve_base15_pack / hve_base15_unpack\nhve_chi_encode / hve_chi_decode\nhve_chi40_pack / hve_chi40_unpack\nhve_frame_write_header / hve_frame_parse")

    h7 = doc.add_heading("7. Verification methodology", level=1)
    h7.paragraph_format.page_break_before = True
    add_table(doc, ["Property", "Method"], [
        ("BASE bijection", "exhaustive enumeration of 32,400 states"),
        ("invalid interval", "exhaustive rejection of 368 words"),
        ("group operations", "identity/inverse plus deterministic randomized associativity"),
        ("bit packing", "boundary counts and corrupted padding"),
        ("chromatic mapping", "NoColor, black, white, boundaries, 100,000 random cases per implementation"),
        ("language conformance", "exhaustive C/Python BASE cross-check"),
        ("memory safety", "AddressSanitizer and UndefinedBehaviorSanitizer"),
        ("frame integrity", "known CRC vector and payload corruption"),
    ])

    doc.add_heading("8. Verified software results", level=1)
    doc.add_paragraph(
        "The complete BASE domain produced 32,400 distinct indices and zero round-trip errors in both implementations. All 368 reserved words were rejected. "
        "C and Python agreed on every BASE state. Boundary and randomized chromatic tests passed, including the distinction between NoColor and black and the rejection of noncanonical P=0 states. "
        "The sanitized C suite completed without a reported memory or undefined-behavior fault."
    )
    doc.add_paragraph(
        "A host benchmark confirmed that the measurement harness operates, but host throughput is not treated as an embedded-system result. Publication-quality performance claims require the physical protocol in Section 10."
    )

    doc.add_heading("9. Reference RTL", level=1)
    doc.add_paragraph(
        "The encoder maps naturally to constant multipliers and additions. The decoder uses division and remainder by constants 9, 5, and 2. The provided RTL is deliberately transparent and can be transformed into reciprocal-based or sequential microarchitectures. "
        "No FPGA resource, frequency, latency, or power result is claimed in this draft because no synthesis tool or target board was available in the implementation environment."
    )

    doc.add_heading("10. Physical evaluation protocol", level=1)
    add_table(doc, ["Target", "Required result"], [
        ("MCU-A low-end", "cycles/state, flash, RAM, energy/state"),
        ("MCU-B RTOS/edge", "latency distribution, jitter, throughput, network overhead"),
        ("FPGA", "LUT/FF/BRAM/DSP, Fmax, latency, throughput, power"),
    ])
    doc.add_paragraph(
        "Measurements shall report board, device revision, voltage, clock, compiler/tool version, optimization flags, cache state, RTOS configuration, sample count, warm-up, raw data, and statistical intervals. "
        "At least one equivalent fixed binary structure must be used as a structural baseline. CBOR or MessagePack may be used for object serialization. UTF-8 is a text baseline only under equivalent coverage and semantics."
    )

    doc.add_heading("11. Embedded case study design", level=1)
    doc.add_paragraph(
        "The proposed case study is a deterministic edge pipeline that transports symbolic identity, auxiliary state, and optional color. A source device produces states, serializes them, frames them, and sends them to a gateway. "
        "The gateway validates CRC, rejects invalid states, reconstructs the exact HVE tuple, and exposes application metadata. The evaluation separates codec time, framing time, transport time, memory, and energy."
    )
    doc.add_paragraph("[RESULTS TO BE INSERTED AFTER PHYSICAL EXECUTION. NO PLACEHOLDER NUMBER MAY BE CONVERTED INTO A CLAIM.]")

    doc.add_heading("12. Discussion", level=1)
    doc.add_paragraph(
        "The system-level novelty is the preservation of a finite algebraic state object across software and serialization layers with explicit invalid regions and canonical chromatic absence. "
        "The architecture is not a universal text replacement, does not infer semantics from coordinate proximity, and does not provide cryptographic protection. Its value must be evaluated where deterministic structured states are required."
    )

    doc.add_heading("13. Limitations", level=1)
    add_bullets(doc, [
        "the symbolic mapping table remains an external versioned artifact;",
        "the meanings of tau and phi are application-defined;",
        "RGB does not identify a complete colorimetric profile;",
        "BASE15 is not naturally byte-aligned;",
        "physical performance and energy remain unmeasured in this draft;",
        "RTL has not yet been simulator- and synthesis-verified in a vendor flow;",
        "comparative advantage depends on equivalent functional requirements."
    ])

    doc.add_heading("14. Conclusion", level=1)
    doc.add_paragraph(
        "HVE-720 Embedded converts a finite mathematical encoding architecture into a deterministic and testable systems design. The software core, serialization profiles, framing, and conformance evidence are complete at host level. "
        "The remaining work is physical rather than conceptual: MCU porting, FPGA synthesis, controlled measurements, and a real edge case study. The separation of completed evidence from pending measurements makes the architecture suitable for rigorous continuation rather than speculative presentation."
    )

    doc.add_heading("Declarations", level=1)
    doc.add_paragraph("Funding: No external funding was received for this work.")
    doc.add_paragraph("Competing interests: The author declares no competing interests.")
    doc.add_paragraph("Data and code availability: The submission version shall identify a public, versioned repository and archived release.")
    doc.add_paragraph("Use of AI tools: Language editing and document structuring assistance shall be disclosed according to the target journal's current policy; all technical content and claims remain the author's responsibility.")

    output = ARTICLE / "HVE720_Embedded_JSA_Research_Article_Draft_EN.docx"
    doc.save(output)
    return output


def build_measurement_protocol():
    title = "HVE Embedded — Protocolo Experimental de Hardware"
    doc = Document()
    configure_doc(doc, title)
    add_title_page(doc, title, "MCU, RTOS, transporte, FPGA e energia", "LABORATORY EXECUTION PROTOCOL")
    doc.add_heading("1. Regra de integridade", level=1)
    doc.add_paragraph("Nenhum número de hardware pode ser inserido no artigo sem arquivo bruto, configuração reproduzível e identificação do alvo. Este protocolo define o mínimo aceitável.")
    doc.add_heading("2. Matriz de alvos", level=1)
    add_table(doc, ["ID", "Classe", "Requisito"], [
        ("MCU-A", "microcontrolador de baixo consumo", "bare metal, clock fixo"),
        ("MCU-B", "microcontrolador/edge", "RTOS e comunicação"),
        ("FPGA-A", "FPGA de uso geral", "síntese de encoder/decoder"),
        ("HOST", "referência", "Linux, compilador e CPU declarados"),
    ])
    doc.add_heading("3. Build congelado", level=1)
    add_bullets(doc, [
        "hash do commit e tag;",
        "versão do compilador/sintetizador;",
        "flags completas;",
        "linker script, bibliotecas e RTOS;",
        "clock, tensão e configuração de memória/cache;",
        "arquivo binário e map file arquivados."
    ])
    doc.add_heading("4. Casos de carga", level=1)
    add_table(doc, ["Caso", "Descrição"], [
        ("B0", "BASE encode somente"),
        ("B1", "BASE decode somente"),
        ("B2", "BASE encode+pack+frame"),
        ("B3", "frame parse+unpack+decode"),
        ("C0", "CHI40 encode"),
        ("C1", "CHI40 decode"),
        ("C2", "CHI encode monolítico"),
        ("E0", "pipeline fim a fim com transporte"),
    ])
    doc.add_heading("5. Latência e throughput", level=1)
    add_numbered(doc, [
        "Executar 1.000 ciclos de aquecimento.",
        "Executar no mínimo 10.000 amostras de latência individual.",
        "Executar lote de pelo menos 1.000.000 estados para throughput.",
        "Usar contador de ciclos e GPIO externo quando possível.",
        "Reportar média, desvio, mediana, p95, p99, máximo e intervalo de confiança."
    ])
    doc.add_heading("6. Memória", level=1)
    add_bullets(doc, [
        "flash/text/rodata/data/bss pelo map file;",
        "stack por canário ou ferramenta do RTOS;",
        "heap deve permanecer zero na biblioteca de referência;",
        "buffers de aplicação devem ser reportados separadamente."
    ])
    doc.add_heading("7. Energia", level=1)
    doc.add_paragraph("Medir potência de repouso e potência ativa. Integrar energia sobre lote conhecido e subtrair baseline equivalente. Reportar instrumento, taxa de amostragem, shunt, calibração, tensão e incerteza.")
    doc.add_heading("8. FPGA", level=1)
    add_bullets(doc, [
        "simulação exaustiva do testbench BASE;",
        "lint e síntese sem warnings críticos;",
        "relatório de recursos e timing;",
        "duas microarquiteturas do decoder;",
        "testes em hardware com vetores dourados;",
        "potência estática e dinâmica sob atividade declarada."
    ])
    doc.add_heading("9. Baselines", level=1)
    add_bullets(doc, [
        "estrutura binária fixa contendo exatamente os mesmos campos;",
        "CBOR ou MessagePack para objeto estruturado equivalente;",
        "UTF-8 somente para fluxo textual e com fallback contabilizado;",
        "nenhuma comparação pode omitir metadados transportados pelo HVE."
    ])
    doc.add_heading("10. Artefatos de publicação", level=1)
    add_numbered(doc, [
        "dados brutos CSV/JSON;",
        "scripts de análise;",
        "gráficos gerados automaticamente;",
        "logs de build e síntese;",
        "binários e bitstreams;",
        "fotos da bancada e esquema de medição;",
        "README de reprodução;",
        "release arquivado com DOI."
    ])
    output = DOCS / "HVE_Embedded_Protocolo_Experimental_Hardware_PT.docx"
    doc.save(output)
    return output


if __name__ == "__main__":
    outputs = [build_spec(), build_report(), build_article(), build_measurement_protocol()]
    for output in outputs:
        print(output)
