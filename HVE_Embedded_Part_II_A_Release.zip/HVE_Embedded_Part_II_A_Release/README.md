# HVE Embedded Part II-A

Executable start of the physical-validation phase for HVE-720 Embedded.

## What this package adds

- portable C benchmark core using the Part I HVE API;
- deterministic workloads for BASE15, CHI40, frame parsing, and fieldwise baselines;
- single-line command protocol and JSON measurement records;
- complete Raspberry Pi Pico / RP2040 target project;
- STM32F446RE DWT cycle-counter drop-in port;
- host-mock target for validating the control and analysis pipeline;
- raw JSONL schema, plans, validation, statistical analysis, and power integration;
- sequential FPGA decoder, pipelined encoder, exhaustive testbench, iCEBreaker flow;
- independent Python cycle model checking all 32,768 input words;
- Portuguese implementation report and updated JSA-oriented manuscript draft.

## Evidence boundary

### Executed in this package

- portable C tests;
- exhaustive HVE and baseline round-trips;
- sanitizer and independent Clang builds;
- host-mock controller execution across all 12 workloads;
- 36 JSONL measurements validated with zero schema errors;
- automated statistical analysis;
- synthetic power-integration test;
- exhaustive Python model of the sequential decoder: 32,400 valid words, 368 reserved words, zero failures;
- DOCX rendering and visual inspection.

### Authored but not executed here

- RP2040 cross-build and physical run;
- STM32Cube build and physical run;
- Verilog simulation;
- Yosys/nextpnr synthesis and iCEBreaker programming;
- physical timing, stack, memory, energy, area, Fmax, and thermal measurements.

No host result may be reported as MCU or FPGA evidence.

## Host build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build
ctest --test-dir build --output-on-failure
```

## Validate the laboratory pipeline

```sh
python tools/lab_controller.py \
  --subprocess ./build/hve_host_target \
  --plan data/plans/quick_plan.json \
  --output data/generated/host_mock_raw.jsonl

python tools/validate_dataset.py \
  data/generated/host_mock_raw.jsonl \
  --schema data/schema/hve_measurement.schema.json

python tools/analyze_results.py \
  data/generated/host_mock_raw.jsonl \
  --output-dir data/generated/host_mock_analysis
```

## Physical execution order

1. RP2040 quick plan and self-test.
2. STM32F446RE quick plan and self-test.
3. Map-file and stack measurements.
4. Publication plan with 30 repetitions.
5. Marker-gated power traces.
6. Verilog simulation.
7. iCE40 synthesis and timing closure.
8. iCEBreaker self-test and physical evidence.
9. Application-level edge case study.
10. Insert only traceable results into the JSA manuscript.

## Key documents

- `docs/HVE_Embedded_Part_II_A_Implementation_Report_PT.docx`
- `article/HVE720_Embedded_JSA_Research_Article_Draft_v2_EN.docx`
- `docs/LAB_EXECUTION_CHECKLIST_PT.md`
- `PART_II_A_STATUS.md`

## Authorship and licensing

Scientific authorship: Charles de Paula Eugênio.

No open-source license is assigned by this package. Select a license before public distribution. Until then, treat the source as all rights reserved.
