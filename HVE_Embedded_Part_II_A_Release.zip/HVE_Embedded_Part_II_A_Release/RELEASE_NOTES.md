# HVE Embedded Part II-A — Release notes

This release starts the physical-validation phase without manufacturing results.

## Verified inside the build environment

- portable C library and workload engine;
- GCC, Clang, AddressSanitizer and UndefinedBehaviorSanitizer tests;
- exhaustive BASE and baseline correctness checks;
- 36 host-harness measurements across 12 workloads;
- JSON Schema validation with zero errors;
- statistical analysis pipeline;
- synthetic marker-gated energy integration;
- independent sequential-decoder model over all 32,768 words;
- rendered and visually inspected DOCX files.

## Requires external execution

- RP2040 and STM32 physical firmware runs;
- HDL simulation and iCE40 synthesis;
- iCEBreaker programming;
- real memory, timing, power and energy measurements.
