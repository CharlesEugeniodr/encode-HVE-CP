# Primary technical sources used for target definitions

1. Raspberry Pi Pico SDK documentation — C/C++ SDK, hardware timer and clock APIs.
   https://www.raspberrypi.com/documentation/pico-sdk/
   https://www.raspberrypi.com/documentation/pico-sdk/hardware.html

2. STMicroelectronics NUCLEO-F446RE product documentation and STM32Cube resources.
   https://www.st.com/en/evaluation-tools/nucleo-f446re.html

3. Arm CMSIS-Core documentation for standardized Cortex-M core-register access.
   https://arm-software.github.io/CMSIS_6/latest/Core/index.html

4. iCEBreaker hardware documentation and product information.
   https://docs.icebreaker-fpga.org/hardware/icebreaker/
   https://1bitsquared.com/products/icebreaker

5. YosysHQ nextpnr documentation for the open iCE40 place-and-route flow.
   https://github.com/YosysHQ/nextpnr

The package does not copy vendor SDKs, startup code, linker scripts, or proprietary tool output. Exact versions must be frozen during physical execution.
