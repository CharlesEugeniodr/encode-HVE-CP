# Part II-A status

## Completed

1. Portable workload engine and counter-wrap handling.
2. BASE15, CHI40, frame and direct-coordinate baselines.
3. Target command grammar and JSON evidence format.
4. Host-mock transport, capture, schema validation and analysis.
5. RP2040 Pico SDK project.
6. STM32F446RE DWT/Cube drop-in port.
7. Marker-gated energy integration.
8. Sequential restoring-divider decoder RTL.
9. Three-stage encoder RTL.
10. Exhaustive RTL testbench and iCEBreaker flow files.
11. Independent Python cycle model with zero failures over the complete 15-bit domain.
12. Portuguese implementation report and JSA draft v2.
13. CMake, GCC, Clang, ASan and UBSan host validation.

## Pending physical Part II-B

1. Obtain or declare exact board revisions.
2. Freeze Pico SDK and STM32Cube versions.
3. Cross-compile and flash both MCU targets.
4. Execute quick plan after cold boot and warm reset.
5. Execute publication plan with 30 repetitions.
6. Archive ELF, map, binary, logs and SHA-256.
7. Capture power traces with marker GPIO.
8. Install Icarus Verilog or Verilator and run exhaustive testbench.
9. Synthesize with Yosys/nextpnr and archive area/timing logs.
10. Program iCEBreaker and capture physical pass/fail evidence.

## Pending application Part II-C

- deterministic edge pipeline with source device, framed HVE stream, receiving gateway, rejection tests, transport separation, and end-to-end latency/energy.
