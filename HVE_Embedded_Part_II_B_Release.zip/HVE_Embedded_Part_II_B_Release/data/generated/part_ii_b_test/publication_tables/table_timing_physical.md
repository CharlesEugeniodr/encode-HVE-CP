# HVE Part II-B publication tables

No physical MCU measurements were found. No timing table may be inserted into the article.
