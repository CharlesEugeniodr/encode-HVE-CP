#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j2
ctest --test-dir build --output-on-failure
python -m py_compile tools/*.py scripts/build_docs.py
python tools/rtl_cycle_model.py --output data/generated/rtl_cycle_model_report.json
python tools/test_tools.py
python tools/lab_controller.py --subprocess ./build/hve_host_target --plan data/plans/quick_plan.json --output data/generated/host_mock_raw.jsonl
python tools/validate_dataset.py data/generated/host_mock_raw.jsonl --schema data/schema/hve_measurement.schema.json
python tools/analyze_results.py data/generated/host_mock_raw.jsonl --output-dir data/generated/host_mock_analysis

echo "ALL PART II-A EXECUTABLE TESTS PASSED"
