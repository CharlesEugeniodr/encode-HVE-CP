from __future__ import annotations

from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Cm, Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
ARTICLE = ROOT / "article"


def make_figures() -> None:
    fig, ax = plt.subplots(figsize=(10, 4.8))
    ax.axis("off")
    boxes = [
        (0.02, 0.58, 0.17, 0.25, "HVE mathematical core\nBASE15 / CHI40"),
        (0.22, 0.58, 0.17, 0.25, "Portable C bench core\nworkloads + baselines"),
        (0.42, 0.58, 0.17, 0.25, "Platform adapters\nRP2040 / STM32"),
        (0.62, 0.58, 0.17, 0.25, "Control channel\nASCII commands + JSON"),
        (0.82, 0.58, 0.16, 0.25, "Raw evidence\nJSONL + build logs"),
        (0.22, 0.10, 0.17, 0.25, "FPGA RTL\nsequential decoder"),
        (0.42, 0.10, 0.17, 0.25, "Physical markers\nGPIO / power gate"),
        (0.62, 0.10, 0.17, 0.25, "Statistical analysis\nCI / p95 / p99"),
    ]
    for x, y, w, h, text in boxes:
        rect = plt.Rectangle((x, y), w, h, fill=False, linewidth=1.5)
        ax.add_patch(rect)
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=9)
    arrows = [
        ((0.19, 0.705), (0.22, 0.705)), ((0.39, 0.705), (0.42, 0.705)),
        ((0.59, 0.705), (0.62, 0.705)), ((0.79, 0.705), (0.82, 0.705)),
        ((0.305, 0.58), (0.305, 0.35)), ((0.505, 0.58), (0.505, 0.35)),
        ((0.705, 0.58), (0.705, 0.35)),
    ]
    for a, b in arrows:
        ax.annotate("", xy=b, xytext=a, arrowprops=dict(arrowstyle="->", linewidth=1.2))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    fig.tight_layout()
    fig.savefig(DOCS / "part2a_architecture.png", dpi=200, bbox_inches="tight")
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(10, 3.8))
    ax.axis("off")
    labels = ["Frozen build", "Target self-test", "Warm-up", "Timed workload", "Raw JSONL", "Schema validation", "Statistical summary", "Article table"]
    xs = [0.02 + i * 0.12 for i in range(len(labels))]
    for i, (x, label) in enumerate(zip(xs, labels)):
        rect = plt.Rectangle((x, 0.36), 0.1, 0.28, fill=False, linewidth=1.4)
        ax.add_patch(rect)
        ax.text(x + 0.05, 0.5, label, ha="center", va="center", fontsize=8, wrap=True)
        if i < len(labels) - 1:
            ax.annotate("", xy=(xs[i + 1], 0.5), xytext=(x + 0.1, 0.5), arrowprops=dict(arrowstyle="->"))
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    fig.tight_layout()
    fig.savefig(DOCS / "measurement_pipeline.png", dpi=200, bbox_inches="tight")
    plt.close(fig)


def set_shading(cell, fill="E7E6E6"):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell(cell, text, bold=False, size=8.5):
    cell.text = ""
    p = cell.paragraphs[0]
    r = p.add_run(str(text))
    r.bold = bold
    r.font.name = "Times New Roman"
    r.font.size = Pt(size)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def add_table(doc, headers, rows, font_size=8.5):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(headers):
        set_cell(table.rows[0].cells[i], h, bold=True, size=font_size)
        set_shading(table.rows[0].cells[i])
    for row in rows:
        cells = table.add_row().cells
        for i, value in enumerate(row):
            set_cell(cells[i], value, size=font_size)
        trPr = cells[0]._tc.getparent().get_or_add_trPr()
        cant_split = OxmlElement("w:cantSplit")
        trPr.append(cant_split)
    return table


def configure(doc: Document, title: str, footer: str):
    sec = doc.sections[0]
    sec.top_margin = Cm(2.1)
    sec.bottom_margin = Cm(2.0)
    sec.left_margin = Cm(2.3)
    sec.right_margin = Cm(2.2)
    sec.header_distance = Cm(0.9)
    sec.footer_distance = Cm(0.9)

    styles = doc.styles
    normal = styles["Normal"]
    normal.font.name = "Times New Roman"
    normal.font.size = Pt(10.5)
    normal.paragraph_format.line_spacing = 1.08
    normal.paragraph_format.space_after = Pt(5)
    for name, size in [("Title", 19), ("Subtitle", 11), ("Heading 1", 14), ("Heading 2", 12), ("Heading 3", 10.5)]:
        st = styles[name]
        st.font.name = "Times New Roman"
        st.font.size = Pt(size)
        st.font.bold = "Heading" in name or name == "Title"
        st.paragraph_format.space_before = Pt(10)
        st.paragraph_format.space_after = Pt(4)
    if "Code Block" not in [s.name for s in styles]:
        code = styles.add_style("Code Block", WD_STYLE_TYPE.PARAGRAPH)
        code.font.name = "Courier New"
        code.font.size = Pt(8)
        code.paragraph_format.left_indent = Cm(0.6)
        code.paragraph_format.right_indent = Cm(0.3)
        code.paragraph_format.space_after = Pt(5)
        code.paragraph_format.line_spacing = 1.0

    header = sec.header.paragraphs[0]
    header.text = title
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in header.runs:
        r.font.name = "Times New Roman"
        r.font.size = Pt(8)
    fp = sec.footer.paragraphs[0]
    fp.text = footer
    fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for r in fp.runs:
        r.font.name = "Times New Roman"
        r.font.size = Pt(8)

    cp = doc.core_properties
    cp.title = title
    cp.author = "Charles de Paula Eugênio"
    cp.subject = "HVE-720 Embedded Part II-A"
    cp.keywords = "HVE-720, embedded systems, benchmarking, RP2040, STM32, FPGA, reproducibility"


def title_page(doc, title, subtitle, status, version="2.0-A"):
    p = doc.add_paragraph(style="Title")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(title)
    p = doc.add_paragraph(style="Subtitle")
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(subtitle)
    doc.add_paragraph("")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Charles de Paula Eugênio")
    r.bold = True
    r.font.size = Pt(12)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Independent Researcher — Parauapebas, Pará, Brazil")
    doc.add_paragraph("")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(status)
    r.bold = True
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(f"Version {version} — July 2026")
    doc.add_page_break()


def bullets(doc, items):
    for item in items:
        doc.add_paragraph(item, style="List Bullet")


def numbered(doc, items):
    for item in items:
        doc.add_paragraph(item, style="List Number")


def code(doc, text):
    p = doc.add_paragraph(style="Code Block")
    p.add_run(text)


def build_report_pt() -> Path:
    title = "HVE Embedded — Parte II-A"
    doc = Document()
    configure(doc, title, "Charles de Paula Eugênio — Part II-A Laboratory Build")
    title_page(doc, title, "Implementação do laboratório, firmware de referência e trilha FPGA", "IMPLEMENTATION AND LABORATORY START PACKAGE")

    doc.add_heading("Resumo executivo", level=1)
    doc.add_paragraph(
        "A Parte II foi iniciada como uma fase de validação física controlada. Este pacote não inventa medições: ele constrói a infraestrutura que torna as medições possíveis, rastreáveis e publicáveis. Foram implementados um núcleo portátil de benchmark, duas linhas de portabilidade para microcontroladores, um protocolo de comando determinístico, coleta em JSONL, validação por esquema, análise estatística, integração de energia e uma microarquitetura FPGA sequencial que evita divisores genéricos no caminho de dados."
    )
    doc.add_paragraph(
        "A evidência concluída nesta subfase é de software e modelagem independente. RP2040, STM32F446RE e iCEBreaker foram definidos como alvos de referência, mas seus números físicos só podem ser preenchidos após execução em placas reais e preservação dos arquivos brutos."
    )

    doc.add_heading("1. Objetivo e fronteira científica", level=1)
    bullets(doc, [
        "Transformar o protocolo experimental da Parte I em firmware, comandos, formatos de evidência e scripts executáveis.",
        "Preservar exatamente as invariantes HVE-720, BASE15, CHI40, NoColor e palavras reservadas.",
        "Separar custo do codec, custo de serialização, custo de frame, custo de transporte e custo de aplicação.",
        "Produzir baselines estruturalmente equivalentes sem reduzir artificialmente a função transportada.",
        "Não converter resultados do computador hospedeiro em alegações de MCU, FPGA, energia ou tempo real."
    ])

    doc.add_heading("2. Estado da execução", level=1)
    add_table(doc, ["Classe", "Componente", "Estado", "Valor probatório"], [
        ("A", "Biblioteca C, benchmark e protocolo", "Compilado e testado no host", "Correção da infraestrutura"),
        ("A", "Controller, schema e análise", "Executado em 36 medições host-mock", "Validação do fluxo de dados"),
        ("B", "Modelo Python do decoder sequencial", "32.400 válidos + 368 reservados", "Validação algorítmica independente"),
        ("C", "Porta RP2040", "Código completo; SDK/placa pendentes", "Implementação pronta para build físico"),
        ("C", "Porta STM32F446RE", "Drop-in Cube; placa pendente", "Implementação pronta para integração"),
        ("C", "RTL e fluxo iCEBreaker", "Autoria concluída; simulador/síntese pendentes", "Arquitetura pronta para ferramentas"),
        ("D", "Latência, energia, área e timing físicos", "Não medidos", "Nenhuma alegação permitida")
    ])

    doc.add_heading("3. Arquitetura da Parte II-A", level=1)
    doc.add_picture(str(DOCS / "part2a_architecture.png"), width=Inches(6.4))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(
        "O núcleo matemático permanece independente. A camada de benchmark chama a mesma API C usada na Parte I. Adaptadores de plataforma fornecem apenas contador, frequência, GPIO de marcação e canal de texto. O computador de controle não calcula o resultado do codec; ele agenda execuções, registra respostas e verifica o esquema."
    )

    doc.add_heading("4. Alvos congelados para a primeira campanha", level=1)
    add_table(doc, ["Alvo", "Função", "Temporização", "Interface", "Motivo"], [
        ("Raspberry Pi Pico / RP2040", "MCU simples, sem RTOS", "timer de hardware em microssegundos", "USB CDC", "reprodutibilidade e baixo atrito"),
        ("NUCLEO-F446RE", "Cortex-M4 com contador de ciclos", "DWT CYCCNT de 32 bits", "ST-LINK VCP / USART2", "medição em ciclos e ecossistema industrial"),
        ("iCEBreaker / iCE40UP5K", "FPGA de referência", "clock externo de 12 MHz", "LED de autoteste e fluxo aberto", "síntese auditável com Yosys/nextpnr")
    ])
    doc.add_paragraph(
        "A seleção é uma referência de laboratório, não uma restrição do HVE. Outros alvos podem ser adicionados, mas um artigo não deve misturar placas sem congelar versões, clocks, tensões e toolchains."
    )

    doc.add_heading("5. Protocolo de controle", level=1)
    code(doc, "PING\nINFO\nSELFTEST\nRUN <WORKLOAD> <ITERATIONS> <BATCH> <SEED> [WARMUP]\nQUIT")
    doc.add_paragraph(
        "Cada comando produz exatamente um objeto JSON em uma única linha. O firmware não recebe objetos JSON; isso evita incorporar um parser pesado no alvo. O controller converte um plano declarativo em comandos, adiciona data UTC, repetição, classe de ambiente e identificador do plano, e grava JSONL sem reescrever os campos produzidos pelo dispositivo."
    )

    doc.add_heading("6. Workloads implementados", level=1)
    add_table(doc, ["Workload", "Objeto medido", "Unidade lógica"], [
        ("BASE_ENCODE", "tupla para índice BASE", "estado"),
        ("BASE_DECODE", "índice BASE para tupla", "estado"),
        ("BASE_ROUNDTRIP", "encode + decode", "estado"),
        ("BASE15_PACK", "empacotamento MSB-first", "estado"),
        ("BASE15_UNPACK", "desempacotamento e validação", "estado"),
        ("CHI40_PACK", "estado + cor para 5 bytes", "estado cromático"),
        ("CHI40_UNPACK", "5 bytes para estado + cor", "estado cromático"),
        ("FRAME_PARSE", "cabeçalho, tamanho e CRC", "frame"),
        ("BASELINE17_*", "bitfield direto de 17 bits", "estado"),
        ("BASELINE40_*", "campos alinhados em 5 bytes", "estado")
    ])

    doc.add_heading("7. Baselines e justiça comparativa", level=1)
    doc.add_paragraph(
        "Dois baselines foram implementados. O FIELD17 armazena diretamente theta, s, tau e phi em 17 bits, sem explorar a cardinalidade conjunta do produto. O FIELD40 armazena theta em dois bytes e os três campos restantes em bytes separados. Ambos carregam exatamente as quatro coordenadas. Nenhum deles representa Unicode, compressão geral ou protocolo de objetos; por isso não devem ser apresentados como substitutos universais."
    )
    add_table(doc, ["Formato", "Bits significativos", "Bytes unitários", "Semântica"], [
        ("HVE BASE15", "15", "fluxo bit-packed", "índice bijetivo completo"),
        ("FIELD17", "17", "3 quando serializado isoladamente", "campos compactos diretos"),
        ("FIELD40", "40", "5", "campos byte-aligned")
    ])

    doc.add_heading("8. Temporização e marcação física", level=1)
    numbered(doc, [
        "O alvo prepara vetores e buffers antes da região temporizada.",
        "O GPIO de marcação sobe imediatamente antes da leitura inicial do contador.",
        "Somente o workload é executado entre as duas leituras.",
        "O GPIO desce antes de qualquer saída serial.",
        "A resposta transporta ticks brutos, frequência do contador, largura do contador, operações e checksum.",
        "O computador converte ticks em tempo, sem apagar os valores originais."
    ])
    doc.add_picture(str(DOCS / "measurement_pipeline.png"), width=Inches(6.5))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_heading("9. Particularidades dos microcontroladores", level=1)
    doc.add_heading("9.1. RP2040", level=2)
    doc.add_paragraph(
        "O timer padrão possui resolução de microssegundos. Consequentemente, o alvo mede lotes grandes e não deve publicar uma latência individual obtida de uma única chamada. O clock do núcleo é lido em tempo de execução. O GPIO 2 foi reservado como marcador por padrão."
    )
    doc.add_heading("9.2. STM32F446RE", level=2)
    doc.add_paragraph(
        "O adaptador habilita DWT CYCCNT e declara contador modular de 32 bits. Uma corrida deve terminar antes do wrap. O HCLK informado por HAL_RCC_GetHCLKFreq() é registrado como frequência do contador. USART2 e PA5 são ligações padrão do pacote, mas permanecem macros editáveis para o projeto Cube congelado."
    )

    doc.add_heading("10. Trilha FPGA", level=1)
    doc.add_paragraph(
        "A Parte I usava divisão e módulo constantes diretamente no RTL combinacional. A Parte II-A adiciona um decoder sequencial por divisão restauradora. O índice é dividido por 9 em 15 ciclos; o quociente é dividido por 5 em outros 15 ciclos; s é o bit menos significativo do segundo quociente e theta é seu deslocamento à direita. O encoder usa pipeline de três estágios."
    )
    add_table(doc, ["Módulo", "Papel", "Evidência atual"], [
        ("hve_divmod_const_seq", "divisão restauradora por constante", "modelo Python exaustivo"),
        ("hve_base_decoder_seq", "inversa BASE sem / ou %", "RTL escrito; simulação pendente"),
        ("hve_base_encoder_pipe", "encoder com pipeline", "RTL escrito; simulação pendente"),
        ("hve_selftest_top", "autoteste dos 32.768 words", "bitstream pendente"),
        ("tb_hve_seq", "testbench exaustivo", "Icarus/Verilator pendente")
    ])
    doc.add_paragraph(
        "O modelo independente verificou 32.400 índices válidos, 368 reservados e zero falhas. Isso valida o algoritmo, não a sintaxe, a síntese, o timing ou a potência do HDL."
    )

    doc.add_heading("11. Dados, esquema e estatística", level=1)
    bullets(doc, [
        "JSONL bruto é imutável após coleta.",
        "JSON Schema valida tipos, limites e campos obrigatórios.",
        "O script deriva segundos, nanossegundos por operação e operações por segundo.",
        "Resumo inclui média, mediana, desvio padrão, p95, p99, mínimo, máximo e intervalo bootstrap de 95%.",
        "Cada gráfico e tabela deve ser regenerável diretamente do JSONL."
    ])
    doc.add_paragraph(
        "O conjunto host-mock acompanha o pacote apenas para demonstrar que o pipeline funciona. Sua classe de ambiente é host_harness e ele não pode ser transferido para a seção de resultados físicos do artigo."
    )

    doc.add_heading("12. Energia", level=1)
    doc.add_paragraph(
        "O script power_integrate.py recebe amostras de tempo, tensão, corrente e marcador. A potência de baseline pode ser fornecida ou estimada pela mediana das amostras com marcador zero. A energia líquida é integrada apenas na janela ativa e dividida pelo número declarado de operações. O resultado preserva baseline, duração, energia total, energia por operação e incerteza relativa."
    )
    doc.add_paragraph(
        "Para publicação, o instrumento, shunt, taxa de amostragem, calibração, tensão, temperatura e método de sincronização devem estar no manifesto da bancada."
    )

    doc.add_heading("13. Critérios de aceitação da Parte II-B física", level=1)
    add_table(doc, ["Gate", "Critério mínimo"], [
        ("MCU funcional", "SELFTEST: 32.400 válidos, 368 reservados, zero falhas em cada placa"),
        ("Reprodutibilidade", "30 repetições por workload e plano/manifesto arquivados"),
        ("Timer", "frequência e wrap documentados; nenhuma corrida ambígua"),
        ("Memória", "ELF, map, flash, data, bss e stack reportados"),
        ("Energia", "trace bruto com marcador e incerteza"),
        ("FPGA simulação", "testbench exaustivo sem falhas"),
        ("FPGA síntese", "logs Yosys/nextpnr, recursos, Fmax e bitstream"),
        ("FPGA físico", "LED de autoteste verde e captura da bancada"),
        ("Artigo", "nenhum placeholder transformado em número sem arquivo de origem")
    ])

    doc.add_heading("14. Procedimento imediato de laboratório", level=1)
    numbered(doc, [
        "Adquirir ou confirmar disponibilidade de Raspberry Pi Pico, NUCLEO-F446RE e iCEBreaker.",
        "Criar repositório versionado e registrar SHA-256 do pacote inicial.",
        "Congelar SDK Pico e STM32Cube em commits/versões identificadas.",
        "Compilar primeiro com o plano quick e executar INFO + SELFTEST.",
        "Validar o JSONL e repetir após power cycle.",
        "Executar publication_plan somente quando o contador e a duração estiverem dentro dos limites.",
        "Capturar map files e medir stack antes de energia.",
        "Instalar Icarus/Verilator e executar o testbench antes de síntese.",
        "Sintetizar e programar o iCEBreaker; arquivar todos os logs.",
        "Somente depois atualizar tabelas e conclusões do artigo JSA."
    ])

    doc.add_heading("15. Limitações abertas", level=1)
    bullets(doc, [
        "Não há placa física conectada ao ambiente de construção deste pacote.",
        "O código STM32 depende do projeto Cube gerado e de seu clock tree explícito.",
        "O código RP2040 depende do Pico SDK e de uma compilação cruzada externa.",
        "O RTL ainda requer simulação e síntese em ferramenta real.",
        "A energia depende de instrumentação externa calibrada.",
        "O caso de uso edge completo permanece para a Parte II-C."
    ])

    doc.add_heading("Conclusão", level=1)
    doc.add_paragraph(
        "A Parte II não foi tratada como promessa. Ela foi iniciada por infraestrutura executável: firmware portátil, planos de carga, protocolo, coleta, schema, estatística, energia e FPGA. O HVE passa a ter uma rota de validação física com gates objetivos. O único elemento que permanece obrigatoriamente fora do pacote é o dado que só uma bancada real pode produzir."
    )

    doc.add_heading("Referências técnicas de plataforma", level=1)
    refs = [
        "Raspberry Pi Ltd. Pico SDK documentation: hardware timer, clocks and C/C++ SDK.",
        "STMicroelectronics. NUCLEO-F446RE product documentation and STM32Cube ecosystem.",
        "Arm. CMSIS-Core documentation for Cortex-M core register access.",
        "iCEBreaker FPGA documentation. iCE40UP5K board, clock, FTDI interface and open hardware resources.",
        "YosysHQ. nextpnr and the open-source iCE40 implementation flow."
    ]
    for i, ref in enumerate(refs, start=1):
        doc.add_paragraph(f"[{i}] {ref}")

    out = DOCS / "HVE_Embedded_Part_II_A_Implementation_Report_PT.docx"
    doc.save(out)
    return out


def build_article_en() -> Path:
    title = "HVE-720 Embedded: Physical Validation Framework for a Deterministic Modular State Architecture"
    doc = Document()
    configure(doc, title, "HVE-720 Embedded — JSA-oriented draft v2.0-A")
    doc.styles["Normal"].font.size = Pt(10)
    doc.styles["Normal"].paragraph_format.space_after = Pt(4)
    doc.sections[0].top_margin = Cm(1.9)
    doc.sections[0].bottom_margin = Cm(1.8)
    title_page(doc, title, "Journal of Systems Architecture-oriented research manuscript", "DRAFT — PHYSICAL RESULTS NOT YET INSERTED", version="2.0-A")

    doc.add_heading("Abstract", level=1)
    doc.add_paragraph(
        "This paper develops the physical-validation framework for HVE-720 Embedded, a deterministic encoding and serialization architecture derived from the finite state space G = Z360 × Z2 × Z5 × Z9. The architecture maps 32,400 complete BASE states bijectively to valid 15-bit indices, explicitly rejects 368 reserved words, and provides an aligned chromatic profile that distinguishes the absence of color from RGB black. The contribution of the present phase is a reproducible systems-evaluation layer: an allocation-free benchmark core, structurally equivalent fieldwise baselines, a line-oriented control protocol, machine-readable measurement records, schema validation, statistical analysis, marker-gated energy integration, complete RP2040 firmware, an STM32F446RE cycle-counter port, and a resource-predictable sequential FPGA decoder. Host execution validates the measurement pipeline and an independent cycle model exhaustively verifies the sequential decoding algorithm. Physical latency, memory, energy, FPGA resource and timing results remain deliberately unclaimed until target boards and synthesis tools are executed under the frozen protocol."
    )
    doc.add_paragraph("Keywords: embedded systems architecture; deterministic encoding; reproducible benchmarking; finite-state serialization; RP2040; STM32; FPGA; hardware validation")

    doc.add_heading("1. Introduction", level=1)
    doc.add_paragraph(
        "A formal encoding can be mathematically correct and still remain unsuitable for systems research if its implementation boundary, measurement method, invalid-state behavior, and physical evidence are not specified. HVE-720 defines a finite modular state object rather than a universal text replacement. The systems question is whether the same object can be preserved across portable software, framing, microcontroller execution and FPGA realization while retaining exact validation rules."
    )
    doc.add_paragraph(
        "The novelty claimed here is architectural. Established arithmetic components are coordinated into a versioned state system with a reversible compact index, explicit invalid regions, optional pointed color, deterministic wire profiles, independent conformance implementations, and a physical evaluation path that separates codec cost from transport and application cost."
    )

    doc.add_heading("1.1. Contributions of the physical-validation phase", level=2)
    bullets(doc, [
        "a platform-independent timing and workload layer that uses the production HVE C API;",
        "complete RP2040 firmware and an STM32F446RE DWT-based drop-in port;",
        "a minimal ASCII command protocol with single-line JSON evidence records;",
        "two equivalent direct-coordinate baselines, using 17 significant bits and 40 aligned bits;",
        "schema-validated JSONL capture and reproducible statistical analysis;",
        "marker-gated power integration with explicit baseline subtraction;",
        "a sequential constant-divider FPGA decoder and a three-stage pipelined encoder;",
        "objective publication gates that prevent host or simulated values from becoming hardware claims."
    ])

    doc.add_heading("2. State and wire models", level=1)
    doc.add_paragraph("The BASE state is g = (theta, s, tau, phi), with cardinalities 360, 2, 5 and 9. The exact index is")
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("E(theta,s,tau,phi) = (((theta·2+s)·5+tau)·9+phi).")
    doc.add_paragraph(
        "Indices 0 through 32,399 are valid; 32,400 through 32,767 are invalid or reserved. BASE15 concatenates indices most-significant-bit first. CHI40 stores the BASE index, one color-presence bit and 24 RGB bits. A zero presence bit with nonzero RGB is noncanonical and rejected."
    )

    doc.add_heading("3. Evaluation architecture", level=1)
    doc.add_picture(str(DOCS / "part2a_architecture.png"), width=Inches(6.4))
    doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
    doc.add_paragraph(
        "Platform adapters provide only a monotonic counter, counter frequency, counter width, core clock, marker GPIO and line I/O. Workload preparation occurs before timing. The marker is asserted before the initial counter read and cleared immediately after the final read. Serialization of the result is outside the measured region."
    )

    doc.add_heading("4. Target platforms", level=1)
    add_table(doc, ["Target", "Counter", "Control channel", "Role"], [
        ("Raspberry Pi Pico / RP2040", "64-bit hardware timer, microsecond ticks", "USB CDC", "batch timing on a low-complexity MCU"),
        ("NUCLEO-F446RE", "32-bit DWT cycle counter", "USART2 through ST-LINK VCP", "cycle-level Cortex-M4 measurements"),
        ("iCEBreaker / iCE40UP5K", "declared FPGA clock", "on-board pass/fail plus tool logs", "open-flow RTL synthesis and physical self-test")
    ])
    doc.add_paragraph(
        "Each publication run must archive the exact SDK or Cube version, compiler, flags, clock tree, voltage, board revision, binary hash, map file and reset state. Results from different timer modes are converted using the declared frequency while raw ticks remain available."
    )

    doc.add_heading("5. Workload design", level=1)
    add_table(doc, ["Class", "Workloads", "Measured operation"], [
        ("BASE", "encode, decode, round-trip", "one complete HVE state"),
        ("Stream", "BASE15 pack and unpack", "one packed state within a batch"),
        ("Chromatic", "CHI40 pack and unpack", "one state with pointed color"),
        ("Integrity", "HVE1 frame parse", "one complete frame"),
        ("Baselines", "FIELD17 and FIELD40 encode/decode", "the same four coordinates")
    ])
    doc.add_paragraph(
        "Input vectors are generated outside the timed region using a deterministic seed. Each timed loop updates a checksum that is returned in the evidence record, preventing dead-code elimination and exposing divergent runs."
    )

    doc.add_heading("6. Comparative baselines", level=1)
    doc.add_paragraph(
        "FIELD17 directly allocates 9, 1, 3 and 4 bits to the four coordinates. FIELD40 stores theta as a 16-bit big-endian field and the remaining coordinates as individual bytes. These baselines preserve the same state information without the mixed-radix reduction. UTF-8, CBOR or MessagePack are not used as universal substitutes in the core microbenchmark because they solve different representation problems; they may be evaluated separately in an application-level case study."
    )

    doc.add_heading("7. Control protocol and evidence format", level=1)
    code(doc, "INFO\nSELFTEST\nRUN BASE_ENCODE 1000000 32 2001 10000")
    doc.add_paragraph(
        "The target accepts a narrow command grammar and returns one JSON object per command. Measurement records include target, board, build identifier, workload, iteration and batch counts, seed, operations, raw ticks, timer frequency, counter width, core clock, checksum and status. The host controller adds UTC capture time, repetition, plan identifier and evidence class, then appends the record to immutable JSONL."
    )

    doc.add_heading("8. Statistical protocol", level=1)
    doc.add_paragraph(
        "Publication runs use at least 30 repetitions per workload after a declared warm-up. Derived metrics include time per operation and operations per second. Reports include mean, median, standard deviation, 95th and 99th percentiles, extrema, and a deterministic 95% bootstrap confidence interval for the mean. Raw data are retained and all tables are regenerated by script."
    )

    doc.add_heading("9. Memory protocol", level=1)
    bullets(doc, [
        "archive ELF, binary and linker map files;",
        "report text, rodata, data and bss separately;",
        "measure maximum stack through a canary or RTOS-aware tool;",
        "confirm that the HVE core performs no mandatory dynamic allocation;",
        "report application buffers separately from library state."
    ])

    doc.add_heading("10. Energy protocol", level=1)
    doc.add_paragraph(
        "The marker GPIO defines the active integration window. Power is computed from synchronized voltage and current samples. Baseline power is either supplied from an independently measured idle interval or estimated from marker-low samples. Net energy is integrated after baseline subtraction and divided by the exact operation count. Instrument, shunt, sampling rate, calibration, voltage and uncertainty are mandatory metadata."
    )

    doc.add_heading("11. FPGA microarchitectures", level=1)
    doc.add_paragraph(
        "The sequential decoder performs two restoring divisions over a fixed 15-bit width: first by 9 to obtain phi and q1, then by 5 to obtain tau and q2. The remaining coordinates are s = q2 mod 2 and theta = floor(q2/2). This architecture has deterministic control and avoids a generic combinational divider. The encoder is a three-stage pipeline implementing multiplications by 2, 5 and 9."
    )
    doc.add_paragraph(
        "A physical self-test traverses the entire 15-bit space. Every valid word must decode and re-encode exactly, while every reserved word must be rejected. The open iCE40 flow archives simulation, synthesis, place-and-route and bitstream logs. Resource use, maximum frequency, latency and power remain pending physical execution."
    )

    doc.add_heading("12. Executed infrastructure validation", level=1)
    doc.add_paragraph(
        "The portable C test suite passed on the build host. The controller captured 36 host-harness measurements across all workloads, the JSON Schema validator reported zero record errors, and the analysis scripts generated derived tables and plots. These observations validate the measurement pipeline only. They are not MCU performance results."
    )
    doc.add_paragraph(
        "An independent Python cycle model exhaustively checked all 32,400 valid indices and all 368 reserved words for the sequential decoding algorithm with zero failures. This is algorithmic evidence and does not replace HDL simulation, synthesis or board execution."
    )

    doc.add_heading("13. Physical results", level=1)
    doc.add_paragraph("NO PHYSICAL RESULT IS INSERTED IN THIS DRAFT.")
    add_table(doc, ["Target", "Workload", "Ticks/op", "ns/op", "Flash", "RAM", "Energy/op", "Evidence file"], [
        ("RP2040", "Pending", "—", "—", "—", "—", "—", "—"),
        ("STM32F446", "Pending", "—", "—", "—", "—", "—", "—"),
        ("iCE40UP5K", "Pending", "—", "—", "—", "—", "—", "—")
    ])
    doc.add_paragraph(
        "The table may only be populated from schema-valid records or archived synthesis reports. Placeholder symbols must never be converted into estimated values."
    )

    doc.add_heading("14. Threats to validity", level=1)
    bullets(doc, [
        "timer resolution and wrap differ across targets;",
        "compiler optimization and constant propagation may change cycle cost;",
        "USB or UART activity must remain outside the timed region;",
        "clock, voltage, cache and wait-state configuration affect results;",
        "board-level energy includes regulators and interfaces unless rails are isolated;",
        "FPGA tool versions and placement randomness can alter timing and power;",
        "microbenchmarks do not establish application-level superiority."
    ])

    doc.add_heading("15. Reproducibility package", level=1)
    bullets(doc, [
        "portable C core and target adapters;",
        "RP2040 build project and STM32 Cube drop-in port;",
        "run plans, controller, JSON Schema and validator;",
        "analysis and power-integration scripts;",
        "RTL, testbench, iCEBreaker constraints and Makefile;",
        "raw host-harness evidence labeled as non-physical;",
        "SHA-256 manifest for the complete release."
    ])

    doc.add_heading("16. Conclusion", level=1)
    doc.add_paragraph(
        "The physical-validation phase has been converted from a narrative requirement into an executable systems framework. HVE-720 Embedded now has portable workloads, fair direct-coordinate baselines, target ports, machine-readable evidence, statistical gates, energy integration and a deterministic FPGA path. The remaining evidence is irreducibly physical: boards, toolchains and instruments must execute the frozen protocol before performance or efficiency claims are submitted."
    )

    doc.add_heading("Declarations", level=1)
    doc.add_paragraph("Funding: No external funding was received for this work.")
    doc.add_paragraph("Competing interests: The author declares no competing interests.")
    doc.add_paragraph("Data and code availability: The submission version shall identify a public versioned repository and an archived release containing raw records, tool logs and hashes.")
    doc.add_paragraph("Use of AI tools: Language and document-structuring assistance shall be disclosed under the target journal's current policy. Technical claims remain the author's responsibility.")

    out = ARTICLE / "HVE720_Embedded_JSA_Research_Article_Draft_v2_EN.docx"
    doc.save(out)
    return out


def main() -> None:
    DOCS.mkdir(exist_ok=True)
    ARTICLE.mkdir(exist_ok=True)
    make_figures()
    print(build_report_pt())
    print(build_article_en())


if __name__ == "__main__":
    main()
