#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"
rm -rf build-part-ii-b evidence/test-host-session evidence/host-build-b data/generated/part_ii_b_test
mkdir -p data/generated/part_ii_b_test

cmake -S . -B build-part-ii-b -DCMAKE_BUILD_TYPE=Release
cmake --build build-part-ii-b -j2
ctest --test-dir build-part-ii-b --output-on-failure
python -m py_compile tools/*.py
python tools/toolchain_probe.py --output data/generated/part_ii_b_test/toolchain_probe.json
python tools/map_metrics.py --elf build-part-ii-b/hve_host_target --map build-part-ii-b/hve_host_target.map --output data/generated/part_ii_b_test/host_memory.json
python tools/stack_usage_collect.py build-part-ii-b --output data/generated/part_ii_b_test/host_stack.json
python tools/fpga_flow.py --project fpga/icebreaker --output-dir data/generated/part_ii_b_test/fpga_readiness
python tools/evidence_session.py \
  --root "$ROOT" \
  --sessions-dir evidence/test-host-session \
  --host-executable "$ROOT/build-part-ii-b/hve_host_target" \
  --plan data/plans/quick_plan.json \
  --schema data/schema/hve_measurement.schema.json \
  --boot-class host_dry_run \
  --board-serial HOST-DRY-RUN \
  --session-id host-dry-run-v1
python tools/generate_publication_tables.py \
  evidence/test-host-session/host-dry-run-v1/analysis/summary.json \
  --output-dir data/generated/part_ii_b_test/publication_tables
python tools/hash_tree.py data/generated/part_ii_b_test --output data/generated/part_ii_b_test/SHA256_MANIFEST.json

echo "ALL PART II-B NON-PHYSICAL TESTS PASSED"
