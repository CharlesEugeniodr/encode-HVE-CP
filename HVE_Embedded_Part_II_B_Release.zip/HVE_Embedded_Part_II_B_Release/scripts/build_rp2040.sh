#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
: "${PICO_SDK_PATH:?Set PICO_SDK_PATH to the Pico SDK root}"
cmake -S "$ROOT/targets/rp2040" -B "$ROOT/build-rp2040" -DCMAKE_BUILD_TYPE=Release
cmake --build "$ROOT/build-rp2040" -j2
