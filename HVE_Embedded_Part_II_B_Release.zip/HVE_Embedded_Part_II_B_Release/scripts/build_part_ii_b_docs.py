from __future__ import annotations

from pathlib import Path
from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_SECTION
from docx.shared import Inches, Pt
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = Path(__file__).resolve().parents[1]
DOCS = ROOT / "docs"
ADD = DOCS / "article_addendum"
DOCS.mkdir(exist_ok=True)
ADD.mkdir(exist_ok=True)


def shade(cell, fill="D9E2F3"):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), fill)
    tcPr.append(shd)


def set_cell_text(cell, text, bold=False):
    cell.text = ""
    p = cell.paragraphs[0]
    r = p.add_run(text)
    r.bold = bold
    r.font.size = Pt(9)
    cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def configure(doc: Document):
    sec = doc.sections[0]
    sec.top_margin = Inches(0.75)
    sec.bottom_margin = Inches(0.75)
    sec.left_margin = Inches(0.85)
    sec.right_margin = Inches(0.85)
    styles = doc.styles
    styles["Normal"].font.name = "Aptos"
    styles["Normal"].font.size = Pt(10.5)
    styles["Normal"].paragraph_format.space_after = Pt(5)
    styles["Normal"].paragraph_format.line_spacing = 1.08
    for name, size in [("Title", 20), ("Heading 1", 15), ("Heading 2", 12), ("Heading 3", 10.5)]:
        styles[name].font.name = "Aptos Display" if name != "Normal" else "Aptos"
        styles[name].font.size = Pt(size)
        styles[name].font.bold = True
    footer = sec.footer.paragraphs[0]
    footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    footer.add_run("HVE Embedded — Part II-B").font.size = Pt(8)


def title_page(doc: Document, title: str, subtitle: str, language_note: str):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run(title).bold = True
    p.runs[0].font.size = Pt(22)
    p.runs[0].font.name = "Aptos Display"
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(subtitle)
    r.font.size = Pt(13)
    r.italic = True
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("Charles de Paula Eugênio")
    r.bold = True
    r.font.size = Pt(12)
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run("Independent Researcher — Parauapebas, Pará, Brazil").font.size = Pt(10)
    doc.add_paragraph()
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run(language_note)
    r.font.size = Pt(9)
    r.italic = True
    doc.add_page_break()


def add_bullets(doc, items):
    for item in items:
        p = doc.add_paragraph(style="List Bullet")
        p.add_run(item)


def add_numbered(doc, items):
    for index, item in enumerate(items, start=1):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.18)
        p.paragraph_format.first_line_indent = Inches(-0.18)
        p.add_run(f"{index}.  ").bold = False
        p.add_run(item)


def report_pt():
    doc = Document()
    configure(doc)
    title_page(
        doc,
        "HVE Embedded — Parte II-B",
        "Protocolo de execução física, rastreabilidade e cadeia de evidências",
        "Documento técnico operacional. Não contém resultados físicos inventados ou estimados."
    )

    doc.add_heading("Resumo executivo", level=1)
    doc.add_paragraph(
        "A Parte II-B foi iniciada como uma camada operacional de validação física do HVE-720 Embedded. "
        "O objetivo não é apenas executar benchmarks, mas garantir que cada número futuro de latência, "
        "throughput, memória, energia, área lógica ou frequência máxima possa ser rastreado até uma placa, "
        "um binário, um plano experimental, um instrumento, um log bruto e um hash criptográfico."
    )
    doc.add_paragraph(
        "Nesta entrega foram implementados controladores de sessão, inventário de hardware, bloqueio do "
        "experimento, coleta de mapa e stack, integração de energia por GPIO marcador, fluxo FPGA e gerador "
        "de tabelas que impede a promoção indevida de dados do computador hospedeiro a evidência embarcada."
    )

    doc.add_heading("1. Estado alcançado", level=1)
    table = doc.add_table(rows=1, cols=3)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = "Table Grid"
    headers = ["Componente", "Estado", "Evidência"]
    for i, h in enumerate(headers):
        set_cell_text(table.rows[0].cells[i], h, True); shade(table.rows[0].cells[i])
    rows = [
        ("Núcleo C portátil", "Executado", "Compilação e testes aprovados"),
        ("Autoteste HVE", "Executado", "32.400 válidos; 368 reservados; zero falhas"),
        ("Sessão de evidência host", "Executada", "JSONL, validação, análise e SHA-256"),
        ("RP2040", "Preparado", "Projeto, script de build e captura; hardware ausente"),
        ("STM32F446RE", "Preparado", "Porta DWT e procedimento Cube; hardware ausente"),
        ("FPGA iCE40UP5K", "Preparado", "RTL, testbench e fluxo; ferramentas/hardware ausentes"),
        ("Energia", "Preparado", "Segmentação por GPIO marcador; instrumento ausente"),
    ]
    for row in rows:
        cells = table.add_row().cells
        for i, text in enumerate(row): set_cell_text(cells[i], text)

    doc.add_heading("2. Princípio de severidade científica", level=1)
    doc.add_paragraph(
        "A execução física é considerada válida apenas quando seis elementos permanecem vinculados na mesma sessão: "
        "hardware declarado, fonte congelada, binário congelado, plano congelado, dados brutos e manifesto SHA-256. "
        "A ausência de qualquer um desses elementos impede o uso do resultado no artigo."
    )
    add_bullets(doc, [
        "Resultado host valida somente o pipeline de medição.",
        "Resultado sintético valida somente o algoritmo de análise.",
        "Resultado de modelo de ciclos valida somente a lógica abstrata.",
        "Resultado físico exige placa identificada e captura serial ou instrumental.",
        "Valor sem arquivo de evidência não entra no manuscrito."
    ])

    doc.add_heading("3. Arquitetura de evidências", level=1)
    doc.add_paragraph(
        "Cada execução cria um diretório independente com as subpastas raw, logs, analysis, metadata e artifacts. "
        "O controlador salva o transcript integral, o manifesto do alvo, a resposta INFO, o SELFTEST, o plano, "
        "o inventário, o conjunto JSONL, os relatórios derivados e o manifesto criptográfico."
    )
    table = doc.add_table(rows=1, cols=2); table.style = "Table Grid"; table.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i,h in enumerate(["Diretório", "Função"]): set_cell_text(table.rows[0].cells[i],h,True); shade(table.rows[0].cells[i])
    for a,b in [
        ("raw", "Dados imutáveis: JSONL, transcript e traços instrumentais."),
        ("logs", "Comandos, stdout, stderr e códigos de retorno."),
        ("analysis", "CSV, resumos estatísticos e figuras derivadas."),
        ("metadata", "Plano, inventário, SDK, compilador, clock, tensão e ambiente."),
        ("artifacts", "ELF, BIN, UF2, MAP, bitstream e relatórios de síntese."),
    ]:
        c=table.add_row().cells; set_cell_text(c[0],a); set_cell_text(c[1],b)

    doc.add_heading("4. Porta de entrada obrigatória: SELFTEST", level=1)
    doc.add_paragraph(
        "Antes de qualquer benchmark, o alvo precisa demonstrar a correção integral do domínio BASE. O controlador "
        "interrompe a sessão quando os valores esperados não forem exatamente 32.400 estados válidos, 368 palavras "
        "reservadas e zero falhas. Esse teste impede a coleta de desempenho sobre uma implementação incorreta."
    )

    doc.add_heading("5. Planos experimentais", level=1)
    doc.add_heading("5.1 Triagem física", level=2)
    doc.add_paragraph(
        "O plano physical_quick executa cinco repetições de cada workload. Ele serve para detectar problemas de "
        "porta serial, clock, wrap do contador, checksum, reinicialização e estabilidade antes do experimento de publicação."
    )
    doc.add_heading("5.2 Plano de publicação", level=2)
    doc.add_paragraph(
        "O plano physical_publication_plan_v2 executa trinta repetições independentes por workload. Deve ser executado "
        "separadamente após cold boot e warm reset, sem alteração do binário, clock, tensão ou ambiente declarado."
    )

    doc.add_heading("6. Métricas", level=1)
    table = doc.add_table(rows=1, cols=3); table.style="Table Grid"; table.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,h in enumerate(["Métrica", "Fonte primária", "Regra"]): set_cell_text(table.rows[0].cells[i],h,True); shade(table.rows[0].cells[i])
    metrics = [
        ("Ticks e tempo", "Contador do alvo", "Preservar ticks e frequência; não guardar apenas nanossegundos."),
        ("Throughput", "Operações/tempo", "Calcular a partir do dataset bruto."),
        ("Flash/RAM estática", "ELF e MAP", "Arquivar saída bruta de size e mapa."),
        ("Stack estática", "Arquivos .su", "Declarar que não prova a profundidade máxima da cadeia."),
        ("Energia", "CSV do instrumento + marcador", "Integrar por segmento e declarar incerteza."),
        ("Área/Fmax", "Yosys/nextpnr", "Publicar somente com logs e bitstream associados."),
    ]
    for row in metrics:
        c=table.add_row().cells
        for i,x in enumerate(row): set_cell_text(c[i],x)

    doc.add_heading("7. Comparações e baselines", level=1)
    doc.add_paragraph(
        "Os baselines BASELINE17 e BASELINE40 carregam os mesmos campos estruturais em formatos diretos. A comparação "
        "não deve opor o HVE completo a uma codificação que represente menos informação. Para UTF-8, CBOR ou MessagePack, "
        "a equivalência funcional precisa ser definida por cenário, incluindo cobertura, fallback e metadados."
    )

    doc.add_heading("8. Execução RP2040", level=1)
    add_numbered(doc, [
        "Congelar o commit do Pico SDK e registrar PICO_SDK_PATH.",
        "Executar build_rp2040_evidence.sh.",
        "Arquivar UF2, ELF, MAP, logs, memória, stack e hashes.",
        "Gravar a placa e identificar a porta serial.",
        "Executar physical_quick em cold boot.",
        "Repetir em warm reset e comparar checksums.",
        "Somente então executar o plano de publicação."
    ])

    doc.add_heading("9. Execução STM32F446RE", level=1)
    doc.add_paragraph(
        "A porta STM32 permanece deliberadamente integrada a um projeto Cube explícito, porque clock tree, startup, "
        "linker script, UART e GPIO precisam constar do arquivo experimental. O contador DWT fornece ciclos modulo 2^32; "
        "cada workload deve permanecer abaixo do wrap ou ser dividido."
    )

    doc.add_heading("10. Execução FPGA", level=1)
    add_numbered(doc, [
        "Executar o testbench HDL e preservar o log completo.",
        "Sintetizar com Yosys e preservar estatísticas de células.",
        "Executar place-and-route com nextpnr e preservar timing.",
        "Gerar bitstream e calcular SHA-256.",
        "Programar a placa e registrar o autoteste físico.",
        "Não inferir Fmax, área ou potência de um modelo Python."
    ])

    doc.add_heading("11. Energia e instrumentação", level=1)
    doc.add_paragraph(
        "O GPIO marcador delimita apenas a região medida. O CSV precisa conter tempo, tensão, corrente e marcador no "
        "mesmo eixo temporal. O script power_segment identifica cada janela ativa, estima a potência basal pelas amostras "
        "inativas e calcula energia líquida e energia por operação. Calibração e erro sistemático continuam obrigatórios."
    )

    doc.add_heading("12. Bloqueios atuais", level=1)
    add_bullets(doc, [
        "Não há placa física conectada a este ambiente.",
        "arm-none-eabi-gcc, Pico SDK e STM32CubeF4 não estão instalados.",
        "Icarus Verilog, Verilator, Yosys, nextpnr-ice40 e IceStorm não estão instalados.",
        "Não há instrumento de energia ou arquivo bruto real.",
        "Consequentemente, nenhuma métrica física foi alegada."
    ])

    doc.add_heading("13. Critério de conclusão da Parte II-B", level=1)
    doc.add_paragraph(
        "A Parte II-B será considerada concluída quando existirem, para pelo menos dois microcontroladores e uma FPGA, "
        "sessões físicas completas, resultados reproduzíveis, memória e stack documentadas, energia medida, simulação e "
        "síntese arquivadas, além de tabelas regeneráveis diretamente dos artefatos."
    )

    doc.add_heading("Apêndice A — Comandos essenciais", level=1)
    for text in [
        "python tools/toolchain_probe.py --output evidence/toolchain_probe.json",
        "./build_scripts/build_rp2040_evidence.sh",
        "./build_scripts/run_physical_mcu_session.sh PORTA SERIAL cold_boot",
        "./build_scripts/run_fpga_evidence.sh",
        "python tools/power_segment.py trace.csv --operations-per-segment N --output energy.json",
    ]:
        p=doc.add_paragraph(); r=p.add_run(text); r.font.name="Consolas"; r.font.size=Pt(9)

    out = DOCS / "HVE_Embedded_Part_II_B_Execution_Protocol_PT.docx"
    doc.save(out)
    return out


def methods_en():
    doc = Document(); configure(doc)
    title_page(
        doc,
        "HVE-720 Embedded — Experimental Methods Addendum v3",
        "Traceable physical validation for the Journal of Systems Architecture manuscript",
        "This addendum contains methods and insertion-ready text only. It contains no fabricated physical results."
    )
    doc.add_heading("1. Experimental design", level=1)
    doc.add_paragraph(
        "The physical evaluation is organized as an evidence-preserving experiment rather than an isolated benchmark. "
        "Each session binds the source release, target board, board revision, serial number, supply voltage, clock, toolchain, "
        "SDK revision, compiler flags, binary artifacts, execution plan, raw output and derived statistics through a SHA-256 manifest."
    )
    doc.add_heading("2. Correctness gate", level=1)
    doc.add_paragraph(
        "No performance measurement is accepted before the target completes an exhaustive BASE-domain self-test. The gate "
        "requires exactly 32,400 valid words, rejection of all 368 reserved 15-bit words, and zero encode-decode failures. "
        "This ordering prevents performance claims from being generated by a functionally incorrect implementation."
    )
    doc.add_heading("3. Targets", level=1)
    table=doc.add_table(rows=1, cols=4); table.style="Table Grid"; table.alignment=WD_TABLE_ALIGNMENT.CENTER
    for i,h in enumerate(["Target", "Timing source", "Build evidence", "Status"]): set_cell_text(table.rows[0].cells[i],h,True); shade(table.rows[0].cells[i])
    for row in [
        ("RP2040", "64-bit hardware timer", "ELF, UF2, map, .su, logs", "Awaiting physical execution"),
        ("STM32F446RE", "32-bit DWT cycle counter", "ELF, BIN, map, .su, Cube config", "Awaiting physical execution"),
        ("iCE40UP5K", "Synthesis/P&R timing and physical self-test", "simulation, Yosys, nextpnr, bitstream", "Awaiting physical execution"),
    ]:
        c=table.add_row().cells
        for i,x in enumerate(row): set_cell_text(c[i],x)

    doc.add_heading("4. Workloads and baselines", level=1)
    doc.add_paragraph(
        "The workload set covers BASE encode, decode and round trip; 15-bit stream packing and unpacking; HVE-chi 40-bit "
        "packing and unpacking; frame parsing; and fieldwise 17-bit and 40-bit baselines that transport the same coordinate fields. "
        "The baselines therefore measure representation overhead without removing HVE information from the comparison."
    )
    doc.add_heading("5. Repetition protocol", level=1)
    doc.add_paragraph(
        "A five-repetition bring-up plan is executed first. The publication plan is executed only after functional and transport "
        "checks pass, and contains 30 independent repetitions per workload. Cold-boot and warm-reset captures are stored as "
        "separate sessions. Seeds change between repetitions, while the binary, clock and voltage remain fixed."
    )
    doc.add_heading("6. Timing analysis", level=1)
    doc.add_paragraph(
        "Raw counter ticks, counter frequency, operation count and checksum are preserved. Derived quantities include time per "
        "operation, throughput, median, standard deviation, 95th and 99th percentiles, extrema, and a nonparametric 95% bootstrap "
        "confidence interval for the mean. Raw ticks remain the primary evidence."
    )
    doc.add_heading("7. Memory and stack", level=1)
    doc.add_paragraph(
        "Flash and static RAM are derived from the target ELF and linker map, with the complete size-tool output retained. GCC "
        "stack-usage files provide per-function static estimates. These estimates are reported separately from dynamic high-water "
        "measurements and are not treated as proof of maximum call-chain depth."
    )
    doc.add_heading("8. Energy", level=1)
    doc.add_paragraph(
        "Energy traces contain a common time axis, voltage, current and a marker GPIO. Each active marker interval is integrated "
        "after baseline-power subtraction. Energy per operation is computed from the exact operation count executed in that interval. "
        "Instrument calibration, sample rate, range and relative uncertainty are archived with the trace."
    )
    doc.add_heading("9. FPGA validation", level=1)
    doc.add_paragraph(
        "The HDL flow includes exhaustive functional simulation, Yosys synthesis, nextpnr place-and-route, timing closure, bitstream "
        "generation and a power-on self-test over the complete 15-bit input domain. Area, Fmax and latency are reported only when the "
        "corresponding logs and bitstream hashes exist."
    )
    doc.add_heading("10. Evidence boundary and threats to validity", level=1)
    add_bullets(doc, [
        "Host measurements validate the harness and are excluded from physical result tables.",
        "Datasheet values are not substituted for measured results.",
        "Different counter types are normalized to time while raw ticks remain available.",
        "USB or serial output occurs outside the timed region.",
        "Cross-platform comparisons declare clock, voltage, compiler and optimization differences.",
        "A missing tool or board is recorded as not executed, not as a negative HVE result."
    ])
    doc.add_heading("11. Result-table insertion rule", level=1)
    doc.add_paragraph(
        "The table generator selects only records explicitly labeled physical_mcu for MCU timing tables. When only host records are "
        "available, the physical table remains empty. This fail-closed behavior is part of the reproducibility design."
    )
    doc.add_heading("12. Current execution status", level=1)
    doc.add_paragraph(
        "The complete non-physical pipeline has passed compilation, unit testing, self-test, dataset validation, statistical analysis, "
        "memory extraction, static stack extraction and evidence hashing. Physical MCU, FPGA and energy measurements remain pending "
        "because no laboratory hardware or cross-toolchains are present in the current environment."
    )
    out=ADD/"HVE720_JSA_Experimental_Methods_v3_EN.docx"
    doc.save(out)
    return out


if __name__ == "__main__":
    print(report_pt())
    print(methods_en())
