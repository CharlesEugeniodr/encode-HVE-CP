#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="${1:-$ROOT/build-host-b}"
EVIDENCE="${2:-$ROOT/evidence/host-build}"
mkdir -p "$EVIDENCE"
rm -rf "$BUILD"
cmake -S "$ROOT" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release 2>&1 | tee "$EVIDENCE/cmake.log"
cmake --build "$BUILD" -j2 2>&1 | tee "$EVIDENCE/build.log"
ctest --test-dir "$BUILD" --output-on-failure 2>&1 | tee "$EVIDENCE/ctest.log"
cp "$BUILD/hve_host_target" "$EVIDENCE/"
cp "$BUILD/hve_host_target.map" "$EVIDENCE/" 2>/dev/null || true
python "$ROOT/tools/map_metrics.py" --elf "$BUILD/hve_host_target" --map "$BUILD/hve_host_target.map" --output "$EVIDENCE/memory_metrics.json"
python "$ROOT/tools/stack_usage_collect.py" "$BUILD" --output "$EVIDENCE/stack_usage.json"
python "$ROOT/tools/hash_tree.py" "$EVIDENCE" --output "$EVIDENCE/SHA256_MANIFEST.json"
echo "Host evidence build complete: $EVIDENCE"
