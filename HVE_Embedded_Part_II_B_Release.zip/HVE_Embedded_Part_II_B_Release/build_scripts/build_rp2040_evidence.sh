#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="${1:-$ROOT/build-rp2040}"
EVIDENCE="${2:-$ROOT/evidence/rp2040-build}"
: "${PICO_SDK_PATH:?Set PICO_SDK_PATH to a frozen Pico SDK checkout}"
mkdir -p "$EVIDENCE"
{
  echo "UTC=$(date -u +%Y-%m-%dT%H:%M:%SZ)"
  echo "PICO_SDK_PATH=$PICO_SDK_PATH"
  git -C "$PICO_SDK_PATH" rev-parse HEAD 2>/dev/null || true
  cmake --version | head -1
  arm-none-eabi-gcc --version | head -1
} > "$EVIDENCE/environment.txt"
rm -rf "$BUILD"
cmake -S "$ROOT/targets/rp2040" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release 2>&1 | tee "$EVIDENCE/cmake.log"
cmake --build "$BUILD" -j2 2>&1 | tee "$EVIDENCE/build.log"
cp "$BUILD"/hve_rp2040_lab.* "$EVIDENCE"/ 2>/dev/null || true
python "$ROOT/tools/map_metrics.py" --elf "$BUILD/hve_rp2040_lab.elf" --size-tool arm-none-eabi-size --map "$BUILD/hve_rp2040_lab.map" --output "$EVIDENCE/memory_metrics.json"
python "$ROOT/tools/stack_usage_collect.py" "$BUILD" --output "$EVIDENCE/stack_usage.json"
python "$ROOT/tools/hash_tree.py" "$EVIDENCE" --output "$EVIDENCE/SHA256_MANIFEST.json"
echo "RP2040 evidence build complete: $EVIDENCE"
