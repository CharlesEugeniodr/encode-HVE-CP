#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PORT="${1:?Usage: $0 SERIAL_PORT BOARD_SERIAL [cold_boot|warm_reset] [PLAN]}"
BOARD_SERIAL="${2:?board serial required}"
BOOT_CLASS="${3:-cold_boot}"
PLAN="${4:-$ROOT/data/plans/physical_quick_plan.json}"
INVENTORY="${HVE_HARDWARE_INVENTORY:-$ROOT/lab/hardware_inventory.json}"
if [[ ! -f "$INVENTORY" ]]; then
  echo "Missing declared hardware inventory: $INVENTORY" >&2
  echo "Copy lab/hardware_inventory.template.json and fill every TO_BE_FILLED field." >&2
  exit 2
fi
ARGS=(
  --root "$ROOT"
  --sessions-dir "$ROOT/evidence/sessions"
  --serial-port "$PORT"
  --baud "${HVE_BAUD:-115200}"
  --plan "$PLAN"
  --schema "$ROOT/data/schema/hve_measurement.schema.json"
  --inventory "$INVENTORY"
  --boot-class "$BOOT_CLASS"
  --board-serial "$BOARD_SERIAL"
)
if [[ -n "${HVE_SUPPLY_VOLTAGE_V:-}" ]]; then
  ARGS+=(--supply-voltage-v "$HVE_SUPPLY_VOLTAGE_V")
fi
if [[ -n "${HVE_AMBIENT_TEMPERATURE_C:-}" ]]; then
  ARGS+=(--ambient-temperature-c "$HVE_AMBIENT_TEMPERATURE_C")
fi
python "$ROOT/tools/evidence_session.py" "${ARGS[@]}"
