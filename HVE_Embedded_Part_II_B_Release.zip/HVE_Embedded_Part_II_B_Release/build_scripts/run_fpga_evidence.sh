#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="${1:-$ROOT/evidence/fpga-flow}"
python "$ROOT/tools/fpga_flow.py" --project "$ROOT/fpga/icebreaker" --output-dir "$OUT"
python "$ROOT/tools/hash_tree.py" "$OUT" --output "$OUT/SHA256_MANIFEST.json"
