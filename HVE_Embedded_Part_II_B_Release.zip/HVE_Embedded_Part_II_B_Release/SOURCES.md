# Sources and provenance

- HVE core, benchmark workloads, MCU ports and RTL originate from the HVE Embedded Part I and Part II-A packages created for Charles de Paula Eugênio.
- Part II-B adds execution, evidence preservation, analysis safeguards and physical run plans.
- No external source code was copied into this release.
- Python dependencies are declared in `tools/requirements.txt`.
- Target SDKs and FPGA toolchains are not redistributed. Their exact commits and versions must be archived by the laboratory.
- Scientific authorship: Charles de Paula Eugênio.
- Until the author selects a public license, the package remains all rights reserved.
