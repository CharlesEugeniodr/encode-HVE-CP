#include "hve_command.h"
#include "hve_platform.h"

#include <string.h>

int main(void) {
    char line[160];
    char output[1024];
    hve_platform_write_line("{\"schema_version\":1,\"type\":\"ready\",\"target\":\"host-mock\"}");
    while (hve_platform_readline(line, sizeof(line))) {
        if (hve_command_execute(line, output, sizeof(output)) != 0) {
            hve_platform_write_line("{\"schema_version\":1,\"type\":\"error\",\"code\":\"OUTPUT_OVERFLOW\"}");
        } else {
            hve_platform_write_line(output);
        }
        if (strcmp(line, "QUIT") == 0) {
            break;
        }
    }
    return 0;
}
