#define _POSIX_C_SOURCE 200809L

#include "hve_platform.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

#ifndef HVE_BUILD_ID
#define HVE_BUILD_ID "part-ii-a-host"
#endif
#ifndef HVE_BUILD_FLAGS
#define HVE_BUILD_FLAGS "unknown"
#endif

uint64_t hve_platform_counter_read(void) {
    struct timespec ts;
    (void)clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return (uint64_t)ts.tv_sec * UINT64_C(1000000000) + (uint64_t)ts.tv_nsec;
}

uint64_t hve_platform_counter_hz(void) { return UINT64_C(1000000000); }
unsigned hve_platform_counter_bits(void) { return 64u; }
uint64_t hve_platform_core_clock_hz(void) { return 0u; }
void hve_platform_marker_set(int high) { (void)high; }

int hve_platform_readline(char *buffer, size_t capacity) {
    size_t len;
    if (buffer == 0 || capacity < 2u || fgets(buffer, (int)capacity, stdin) == 0) {
        return 0;
    }
    len = strlen(buffer);
    while (len > 0u && (buffer[len - 1u] == '\n' || buffer[len - 1u] == '\r')) {
        buffer[--len] = '\0';
    }
    return 1;
}

void hve_platform_write_line(const char *line) {
    if (line != 0) {
        fputs(line, stdout);
        fputc('\n', stdout);
        fflush(stdout);
    }
}

const char *hve_platform_target_name(void) { return "host-mock"; }
const char *hve_platform_board_name(void) { return "POSIX host - harness validation only"; }
const char *hve_platform_toolchain(void) { return "host C compiler"; }
const char *hve_platform_build_flags(void) { return HVE_BUILD_FLAGS; }
const char *hve_platform_build_id(void) { return HVE_BUILD_ID; }
