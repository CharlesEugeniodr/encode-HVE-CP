#include "hve_command.h"
#include "hve_platform.h"

void hve_stm32_platform_init(void);

void hve_lab_run_forever(void) {
    char line[160];
    char output[1024];
    hve_stm32_platform_init();
    hve_platform_write_line("{\"schema_version\":1,\"type\":\"ready\",\"target\":\"stm32f446re\"}");
    for (;;) {
        if (!hve_platform_readline(line, sizeof(line))) {
            continue;
        }
        if (hve_command_execute(line, output, sizeof(output)) != 0) {
            hve_platform_write_line("{\"schema_version\":1,\"type\":\"error\",\"code\":\"OUTPUT_OVERFLOW\"}");
        } else {
            hve_platform_write_line(output);
        }
    }
}
