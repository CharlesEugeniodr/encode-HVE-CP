#ifndef HVE_STM32_CONFIG_H
#define HVE_STM32_CONFIG_H

/* Adjust these bindings to the STM32CubeMX-generated project. */
#include "main.h"
#include "usart.h"

#define HVE_STM32_UART_HANDLE huart2
#define HVE_STM32_MARKER_GPIO_Port GPIOA
#define HVE_STM32_MARKER_Pin GPIO_PIN_5
#define HVE_STM32_BUILD_ID "stm32f446re-part-ii-a"
#define HVE_STM32_BUILD_FLAGS "declare Cube version, compiler and optimization flags"

#endif /* HVE_STM32_CONFIG_H */
