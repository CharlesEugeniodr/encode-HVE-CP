#include "hve_platform.h"
#include "hve_stm32_config.h"

#include <string.h>

static void dwt_enable(void) {
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0u;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    __DSB();
    __ISB();
}

void hve_stm32_platform_init(void) {
    dwt_enable();
    HAL_GPIO_WritePin(HVE_STM32_MARKER_GPIO_Port, HVE_STM32_MARKER_Pin, GPIO_PIN_RESET);
}

uint64_t hve_platform_counter_read(void) { return (uint64_t)DWT->CYCCNT; }
uint64_t hve_platform_counter_hz(void) { return (uint64_t)HAL_RCC_GetHCLKFreq(); }
unsigned hve_platform_counter_bits(void) { return 32u; }
uint64_t hve_platform_core_clock_hz(void) { return (uint64_t)HAL_RCC_GetHCLKFreq(); }

void hve_platform_marker_set(int high) {
    HAL_GPIO_WritePin(HVE_STM32_MARKER_GPIO_Port, HVE_STM32_MARKER_Pin,
                      high ? GPIO_PIN_SET : GPIO_PIN_RESET);
}

int hve_platform_readline(char *buffer, size_t capacity) {
    size_t n = 0u;
    uint8_t ch;
    if (buffer == 0 || capacity < 2u) {
        return 0;
    }
    for (;;) {
        if (HAL_UART_Receive(&HVE_STM32_UART_HANDLE, &ch, 1u, HAL_MAX_DELAY) != HAL_OK) {
            return 0;
        }
        if (ch == '\r' || ch == '\n') {
            if (n == 0u) continue;
            buffer[n] = '\0';
            return 1;
        }
        if (n + 1u < capacity) {
            buffer[n++] = (char)ch;
        }
    }
}

void hve_platform_write_line(const char *line) {
    static const uint8_t crlf[2] = {'\r', '\n'};
    if (line == 0) return;
    (void)HAL_UART_Transmit(&HVE_STM32_UART_HANDLE, (uint8_t *)(uintptr_t)line,
                           (uint16_t)strlen(line), HAL_MAX_DELAY);
    (void)HAL_UART_Transmit(&HVE_STM32_UART_HANDLE, (uint8_t *)(uintptr_t)crlf,
                           2u, HAL_MAX_DELAY);
}

const char *hve_platform_target_name(void) { return "stm32f446re"; }
const char *hve_platform_board_name(void) { return "NUCLEO-F446RE"; }
const char *hve_platform_toolchain(void) { return __VERSION__; }
const char *hve_platform_build_flags(void) { return HVE_STM32_BUILD_FLAGS; }
const char *hve_platform_build_id(void) { return HVE_STM32_BUILD_ID; }
