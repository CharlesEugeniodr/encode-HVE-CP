# NUCLEO-F446RE drop-in port

This directory is intentionally a drop-in port for an STM32CubeMX/CubeIDE project, because startup code, linker scripts, clock tree, UART, and GPIO ownership must remain explicit in the laboratory archive.

## Integration

1. Create an STM32Cube project for NUCLEO-F446RE.
2. Configure the exact HCLK used in the experiment.
3. Enable USART2 for the ST-LINK virtual COM port, or change `HVE_STM32_UART_HANDLE`.
4. Configure PA5 as a push-pull output for the timing/power marker, or change the marker macros.
5. Add all files from `common/src`, all headers from `common/include`, and the three files in this directory.
6. Call `hve_lab_run_forever()` after `MX_GPIO_Init()` and `MX_USART2_UART_Init()`.
7. Compile with a declared optimization level. Archive the `.map`, ELF, binary, Cube configuration, compiler version, and complete build log.

## Timer

The port enables the Cortex-M DWT cycle counter and reports a 32-bit modulo counter. Each timed run must remain below one counter wrap. At 180 MHz this is under 2^32 cycles; the controller plan should split longer workloads.

## Scientific rule

Do not compare STM32 cycle counts with RP2040 microsecond batches as though they were the same measurement mode. Convert both to time using the declared counter frequency and retain the raw ticks.
