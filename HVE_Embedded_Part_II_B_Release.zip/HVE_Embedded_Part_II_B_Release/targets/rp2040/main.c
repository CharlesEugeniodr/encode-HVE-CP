#include "hve_command.h"
#include "hve_platform.h"

#include <string.h>

void hve_rp2040_platform_init(void);

int main(void) {
    char line[160];
    char output[1024];
    hve_rp2040_platform_init();
    hve_platform_write_line("{\"schema_version\":1,\"type\":\"ready\",\"target\":\"rp2040\"}");
    for (;;) {
        if (!hve_platform_readline(line, sizeof(line))) {
            continue;
        }
        if (hve_command_execute(line, output, sizeof(output)) != 0) {
            hve_platform_write_line("{\"schema_version\":1,\"type\":\"error\",\"code\":\"OUTPUT_OVERFLOW\"}");
        } else {
            hve_platform_write_line(output);
        }
        if (strcmp(line, "QUIT") == 0) {
            hve_platform_write_line("{\"schema_version\":1,\"type\":\"notice\",\"message\":\"RP2040 target remains active; QUIT only terminates host-mock\"}");
        }
    }
}
