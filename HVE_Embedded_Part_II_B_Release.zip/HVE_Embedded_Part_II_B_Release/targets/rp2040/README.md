# RP2040 laboratory target

This is a complete Raspberry Pi Pico SDK project for the HVE Part II-A measurement harness.

## Build

```sh
export PICO_SDK_PATH=/absolute/path/to/pico-sdk
cmake -S targets/rp2040 -B build-rp2040 -DCMAKE_BUILD_TYPE=Release
cmake --build build-rp2040
```

Flash `hve_rp2040_lab.uf2`, connect the USB CDC serial port, and run the host controller.

## Measurement boundary

- Timer: the RP2040 64-bit hardware timer, in microseconds.
- Core clock: reported at runtime from `clk_sys`.
- Marker: GPIO 2 is high only during the measured region.
- Because timer resolution is 1 microsecond, use large iteration counts. Do not report a single-operation latency derived from one invocation.
- USB output occurs outside the timed region.

The target must be rebuilt with a frozen SDK commit, compiler version, flags, voltage, and clock configuration before publication.
