#include "hve_platform.h"

#include "hardware/clocks.h"
#include "hardware/gpio.h"
#include "hardware/timer.h"
#include "pico/stdlib.h"

#include <stdio.h>

#ifndef HVE_MARKER_GPIO
#define HVE_MARKER_GPIO 2u
#endif
#ifndef HVE_BUILD_ID
#define HVE_BUILD_ID "rp2040-unversioned"
#endif
#ifndef HVE_BUILD_FLAGS
#define HVE_BUILD_FLAGS "not-declared"
#endif

void hve_rp2040_platform_init(void) {
    stdio_init_all();
    gpio_init(HVE_MARKER_GPIO);
    gpio_set_dir(HVE_MARKER_GPIO, GPIO_OUT);
    gpio_put(HVE_MARKER_GPIO, 0);
}

uint64_t hve_platform_counter_read(void) { return time_us_64(); }
uint64_t hve_platform_counter_hz(void) { return UINT64_C(1000000); }
unsigned hve_platform_counter_bits(void) { return 64u; }
uint64_t hve_platform_core_clock_hz(void) { return (uint64_t)clock_get_hz(clk_sys); }
void hve_platform_marker_set(int high) { gpio_put(HVE_MARKER_GPIO, high ? 1 : 0); }

int hve_platform_readline(char *buffer, size_t capacity) {
    size_t n = 0u;
    if (buffer == 0 || capacity < 2u) {
        return 0;
    }
    for (;;) {
        int ch = getchar_timeout_us(1000000u);
        if (ch == PICO_ERROR_TIMEOUT) {
            tight_loop_contents();
            continue;
        }
        if (ch == '\r' || ch == '\n') {
            if (n == 0u) {
                continue;
            }
            buffer[n] = '\0';
            return 1;
        }
        if (n + 1u < capacity) {
            buffer[n++] = (char)ch;
        }
    }
}

void hve_platform_write_line(const char *line) {
    if (line != 0) {
        puts(line);
        fflush(stdout);
    }
}

const char *hve_platform_target_name(void) { return "rp2040"; }
const char *hve_platform_board_name(void) { return "Raspberry Pi Pico / RP2040"; }
const char *hve_platform_toolchain(void) { return __VERSION__; }
const char *hve_platform_build_flags(void) { return HVE_BUILD_FLAGS; }
const char *hve_platform_build_id(void) { return HVE_BUILD_ID; }
