# HVE Embedded Part II-B — Physical Evidence Execution Layer

This release starts the physical-validation stage without fabricating hardware results. It extends Part II-A with a traceable laboratory execution system, immutable evidence sessions, memory/stack extraction, FPGA-flow capture, energy segmentation and article-table generation.

## What is new

- `tools/evidence_session.py`: creates a complete session folder and chain of custody.
- `tools/lab_controller_v2.py`: serial/host controller with transcript, boot class and physical metadata.
- `tools/toolchain_probe.py`: records installed tools, SDK paths and exact versions.
- `tools/map_metrics.py`: extracts ELF section sizes and preserves raw `size` output.
- `tools/stack_usage_collect.py`: archives GCC `-fstack-usage` evidence.
- `tools/fpga_flow.py`: executes simulation/synthesis when available and records `not_executed` otherwise.
- `tools/power_segment.py`: computes marker-gated energy per segment.
- `tools/generate_publication_tables.py`: accepts physical summaries only for physical result tables.
- `lab/*.template.json`: hardware inventory and experiment lock.
- `data/plans/physical_*`: bring-up and publication plans.
- `build_scripts/*`: build and capture wrappers.

## Verified non-physical execution

```sh
./scripts/test_part_ii_b.sh
```

The test builds the portable C target, runs unit tests, probes the environment, extracts host binary metrics, performs an end-to-end dry-run evidence session, validates the JSONL dataset, runs the statistical pipeline and generates a SHA-256 manifest.

## RP2040 build

```sh
export PICO_SDK_PATH=/absolute/frozen/pico-sdk
./build_scripts/build_rp2040_evidence.sh
```

The script requires `arm-none-eabi-gcc`. It archives ELF, UF2/BIN outputs when present, map file, memory metrics, stack-usage files, build logs and hashes.

## Physical MCU session

1. Copy `lab/hardware_inventory.template.json` to `lab/hardware_inventory.json`.
2. Fill every hardware and instrument field.
3. Flash the target firmware.
4. Execute:

```sh
./build_scripts/run_physical_mcu_session.sh /dev/ttyACM0 BOARD_SERIAL cold_boot
```

Use `COM5` or the correct port on Windows. Repeat with `warm_reset`, then execute the publication plan only after the quick plan passes.

## FPGA evidence

```sh
./build_scripts/run_fpga_evidence.sh
```

If tools are absent, the result is explicitly `not_executed`; it is never interpreted as an HVE failure.

## Evidence rule

Host, synthetic and cycle-model outputs validate the harness only. They cannot be inserted into the manuscript as MCU/FPGA performance, area, energy, latency or Fmax results.

## Key documents

- `docs/HVE_Embedded_Part_II_B_Execution_Protocol_PT.docx`
- `docs/PART_II_B_RUNBOOK_PT.md`
- `docs/article_addendum/HVE720_JSA_Experimental_Methods_v3_EN.docx`
- `PART_II_B_STATUS.md`
