#include "hve.h"
#include "hve_baseline.h"
#include "hve_bench.h"
#include "hve_command.h"

#include <stdio.h>
#include <string.h>

#define CHECK(x) do { if (!(x)) { fprintf(stderr, "CHECK failed at %s:%d: %s\n", __FILE__, __LINE__, #x); return 1; } } while (0)

static int test_baselines(void) {
    uint32_t theta, s, tau, phi;
    for (theta = 0u; theta < 360u; ++theta) {
        for (s = 0u; s < 2u; ++s) {
            for (tau = 0u; tau < 5u; ++tau) {
                for (phi = 0u; phi < 9u; ++phi) {
                    hve_state_t in = {(uint16_t)theta, (uint8_t)s, (uint8_t)tau, (uint8_t)phi};
                    hve_state_t out;
                    uint32_t word;
                    uint8_t bytes[5];
                    CHECK(hve_baseline17_encode(&in, &word) == HVE_OK);
                    CHECK(hve_baseline17_decode(word, &out) == HVE_OK);
                    CHECK(in.theta == out.theta && in.s == out.s && in.tau == out.tau && in.phi == out.phi);
                    CHECK(hve_baseline40_pack(&in, bytes) == HVE_OK);
                    CHECK(hve_baseline40_unpack(bytes, &out) == HVE_OK);
                    CHECK(in.theta == out.theta && in.s == out.s && in.tau == out.tau && in.phi == out.phi);
                }
            }
        }
    }
    CHECK(hve_baseline17_decode(UINT32_C(1) << 17, &(hve_state_t){0}) == HVE_ERR_INVALID_WORD);
    return 0;
}

static int test_counter_delta(void) {
    CHECK(hve_bench_counter_delta(100u, 150u, 64u) == 50u);
    CHECK(hve_bench_counter_delta(250u, 5u, 8u) == 11u);
    CHECK(hve_bench_counter_delta(0u, 0u, 0u) == 0u);
    return 0;
}

static int test_selftest(void) {
    uint32_t states, reserved, failures;
    CHECK(hve_bench_selftest(&states, &reserved, &failures) == HVE_OK);
    CHECK(states == 32400u);
    CHECK(reserved == 368u);
    CHECK(failures == 0u);
    return 0;
}

static int test_command(void) {
    char output[1024];
    CHECK(hve_command_execute("PING", output, sizeof(output)) == 0);
    CHECK(strstr(output, "pong") != 0);
    CHECK(hve_command_execute("INFO", output, sizeof(output)) == 0);
    CHECK(strstr(output, "host-mock") != 0);
    CHECK(hve_command_execute("RUN BASE_ENCODE 1000 16 123 10", output, sizeof(output)) == 0);
    CHECK(strstr(output, "measurement") != 0);
    CHECK(strstr(output, "\"status\":\"ok\"") != 0);
    CHECK(hve_command_execute("RUN NOPE 10 1 1", output, sizeof(output)) == 0);
    CHECK(strstr(output, "UNKNOWN_WORKLOAD") != 0);
    return 0;
}

int main(void) {
    CHECK(test_baselines() == 0);
    CHECK(test_counter_delta() == 0);
    CHECK(test_selftest() == 0);
    CHECK(test_command() == 0);
    puts("PART II-A C TESTS PASSED");
    return 0;
}
