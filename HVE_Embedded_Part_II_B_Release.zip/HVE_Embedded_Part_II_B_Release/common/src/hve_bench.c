#include "hve_bench.h"

#include "hve.h"
#include "hve_baseline.h"
#include "hve_platform.h"

#include <string.h>

static volatile uint32_t hve_bench_sink;

static uint32_t rng_next(uint32_t *state) {
    uint32_t x = *state;
    if (x == 0u) {
        x = UINT32_C(0x6D2B79F5);
    }
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    *state = x;
    return x;
}

static hve_state_t state_from_rng(uint32_t *rng) {
    hve_state_t state;
    state.theta = (uint16_t)(rng_next(rng) % HVE_THETA_CARDINALITY);
    state.s = (uint8_t)(rng_next(rng) % HVE_S_CARDINALITY);
    state.tau = (uint8_t)(rng_next(rng) % HVE_TAU_CARDINALITY);
    state.phi = (uint8_t)(rng_next(rng) % HVE_PHI_CARDINALITY);
    return state;
}

static hve_color_t color_from_rng(uint32_t *rng, uint32_t ordinal) {
    hve_color_t color;
    if ((ordinal & 7u) == 0u) {
        color.present = 0u;
        color.r = 0u;
        color.g = 0u;
        color.b = 0u;
    } else {
        color.present = 1u;
        color.r = (uint8_t)rng_next(rng);
        color.g = (uint8_t)rng_next(rng);
        color.b = (uint8_t)rng_next(rng);
    }
    return color;
}

const char *hve_bench_workload_name(hve_bench_workload_t workload) {
    static const char *const names[HVE_BENCH_WORKLOAD_COUNT] = {
        "BASE_ENCODE",
        "BASE_DECODE",
        "BASE_ROUNDTRIP",
        "BASE15_PACK",
        "BASE15_UNPACK",
        "CHI40_PACK",
        "CHI40_UNPACK",
        "FRAME_PARSE",
        "BASELINE17_ENCODE",
        "BASELINE17_DECODE",
        "BASELINE40_PACK",
        "BASELINE40_UNPACK"
    };
    if ((unsigned)workload >= (unsigned)HVE_BENCH_WORKLOAD_COUNT) {
        return "UNKNOWN";
    }
    return names[workload];
}

int hve_bench_workload_parse(const char *name, hve_bench_workload_t *workload_out) {
    unsigned i;
    if (name == 0 || workload_out == 0) {
        return -1;
    }
    for (i = 0u; i < (unsigned)HVE_BENCH_WORKLOAD_COUNT; ++i) {
        if (strcmp(name, hve_bench_workload_name((hve_bench_workload_t)i)) == 0) {
            *workload_out = (hve_bench_workload_t)i;
            return 0;
        }
    }
    return -1;
}

uint64_t hve_bench_counter_delta(uint64_t start, uint64_t end, unsigned bits) {
    if (bits == 0u || bits > 64u) {
        return 0u;
    }
    if (bits == 64u) {
        return end - start;
    }
    return (end - start) & ((UINT64_C(1) << bits) - 1u);
}

static int prepare_vectors(const hve_bench_config_t *config,
                           hve_state_t states[HVE_BENCH_MAX_BATCH],
                           hve_color_t colors[HVE_BENCH_MAX_BATCH],
                           uint16_t indices[HVE_BENCH_MAX_BATCH],
                           uint8_t chi40[HVE_BENCH_MAX_BATCH][5],
                           uint32_t baseline17[HVE_BENCH_MAX_BATCH],
                           uint8_t baseline40[HVE_BENCH_MAX_BATCH][5]) {
    uint32_t rng = config->seed;
    uint32_t i;
    uint32_t count = config->batch_size;
    if (count == 0u) {
        count = 1u;
    }
    if (count > HVE_BENCH_MAX_BATCH) {
        return HVE_ERR_RANGE;
    }
    for (i = 0u; i < count; ++i) {
        states[i] = state_from_rng(&rng);
        colors[i] = color_from_rng(&rng, i);
        if (hve_base_encode(&states[i], &indices[i]) != HVE_OK) {
            return HVE_ERR_RANGE;
        }
        if (hve_chi40_pack(&states[i], &colors[i], chi40[i]) != HVE_OK) {
            return HVE_ERR_INVALID_COLOR;
        }
        if (hve_baseline17_encode(&states[i], &baseline17[i]) != HVE_OK) {
            return HVE_ERR_RANGE;
        }
        if (hve_baseline40_pack(&states[i], baseline40[i]) != HVE_OK) {
            return HVE_ERR_RANGE;
        }
    }
    return HVE_OK;
}

static int run_workload(const hve_bench_config_t *config,
                        uint32_t *checksum_out,
                        uint64_t *operations_out) {
    hve_state_t states[HVE_BENCH_MAX_BATCH];
    hve_color_t colors[HVE_BENCH_MAX_BATCH];
    uint16_t indices[HVE_BENCH_MAX_BATCH];
    uint16_t unpacked[HVE_BENCH_MAX_BATCH];
    uint8_t chi40[HVE_BENCH_MAX_BATCH][5];
    uint32_t baseline17[HVE_BENCH_MAX_BATCH];
    uint8_t baseline40[HVE_BENCH_MAX_BATCH][5];
    uint8_t packed15[120];
    uint8_t frame[HVE_FRAME_HEADER_SIZE + 120];
    uint32_t checksum = UINT32_C(2166136261);
    uint32_t count = config->batch_size == 0u ? 1u : config->batch_size;
    uint32_t it;
    size_t packed_size;
    size_t written;
    int st;

    if (config->iterations == 0u || count > HVE_BENCH_MAX_BATCH) {
        return HVE_ERR_RANGE;
    }
    st = prepare_vectors(config, states, colors, indices, chi40, baseline17, baseline40);
    if (st != HVE_OK) {
        return st;
    }
    packed_size = hve_base15_packed_size(count);
    if (packed_size == 0u || packed_size > sizeof(packed15)) {
        return HVE_ERR_OVERFLOW;
    }
    if (hve_base15_pack(indices, count, packed15, sizeof(packed15), &written) != HVE_OK || written != packed_size) {
        return HVE_ERR_INVALID_WORD;
    }
    if (hve_frame_write_header(HVE_PROFILE_BASE15, 0u, count, packed15, packed_size, frame) != HVE_OK) {
        return HVE_ERR_INVALID_FRAME;
    }
    memcpy(frame + HVE_FRAME_HEADER_SIZE, packed15, packed_size);

    switch (config->workload) {
        case HVE_BENCH_BASE_ENCODE:
            for (it = 0u; it < config->iterations; ++it) {
                uint16_t index;
                st = hve_base_encode(&states[it % count], &index);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ index) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASE_DECODE:
            for (it = 0u; it < config->iterations; ++it) {
                hve_state_t state;
                st = hve_base_decode(indices[it % count], &state);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ state.theta ^ ((uint32_t)state.s << 10) ^
                            ((uint32_t)state.tau << 12) ^ ((uint32_t)state.phi << 16)) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASE_ROUNDTRIP:
            for (it = 0u; it < config->iterations; ++it) {
                uint16_t index;
                hve_state_t state;
                st = hve_base_encode(&states[it % count], &index);
                if (st != HVE_OK) return st;
                st = hve_base_decode(index, &state);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ index ^ state.theta) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASE15_PACK:
            for (it = 0u; it < config->iterations; ++it) {
                st = hve_base15_pack(indices, count, packed15, sizeof(packed15), &written);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ packed15[it % packed_size] ^ (uint32_t)written) * UINT32_C(16777619);
            }
            *operations_out = (uint64_t)config->iterations * count;
            break;

        case HVE_BENCH_BASE15_UNPACK:
            for (it = 0u; it < config->iterations; ++it) {
                size_t states_written;
                st = hve_base15_unpack(packed15, packed_size, count, unpacked, HVE_BENCH_MAX_BATCH, &states_written);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ unpacked[it % count] ^ (uint32_t)states_written) * UINT32_C(16777619);
            }
            *operations_out = (uint64_t)config->iterations * count;
            break;

        case HVE_BENCH_CHI40_PACK:
            for (it = 0u; it < config->iterations; ++it) {
                uint8_t out[5];
                uint32_t k = it % count;
                st = hve_chi40_pack(&states[k], &colors[k], out);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ out[it % 5u]) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_CHI40_UNPACK:
            for (it = 0u; it < config->iterations; ++it) {
                hve_state_t state;
                hve_color_t color;
                st = hve_chi40_unpack(chi40[it % count], &state, &color);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ state.theta ^ color.r ^ ((uint32_t)color.present << 24)) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_FRAME_PARSE:
            for (it = 0u; it < config->iterations; ++it) {
                hve_frame_info_t info;
                const uint8_t *payload;
                st = hve_frame_parse(frame, HVE_FRAME_HEADER_SIZE + packed_size, &info, &payload);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ info.state_count ^ payload[it % packed_size]) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASELINE17_ENCODE:
            for (it = 0u; it < config->iterations; ++it) {
                uint32_t word;
                st = hve_baseline17_encode(&states[it % count], &word);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ word) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASELINE17_DECODE:
            for (it = 0u; it < config->iterations; ++it) {
                hve_state_t state;
                st = hve_baseline17_decode(baseline17[it % count], &state);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ state.theta ^ ((uint32_t)state.phi << 16)) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASELINE40_PACK:
            for (it = 0u; it < config->iterations; ++it) {
                uint8_t out[5];
                st = hve_baseline40_pack(&states[it % count], out);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ out[it % 5u]) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        case HVE_BENCH_BASELINE40_UNPACK:
            for (it = 0u; it < config->iterations; ++it) {
                hve_state_t state;
                st = hve_baseline40_unpack(baseline40[it % count], &state);
                if (st != HVE_OK) return st;
                checksum = (checksum ^ state.theta ^ ((uint32_t)state.tau << 12)) * UINT32_C(16777619);
            }
            *operations_out = config->iterations;
            break;

        default:
            return HVE_ERR_UNSUPPORTED_PROFILE;
    }

    hve_bench_sink ^= checksum;
    *checksum_out = checksum;
    return HVE_OK;
}

int hve_bench_execute(const hve_bench_config_t *config, hve_bench_result_t *result) {
    hve_bench_config_t warm;
    uint64_t start;
    uint64_t end;
    uint64_t operations = 0u;
    uint32_t checksum = 0u;
    int st;

    if (config == 0 || result == 0) {
        return HVE_ERR_NULL;
    }
    if ((unsigned)config->workload >= (unsigned)HVE_BENCH_WORKLOAD_COUNT ||
        config->iterations == 0u || config->batch_size == 0u ||
        config->batch_size > HVE_BENCH_MAX_BATCH) {
        return HVE_ERR_RANGE;
    }

    memset(result, 0, sizeof(*result));
    warm = *config;
    warm.iterations = config->warmup_iterations;
    if (warm.iterations > 0u) {
        st = run_workload(&warm, &checksum, &operations);
        if (st != HVE_OK) {
            result->status = st;
            return st;
        }
    }

    hve_platform_marker_set(1);
    start = hve_platform_counter_read();
    st = run_workload(config, &checksum, &operations);
    end = hve_platform_counter_read();
    hve_platform_marker_set(0);

    result->ticks_total = hve_bench_counter_delta(start, end, hve_platform_counter_bits());
    result->operations = operations;
    result->timer_hz = hve_platform_counter_hz();
    result->core_clock_hz = hve_platform_core_clock_hz();
    result->checksum = checksum;
    result->iterations = config->iterations;
    result->batch_size = config->batch_size;
    result->seed = config->seed;
    result->counter_bits = hve_platform_counter_bits();
    result->status = st;
    return st;
}

int hve_bench_selftest(uint32_t *states_checked, uint32_t *reserved_checked, uint32_t *failures) {
    uint32_t state_count = 0u;
    uint32_t reserved_count = 0u;
    uint32_t fail_count = 0u;
    uint32_t theta;
    uint32_t s;
    uint32_t tau;
    uint32_t phi;
    uint32_t index;

    if (states_checked == 0 || reserved_checked == 0 || failures == 0) {
        return HVE_ERR_NULL;
    }

    for (theta = 0u; theta < 360u; ++theta) {
        for (s = 0u; s < 2u; ++s) {
            for (tau = 0u; tau < 5u; ++tau) {
                for (phi = 0u; phi < 9u; ++phi) {
                    hve_state_t in;
                    hve_state_t out;
                    uint16_t encoded;
                    in.theta = (uint16_t)theta;
                    in.s = (uint8_t)s;
                    in.tau = (uint8_t)tau;
                    in.phi = (uint8_t)phi;
                    if (hve_base_encode(&in, &encoded) != HVE_OK ||
                        hve_base_decode(encoded, &out) != HVE_OK ||
                        out.theta != in.theta || out.s != in.s ||
                        out.tau != in.tau || out.phi != in.phi) {
                        ++fail_count;
                    }
                    ++state_count;
                }
            }
        }
    }
    for (index = HVE_BASE_CARDINALITY; index < HVE_BASE_WORD_CAPACITY; ++index) {
        hve_state_t out;
        if (hve_base_decode((uint16_t)index, &out) != HVE_ERR_INVALID_WORD) {
            ++fail_count;
        }
        ++reserved_count;
    }

    *states_checked = state_count;
    *reserved_checked = reserved_count;
    *failures = fail_count;
    return fail_count == 0u ? HVE_OK : HVE_ERR_INVALID_WORD;
}
