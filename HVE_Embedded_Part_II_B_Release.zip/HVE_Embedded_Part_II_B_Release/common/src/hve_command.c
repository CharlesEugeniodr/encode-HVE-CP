#include "hve_command.h"

#include "hve.h"
#include "hve_bench.h"
#include "hve_platform.h"

#include <inttypes.h>
#include <stdio.h>
#include <string.h>

static int write_error(char *output, size_t capacity, const char *code, const char *message) {
    int n = snprintf(output, capacity,
                     "{\"schema_version\":%u,\"type\":\"error\",\"code\":\"%s\",\"message\":\"%s\"}",
                     HVE_BENCH_SCHEMA_VERSION, code, message);
    return (n < 0 || (size_t)n >= capacity) ? -1 : 0;
}

int hve_command_execute(const char *line, char *output, size_t output_capacity) {
    char command[16];
    char workload_name[32];
    uint32_t iterations;
    uint32_t batch_size;
    uint32_t seed;
    uint32_t warmup = 1000u;
    int fields;

    if (line == 0 || output == 0 || output_capacity == 0u) {
        return -1;
    }

    if (strcmp(line, "PING") == 0) {
        int n = snprintf(output, output_capacity,
                         "{\"schema_version\":%u,\"type\":\"pong\",\"status\":\"ok\"}",
                         HVE_BENCH_SCHEMA_VERSION);
        return (n < 0 || (size_t)n >= output_capacity) ? -1 : 0;
    }

    if (strcmp(line, "INFO") == 0) {
        int n = snprintf(output, output_capacity,
                         "{\"schema_version\":%u,\"type\":\"info\","
                         "\"target\":\"%s\",\"board\":\"%s\",\"toolchain\":\"%s\","
                         "\"build_flags\":\"%s\",\"build_id\":\"%s\","
                         "\"timer_hz\":%" PRIu64 ",\"counter_bits\":%u,\"core_clock_hz\":%" PRIu64 ","
                         "\"hve_version\":\"%u.%u\",\"max_batch\":%u}",
                         HVE_BENCH_SCHEMA_VERSION,
                         hve_platform_target_name(), hve_platform_board_name(),
                         hve_platform_toolchain(), hve_platform_build_flags(),
                         hve_platform_build_id(), hve_platform_counter_hz(),
                         hve_platform_counter_bits(), hve_platform_core_clock_hz(),
                         HVE_VERSION_MAJOR, HVE_VERSION_MINOR, HVE_BENCH_MAX_BATCH);
        return (n < 0 || (size_t)n >= output_capacity) ? -1 : 0;
    }

    if (strcmp(line, "SELFTEST") == 0) {
        uint32_t states_checked;
        uint32_t reserved_checked;
        uint32_t failures;
        int st = hve_bench_selftest(&states_checked, &reserved_checked, &failures);
        int n = snprintf(output, output_capacity,
                         "{\"schema_version\":%u,\"type\":\"selftest\","
                         "\"status\":\"%s\",\"status_code\":%d,"
                         "\"states_checked\":%u,\"reserved_checked\":%u,\"failures\":%u}",
                         HVE_BENCH_SCHEMA_VERSION, st == HVE_OK ? "ok" : "failed", st,
                         states_checked, reserved_checked, failures);
        return (n < 0 || (size_t)n >= output_capacity) ? -1 : 0;
    }

    if (strcmp(line, "HELP") == 0) {
        int n = snprintf(output, output_capacity,
                         "{\"schema_version\":%u,\"type\":\"help\","
                         "\"commands\":[\"PING\",\"INFO\",\"SELFTEST\","
                         "\"RUN <WORKLOAD> <ITERATIONS> <BATCH> <SEED> [WARMUP]\",\"QUIT\"]}",
                         HVE_BENCH_SCHEMA_VERSION);
        return (n < 0 || (size_t)n >= output_capacity) ? -1 : 0;
    }

    if (strcmp(line, "QUIT") == 0) {
        int n = snprintf(output, output_capacity,
                         "{\"schema_version\":%u,\"type\":\"quit\",\"status\":\"ok\"}",
                         HVE_BENCH_SCHEMA_VERSION);
        return (n < 0 || (size_t)n >= output_capacity) ? -1 : 0;
    }

    fields = sscanf(line, "%15s %31s %" SCNu32 " %" SCNu32 " %" SCNu32 " %" SCNu32,
                    command, workload_name, &iterations, &batch_size, &seed, &warmup);
    if (fields < 5 || strcmp(command, "RUN") != 0) {
        return write_error(output, output_capacity, "MALFORMED_COMMAND", "Use HELP for the command grammar");
    }

    {
        hve_bench_workload_t workload;
        hve_bench_config_t config;
        hve_bench_result_t result;
        int st;
        int n;
        if (hve_bench_workload_parse(workload_name, &workload) != 0) {
            return write_error(output, output_capacity, "UNKNOWN_WORKLOAD", workload_name);
        }
        config.workload = workload;
        config.iterations = iterations;
        config.batch_size = batch_size;
        config.seed = seed;
        config.warmup_iterations = fields >= 6 ? warmup : 1000u;
        st = hve_bench_execute(&config, &result);
        n = snprintf(output, output_capacity,
                     "{\"schema_version\":%u,\"type\":\"measurement\","
                     "\"target\":\"%s\",\"board\":\"%s\",\"build_id\":\"%s\","
                     "\"workload\":\"%s\",\"iterations\":%u,\"batch_size\":%u,"
                     "\"seed\":%u,\"warmup_iterations\":%u,\"operations\":%" PRIu64 ","
                     "\"ticks_total\":%" PRIu64 ",\"timer_hz\":%" PRIu64 ","
                     "\"counter_bits\":%u,\"core_clock_hz\":%" PRIu64 ","
                     "\"checksum\":%u,\"status\":\"%s\",\"status_code\":%d}",
                     HVE_BENCH_SCHEMA_VERSION,
                     hve_platform_target_name(), hve_platform_board_name(), hve_platform_build_id(),
                     hve_bench_workload_name(workload), result.iterations, result.batch_size,
                     result.seed, config.warmup_iterations, result.operations,
                     result.ticks_total, result.timer_hz, result.counter_bits,
                     result.core_clock_hz, result.checksum,
                     st == HVE_OK ? "ok" : "failed", st);
        return (n < 0 || (size_t)n >= output_capacity) ? -1 : 0;
    }
}
