#include "hve_baseline.h"

hve_status_t hve_baseline17_encode(const hve_state_t *state, uint32_t *word_out) {
    hve_status_t st;
    if (word_out == 0) {
        return HVE_ERR_NULL;
    }
    st = hve_state_validate(state);
    if (st != HVE_OK) {
        return st;
    }
    *word_out = ((uint32_t)state->theta << 8) |
                ((uint32_t)state->s << 7) |
                ((uint32_t)state->tau << 4) |
                (uint32_t)state->phi;
    return HVE_OK;
}

hve_status_t hve_baseline17_decode(uint32_t word, hve_state_t *state_out) {
    hve_state_t state;
    if (state_out == 0) {
        return HVE_ERR_NULL;
    }
    if ((word >> 17) != 0u) {
        return HVE_ERR_INVALID_WORD;
    }
    state.theta = (uint16_t)((word >> 8) & 0x1FFu);
    state.s = (uint8_t)((word >> 7) & 0x1u);
    state.tau = (uint8_t)((word >> 4) & 0x7u);
    state.phi = (uint8_t)(word & 0xFu);
    if (hve_state_validate(&state) != HVE_OK) {
        return HVE_ERR_INVALID_WORD;
    }
    *state_out = state;
    return HVE_OK;
}

hve_status_t hve_baseline40_pack(const hve_state_t *state, uint8_t output[5]) {
    hve_status_t st;
    if (output == 0) {
        return HVE_ERR_NULL;
    }
    st = hve_state_validate(state);
    if (st != HVE_OK) {
        return st;
    }
    output[0] = (uint8_t)(state->theta >> 8);
    output[1] = (uint8_t)state->theta;
    output[2] = state->s;
    output[3] = state->tau;
    output[4] = state->phi;
    return HVE_OK;
}

hve_status_t hve_baseline40_unpack(const uint8_t input[5], hve_state_t *state_out) {
    hve_state_t state;
    if (input == 0 || state_out == 0) {
        return HVE_ERR_NULL;
    }
    state.theta = (uint16_t)(((uint16_t)input[0] << 8) | input[1]);
    state.s = input[2];
    state.tau = input[3];
    state.phi = input[4];
    if (hve_state_validate(&state) != HVE_OK) {
        return HVE_ERR_INVALID_WORD;
    }
    *state_out = state;
    return HVE_OK;
}
