#include "hve.h"

#include <limits.h>
#include <string.h>

static void put_u16_be(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)v;
}

static void put_u32_be(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}

static uint16_t get_u16_be(const uint8_t *p) {
    return (uint16_t)(((uint16_t)p[0] << 8) | (uint16_t)p[1]);
}

static uint32_t get_u32_be(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) |
           ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) |
           (uint32_t)p[3];
}

hve_status_t hve_state_validate(const hve_state_t *state) {
    if (state == NULL) {
        return HVE_ERR_NULL;
    }
    if (state->theta >= HVE_THETA_CARDINALITY ||
        state->s >= HVE_S_CARDINALITY ||
        state->tau >= HVE_TAU_CARDINALITY ||
        state->phi >= HVE_PHI_CARDINALITY) {
        return HVE_ERR_RANGE;
    }
    return HVE_OK;
}

hve_status_t hve_color_validate(const hve_color_t *color) {
    if (color == NULL) {
        return HVE_ERR_NULL;
    }
    if (color->present > 1u) {
        return HVE_ERR_INVALID_COLOR;
    }
    if (color->present == 0u && (color->r != 0u || color->g != 0u || color->b != 0u)) {
        return HVE_ERR_INVALID_COLOR;
    }
    return HVE_OK;
}

hve_status_t hve_sigma_to_s(int sigma, uint8_t *s_out) {
    if (s_out == NULL) {
        return HVE_ERR_NULL;
    }
    if (sigma == 1) {
        *s_out = 0u;
        return HVE_OK;
    }
    if (sigma == -1) {
        *s_out = 1u;
        return HVE_OK;
    }
    return HVE_ERR_RANGE;
}

hve_status_t hve_s_to_sigma(uint8_t s, int *sigma_out) {
    if (sigma_out == NULL) {
        return HVE_ERR_NULL;
    }
    if (s >= 2u) {
        return HVE_ERR_RANGE;
    }
    *sigma_out = (s == 0u) ? 1 : -1;
    return HVE_OK;
}

hve_status_t hve_base_encode(const hve_state_t *state, uint16_t *index_out) {
    uint32_t index;
    hve_status_t status;

    if (index_out == NULL) {
        return HVE_ERR_NULL;
    }
    status = hve_state_validate(state);
    if (status != HVE_OK) {
        return status;
    }

    index = ((((uint32_t)state->theta * 2u + state->s) * 5u + state->tau) * 9u + state->phi);
    if (index >= HVE_BASE_CARDINALITY) {
        return HVE_ERR_OVERFLOW;
    }
    *index_out = (uint16_t)index;
    return HVE_OK;
}

hve_status_t hve_base_decode(uint16_t index, hve_state_t *state_out) {
    uint32_t q1;
    uint32_t q2;

    if (state_out == NULL) {
        return HVE_ERR_NULL;
    }
    if ((uint32_t)index >= HVE_BASE_CARDINALITY) {
        return HVE_ERR_INVALID_WORD;
    }

    state_out->phi = (uint8_t)(index % 9u);
    q1 = index / 9u;
    state_out->tau = (uint8_t)(q1 % 5u);
    q2 = q1 / 5u;
    state_out->s = (uint8_t)(q2 % 2u);
    state_out->theta = (uint16_t)(q2 / 2u);
    return HVE_OK;
}

hve_status_t hve_group_add(const hve_state_t *a, const hve_state_t *b, hve_state_t *out) {
    hve_status_t status;
    if (out == NULL) {
        return HVE_ERR_NULL;
    }
    status = hve_state_validate(a);
    if (status != HVE_OK) {
        return status;
    }
    status = hve_state_validate(b);
    if (status != HVE_OK) {
        return status;
    }
    out->theta = (uint16_t)(((uint32_t)a->theta + b->theta) % 360u);
    out->s = (uint8_t)((a->s + b->s) % 2u);
    out->tau = (uint8_t)((a->tau + b->tau) % 5u);
    out->phi = (uint8_t)((a->phi + b->phi) % 9u);
    return HVE_OK;
}

hve_status_t hve_group_inverse(const hve_state_t *a, hve_state_t *out) {
    hve_status_t status;
    if (out == NULL) {
        return HVE_ERR_NULL;
    }
    status = hve_state_validate(a);
    if (status != HVE_OK) {
        return status;
    }
    out->theta = (uint16_t)((360u - a->theta) % 360u);
    out->s = (uint8_t)((2u - a->s) % 2u);
    out->tau = (uint8_t)((5u - a->tau) % 5u);
    out->phi = (uint8_t)((9u - a->phi) % 9u);
    return HVE_OK;
}

size_t hve_base15_packed_size(size_t state_count) {
    if (state_count > (SIZE_MAX - 7u) / 15u) {
        return 0u;
    }
    return (state_count * 15u + 7u) / 8u;
}

hve_status_t hve_base15_pack(const uint16_t *indices,
                             size_t state_count,
                             uint8_t *output,
                             size_t output_size,
                             size_t *bytes_written) {
    size_t required;
    size_t bit_pos = 0u;
    size_t i;

    if ((state_count > 0u && (indices == NULL || output == NULL)) || bytes_written == NULL) {
        return HVE_ERR_NULL;
    }
    required = hve_base15_packed_size(state_count);
    if (state_count > 0u && required == 0u) {
        return HVE_ERR_OVERFLOW;
    }
    if (output_size < required) {
        return HVE_ERR_BUFFER_TOO_SMALL;
    }
    if (required > 0u) {
        memset(output, 0, required);
    }

    for (i = 0u; i < state_count; ++i) {
        int bit;
        uint16_t word = indices[i];
        if ((uint32_t)word >= HVE_BASE_CARDINALITY) {
            return HVE_ERR_INVALID_WORD;
        }
        for (bit = 14; bit >= 0; --bit) {
            size_t byte_index = bit_pos / 8u;
            unsigned bit_in_byte = (unsigned)(7u - (bit_pos % 8u));
            output[byte_index] |= (uint8_t)(((word >> bit) & 1u) << bit_in_byte);
            ++bit_pos;
        }
    }

    *bytes_written = required;
    return HVE_OK;
}

hve_status_t hve_base15_unpack(const uint8_t *input,
                               size_t input_size,
                               size_t state_count,
                               uint16_t *indices_out,
                               size_t indices_capacity,
                               size_t *states_written) {
    size_t required;
    size_t bit_pos = 0u;
    size_t i;

    if ((state_count > 0u && (input == NULL || indices_out == NULL)) || states_written == NULL) {
        return HVE_ERR_NULL;
    }
    if (indices_capacity < state_count) {
        return HVE_ERR_BUFFER_TOO_SMALL;
    }
    required = hve_base15_packed_size(state_count);
    if (state_count > 0u && required == 0u) {
        return HVE_ERR_OVERFLOW;
    }
    if (input_size < required) {
        return HVE_ERR_BUFFER_TOO_SMALL;
    }

    for (i = 0u; i < state_count; ++i) {
        int bit;
        uint16_t word = 0u;
        for (bit = 14; bit >= 0; --bit) {
            size_t byte_index = bit_pos / 8u;
            unsigned bit_in_byte = (unsigned)(7u - (bit_pos % 8u));
            uint16_t value = (uint16_t)((input[byte_index] >> bit_in_byte) & 1u);
            word |= (uint16_t)(value << bit);
            ++bit_pos;
        }
        if ((uint32_t)word >= HVE_BASE_CARDINALITY) {
            return HVE_ERR_INVALID_WORD;
        }
        indices_out[i] = word;
    }

    if (required > 0u && (state_count * 15u) % 8u != 0u) {
        unsigned used_bits = (unsigned)((state_count * 15u) % 8u);
        unsigned padding_bits = 8u - used_bits;
        uint8_t padding_mask = (uint8_t)((1u << padding_bits) - 1u);
        if ((input[required - 1u] & padding_mask) != 0u) {
            return HVE_ERR_INVALID_PADDING;
        }
    }

    *states_written = state_count;
    return HVE_OK;
}

hve_status_t hve_color_kappa(const hve_color_t *color, uint32_t *kappa_out) {
    hve_status_t status;
    uint32_t value;
    if (kappa_out == NULL) {
        return HVE_ERR_NULL;
    }
    status = hve_color_validate(color);
    if (status != HVE_OK) {
        return status;
    }
    if (color->present == 0u) {
        *kappa_out = 0u;
        return HVE_OK;
    }
    value = 1u + ((uint32_t)color->r << 16) + ((uint32_t)color->g << 8) + color->b;
    *kappa_out = value;
    return HVE_OK;
}

hve_status_t hve_color_kappa_inverse(uint32_t kappa, hve_color_t *color_out) {
    uint32_t u;
    if (color_out == NULL) {
        return HVE_ERR_NULL;
    }
    if ((uint64_t)kappa >= HVE_COLOR_POINTED_CARDINALITY) {
        return HVE_ERR_INVALID_COLOR;
    }
    if (kappa == 0u) {
        color_out->present = 0u;
        color_out->r = 0u;
        color_out->g = 0u;
        color_out->b = 0u;
        return HVE_OK;
    }
    u = kappa - 1u;
    color_out->present = 1u;
    color_out->r = (uint8_t)(u >> 16);
    color_out->g = (uint8_t)(u >> 8);
    color_out->b = (uint8_t)u;
    return HVE_OK;
}

hve_status_t hve_chi_encode(const hve_state_t *state,
                            const hve_color_t *color,
                            uint64_t *index_out) {
    uint16_t base_index;
    uint32_t kappa;
    hve_status_t status;
    if (index_out == NULL) {
        return HVE_ERR_NULL;
    }
    status = hve_base_encode(state, &base_index);
    if (status != HVE_OK) {
        return status;
    }
    status = hve_color_kappa(color, &kappa);
    if (status != HVE_OK) {
        return status;
    }
    *index_out = (uint64_t)base_index * HVE_COLOR_POINTED_CARDINALITY + (uint64_t)kappa;
    return HVE_OK;
}

hve_status_t hve_chi_decode(uint64_t index,
                            hve_state_t *state_out,
                            hve_color_t *color_out) {
    uint64_t q;
    uint64_t k;
    hve_status_t status;
    if (state_out == NULL || color_out == NULL) {
        return HVE_ERR_NULL;
    }
    if (index > HVE_CHI_MAX_INDEX) {
        return HVE_ERR_INVALID_WORD;
    }
    q = index / HVE_COLOR_POINTED_CARDINALITY;
    k = index % HVE_COLOR_POINTED_CARDINALITY;
    status = hve_base_decode((uint16_t)q, state_out);
    if (status != HVE_OK) {
        return status;
    }
    return hve_color_kappa_inverse((uint32_t)k, color_out);
}

hve_status_t hve_chi40_pack(const hve_state_t *state,
                            const hve_color_t *color,
                            uint8_t output[5]) {
    uint16_t base_index;
    uint64_t word;
    hve_status_t status;
    if (output == NULL) {
        return HVE_ERR_NULL;
    }
    status = hve_base_encode(state, &base_index);
    if (status != HVE_OK) {
        return status;
    }
    status = hve_color_validate(color);
    if (status != HVE_OK) {
        return status;
    }
    word = ((uint64_t)base_index << 25) |
           ((uint64_t)color->present << 24) |
           ((uint64_t)color->r << 16) |
           ((uint64_t)color->g << 8) |
           (uint64_t)color->b;
    output[0] = (uint8_t)(word >> 32);
    output[1] = (uint8_t)(word >> 24);
    output[2] = (uint8_t)(word >> 16);
    output[3] = (uint8_t)(word >> 8);
    output[4] = (uint8_t)word;
    return HVE_OK;
}

hve_status_t hve_chi40_unpack(const uint8_t input[5],
                              hve_state_t *state_out,
                              hve_color_t *color_out) {
    uint64_t word;
    uint16_t base_index;
    hve_status_t status;
    if (input == NULL || state_out == NULL || color_out == NULL) {
        return HVE_ERR_NULL;
    }
    word = ((uint64_t)input[0] << 32) |
           ((uint64_t)input[1] << 24) |
           ((uint64_t)input[2] << 16) |
           ((uint64_t)input[3] << 8) |
           (uint64_t)input[4];
    base_index = (uint16_t)((word >> 25) & UINT64_C(0x7FFF));
    color_out->present = (uint8_t)((word >> 24) & 1u);
    color_out->r = (uint8_t)(word >> 16);
    color_out->g = (uint8_t)(word >> 8);
    color_out->b = (uint8_t)word;
    status = hve_color_validate(color_out);
    if (status != HVE_OK) {
        return status;
    }
    return hve_base_decode(base_index, state_out);
}

hve_status_t hve_chi39_pack_index(uint64_t index, uint8_t output[5]) {
    if (output == NULL) {
        return HVE_ERR_NULL;
    }
    if (index > HVE_CHI_MAX_INDEX) {
        return HVE_ERR_INVALID_WORD;
    }
    output[0] = (uint8_t)((index >> 32) & UINT64_C(0x7F));
    output[1] = (uint8_t)(index >> 24);
    output[2] = (uint8_t)(index >> 16);
    output[3] = (uint8_t)(index >> 8);
    output[4] = (uint8_t)index;
    return HVE_OK;
}

hve_status_t hve_chi39_unpack_index(const uint8_t input[5], uint64_t *index_out) {
    uint64_t index;
    if (input == NULL || index_out == NULL) {
        return HVE_ERR_NULL;
    }
    if ((input[0] & 0x80u) != 0u) {
        return HVE_ERR_INVALID_PADDING;
    }
    index = ((uint64_t)input[0] << 32) |
            ((uint64_t)input[1] << 24) |
            ((uint64_t)input[2] << 16) |
            ((uint64_t)input[3] << 8) |
            (uint64_t)input[4];
    if (index > HVE_CHI_MAX_INDEX) {
        return HVE_ERR_INVALID_WORD;
    }
    *index_out = index;
    return HVE_OK;
}

size_t hve_frame_payload_size(uint8_t profile, uint32_t state_count) {
    if (profile == HVE_PROFILE_BASE15) {
        return hve_base15_packed_size((size_t)state_count);
    }
    if (profile == HVE_PROFILE_CHI40) {
#if SIZE_MAX < UINT32_MAX
        if (state_count > (uint32_t)(SIZE_MAX / 5u)) {
            return 0u;
        }
#endif
        return (size_t)state_count * 5u;
    }
    return 0u;
}

size_t hve_frame_total_size(uint8_t profile, uint32_t state_count) {
    size_t payload = hve_frame_payload_size(profile, state_count);
    if (state_count > 0u && payload == 0u) {
        return 0u;
    }
    if (payload > SIZE_MAX - HVE_FRAME_HEADER_SIZE) {
        return 0u;
    }
    return HVE_FRAME_HEADER_SIZE + payload;
}

uint32_t hve_crc32(const uint8_t *data, size_t size) {
    uint32_t crc = UINT32_C(0xFFFFFFFF);
    size_t i;
    if (data == NULL && size != 0u) {
        return 0u;
    }
    for (i = 0u; i < size; ++i) {
        unsigned bit;
        crc ^= data[i];
        for (bit = 0u; bit < 8u; ++bit) {
            uint32_t mask = (uint32_t)-(int32_t)(crc & 1u);
            crc = (crc >> 1) ^ (UINT32_C(0xEDB88320) & mask);
        }
    }
    return ~crc;
}

hve_status_t hve_frame_write_header(uint8_t profile,
                                    uint16_t flags,
                                    uint32_t state_count,
                                    const uint8_t *payload,
                                    size_t payload_size,
                                    uint8_t header_out[HVE_FRAME_HEADER_SIZE]) {
    size_t expected;
    uint32_t crc;
    if (header_out == NULL || (payload == NULL && payload_size != 0u)) {
        return HVE_ERR_NULL;
    }
    expected = hve_frame_payload_size(profile, state_count);
    if ((state_count > 0u && expected == 0u) || expected != payload_size) {
        return (profile == HVE_PROFILE_BASE15 || profile == HVE_PROFILE_CHI40)
                   ? HVE_ERR_RANGE
                   : HVE_ERR_UNSUPPORTED_PROFILE;
    }
    crc = hve_crc32(payload, payload_size);
    header_out[0] = HVE_FRAME_MAGIC_0;
    header_out[1] = HVE_FRAME_MAGIC_1;
    header_out[2] = HVE_FRAME_MAGIC_2;
    header_out[3] = HVE_FRAME_MAGIC_3;
    header_out[4] = (uint8_t)HVE_VERSION_MAJOR;
    header_out[5] = profile;
    put_u16_be(&header_out[6], flags);
    put_u32_be(&header_out[8], state_count);
    put_u32_be(&header_out[12], crc);
    return HVE_OK;
}

hve_status_t hve_frame_parse(const uint8_t *frame,
                             size_t frame_size,
                             hve_frame_info_t *info_out,
                             const uint8_t **payload_out) {
    uint8_t profile;
    uint32_t state_count;
    size_t payload_size;
    uint32_t stored_crc;
    uint32_t actual_crc;
    const uint8_t *payload;

    if (frame == NULL || info_out == NULL || payload_out == NULL) {
        return HVE_ERR_NULL;
    }
    if (frame_size < HVE_FRAME_HEADER_SIZE) {
        return HVE_ERR_INVALID_FRAME;
    }
    if (frame[0] != HVE_FRAME_MAGIC_0 || frame[1] != HVE_FRAME_MAGIC_1 ||
        frame[2] != HVE_FRAME_MAGIC_2 || frame[3] != HVE_FRAME_MAGIC_3) {
        return HVE_ERR_INVALID_FRAME;
    }
    if (frame[4] != HVE_VERSION_MAJOR) {
        return HVE_ERR_INVALID_FRAME;
    }
    profile = frame[5];
    state_count = get_u32_be(&frame[8]);
    payload_size = hve_frame_payload_size(profile, state_count);
    if ((state_count > 0u && payload_size == 0u) ||
        (profile != HVE_PROFILE_BASE15 && profile != HVE_PROFILE_CHI40)) {
        return HVE_ERR_UNSUPPORTED_PROFILE;
    }
    if (frame_size != HVE_FRAME_HEADER_SIZE + payload_size) {
        return HVE_ERR_INVALID_FRAME;
    }
    payload = frame + HVE_FRAME_HEADER_SIZE;
    stored_crc = get_u32_be(&frame[12]);
    actual_crc = hve_crc32(payload, payload_size);
    if (stored_crc != actual_crc) {
        return HVE_ERR_CRC_MISMATCH;
    }
    info_out->version_major = frame[4];
    info_out->profile = profile;
    info_out->flags = get_u16_be(&frame[6]);
    info_out->state_count = state_count;
    info_out->payload_size = (uint32_t)payload_size;
    *payload_out = payload;
    return HVE_OK;
}

const char *hve_status_string(hve_status_t status) {
    switch (status) {
        case HVE_OK: return "HVE_OK";
        case HVE_ERR_NULL: return "HVE_ERR_NULL";
        case HVE_ERR_RANGE: return "HVE_ERR_RANGE";
        case HVE_ERR_BUFFER_TOO_SMALL: return "HVE_ERR_BUFFER_TOO_SMALL";
        case HVE_ERR_INVALID_WORD: return "HVE_ERR_INVALID_WORD";
        case HVE_ERR_INVALID_COLOR: return "HVE_ERR_INVALID_COLOR";
        case HVE_ERR_INVALID_PADDING: return "HVE_ERR_INVALID_PADDING";
        case HVE_ERR_INVALID_FRAME: return "HVE_ERR_INVALID_FRAME";
        case HVE_ERR_CRC_MISMATCH: return "HVE_ERR_CRC_MISMATCH";
        case HVE_ERR_UNSUPPORTED_PROFILE: return "HVE_ERR_UNSUPPORTED_PROFILE";
        case HVE_ERR_OVERFLOW: return "HVE_ERR_OVERFLOW";
        default: return "HVE_ERR_UNKNOWN";
    }
}
