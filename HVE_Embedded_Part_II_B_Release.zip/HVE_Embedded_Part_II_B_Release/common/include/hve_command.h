#ifndef HVE_COMMAND_H
#define HVE_COMMAND_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Executes one command and writes one JSON object into output.
 * Returns 0 whenever a JSON response was produced, including protocol errors,
 * and -1 only when the output buffer or arguments prevent a response.
 */
int hve_command_execute(const char *line, char *output, size_t output_capacity);

#ifdef __cplusplus
}
#endif

#endif /* HVE_COMMAND_H */
