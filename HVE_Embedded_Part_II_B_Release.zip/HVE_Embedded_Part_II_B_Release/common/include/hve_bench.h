#ifndef HVE_BENCH_H
#define HVE_BENCH_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HVE_BENCH_SCHEMA_VERSION 1u
#define HVE_BENCH_MAX_BATCH 64u

typedef enum hve_bench_workload {
    HVE_BENCH_BASE_ENCODE = 0,
    HVE_BENCH_BASE_DECODE,
    HVE_BENCH_BASE_ROUNDTRIP,
    HVE_BENCH_BASE15_PACK,
    HVE_BENCH_BASE15_UNPACK,
    HVE_BENCH_CHI40_PACK,
    HVE_BENCH_CHI40_UNPACK,
    HVE_BENCH_FRAME_PARSE,
    HVE_BENCH_BASELINE17_ENCODE,
    HVE_BENCH_BASELINE17_DECODE,
    HVE_BENCH_BASELINE40_PACK,
    HVE_BENCH_BASELINE40_UNPACK,
    HVE_BENCH_WORKLOAD_COUNT
} hve_bench_workload_t;

typedef struct hve_bench_config {
    hve_bench_workload_t workload;
    uint32_t iterations;
    uint32_t batch_size;
    uint32_t seed;
    uint32_t warmup_iterations;
} hve_bench_config_t;

typedef struct hve_bench_result {
    uint64_t ticks_total;
    uint64_t operations;
    uint64_t timer_hz;
    uint64_t core_clock_hz;
    uint32_t checksum;
    uint32_t iterations;
    uint32_t batch_size;
    uint32_t seed;
    unsigned counter_bits;
    int status;
} hve_bench_result_t;

const char *hve_bench_workload_name(hve_bench_workload_t workload);
int hve_bench_workload_parse(const char *name, hve_bench_workload_t *workload_out);
int hve_bench_execute(const hve_bench_config_t *config, hve_bench_result_t *result);
int hve_bench_selftest(uint32_t *states_checked, uint32_t *reserved_checked, uint32_t *failures);
uint64_t hve_bench_counter_delta(uint64_t start, uint64_t end, unsigned bits);

#ifdef __cplusplus
}
#endif

#endif /* HVE_BENCH_H */
