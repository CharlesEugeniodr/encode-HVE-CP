#ifndef HVE_H
#define HVE_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

#define HVE_VERSION_MAJOR 1u
#define HVE_VERSION_MINOR 0u

#define HVE_THETA_CARDINALITY 360u
#define HVE_S_CARDINALITY 2u
#define HVE_TAU_CARDINALITY 5u
#define HVE_PHI_CARDINALITY 9u
#define HVE_BASE_CARDINALITY 32400u
#define HVE_BASE_WORD_BITS 15u
#define HVE_BASE_WORD_CAPACITY 32768u
#define HVE_BASE_RESERVED_WORDS 368u

#define HVE_COLOR_RGB_CARDINALITY UINT64_C(16777216)
#define HVE_COLOR_POINTED_CARDINALITY UINT64_C(16777217)
#define HVE_CHI_CARDINALITY UINT64_C(543581830800)
#define HVE_CHI_MAX_INDEX UINT64_C(543581830799)

#define HVE_FRAME_HEADER_SIZE 16u
#define HVE_FRAME_MAGIC_0 0x48u /* H */
#define HVE_FRAME_MAGIC_1 0x56u /* V */
#define HVE_FRAME_MAGIC_2 0x45u /* E */
#define HVE_FRAME_MAGIC_3 0x31u /* 1 */

#define HVE_PROFILE_BASE15 0x01u
#define HVE_PROFILE_CHI40 0x02u

typedef enum hve_status {
    HVE_OK = 0,
    HVE_ERR_NULL = -1,
    HVE_ERR_RANGE = -2,
    HVE_ERR_BUFFER_TOO_SMALL = -3,
    HVE_ERR_INVALID_WORD = -4,
    HVE_ERR_INVALID_COLOR = -5,
    HVE_ERR_INVALID_PADDING = -6,
    HVE_ERR_INVALID_FRAME = -7,
    HVE_ERR_CRC_MISMATCH = -8,
    HVE_ERR_UNSUPPORTED_PROFILE = -9,
    HVE_ERR_OVERFLOW = -10
} hve_status_t;

typedef struct hve_state {
    uint16_t theta;
    uint8_t s;
    uint8_t tau;
    uint8_t phi;
} hve_state_t;

typedef struct hve_color {
    uint8_t present; /* 0 = NoColor, 1 = RGB */
    uint8_t r;
    uint8_t g;
    uint8_t b;
} hve_color_t;

typedef struct hve_frame_info {
    uint8_t version_major;
    uint8_t profile;
    uint16_t flags;
    uint32_t state_count;
    uint32_t payload_size;
} hve_frame_info_t;

/* Validation and coordinate conversion */
hve_status_t hve_state_validate(const hve_state_t *state);
hve_status_t hve_color_validate(const hve_color_t *color);
hve_status_t hve_sigma_to_s(int sigma, uint8_t *s_out);
hve_status_t hve_s_to_sigma(uint8_t s, int *sigma_out);

/* HVE-720 BASE bijection */
hve_status_t hve_base_encode(const hve_state_t *state, uint16_t *index_out);
hve_status_t hve_base_decode(uint16_t index, hve_state_t *state_out);

/* Finite-group operations */
hve_status_t hve_group_add(const hve_state_t *a, const hve_state_t *b, hve_state_t *out);
hve_status_t hve_group_inverse(const hve_state_t *a, hve_state_t *out);

/* MSB-first stream packing of 15-bit BASE words. The caller supplies state_count. */
size_t hve_base15_packed_size(size_t state_count);
hve_status_t hve_base15_pack(const uint16_t *indices,
                             size_t state_count,
                             uint8_t *output,
                             size_t output_size,
                             size_t *bytes_written);
hve_status_t hve_base15_unpack(const uint8_t *input,
                               size_t input_size,
                               size_t state_count,
                               uint16_t *indices_out,
                               size_t indices_capacity,
                               size_t *states_written);

/* HVE-chi chromatic bijection */
hve_status_t hve_color_kappa(const hve_color_t *color, uint32_t *kappa_out);
hve_status_t hve_color_kappa_inverse(uint32_t kappa, hve_color_t *color_out);
hve_status_t hve_chi_encode(const hve_state_t *state,
                            const hve_color_t *color,
                            uint64_t *index_out);
hve_status_t hve_chi_decode(uint64_t index,
                            hve_state_t *state_out,
                            hve_color_t *color_out);

/* Aligned 40-bit profile: [BASE index:15][P:1][R:8][G:8][B:8], big-endian. */
hve_status_t hve_chi40_pack(const hve_state_t *state,
                            const hve_color_t *color,
                            uint8_t output[5]);
hve_status_t hve_chi40_unpack(const uint8_t input[5],
                              hve_state_t *state_out,
                              hve_color_t *color_out);

/* Compact 39-bit monolithic value in five bytes, big-endian; bit 39 must be zero. */
hve_status_t hve_chi39_pack_index(uint64_t index, uint8_t output[5]);
hve_status_t hve_chi39_unpack_index(const uint8_t input[5], uint64_t *index_out);

/* Deterministic framing. Header layout (16 bytes, network order):
 * 0..3 magic "HVE1"
 * 4 version major
 * 5 profile
 * 6..7 flags
 * 8..11 state_count
 * 12..15 CRC-32/ISO-HDLC of payload
 * Payload length is derived from profile and state_count.
 */
size_t hve_frame_payload_size(uint8_t profile, uint32_t state_count);
size_t hve_frame_total_size(uint8_t profile, uint32_t state_count);
uint32_t hve_crc32(const uint8_t *data, size_t size);
hve_status_t hve_frame_write_header(uint8_t profile,
                                    uint16_t flags,
                                    uint32_t state_count,
                                    const uint8_t *payload,
                                    size_t payload_size,
                                    uint8_t header_out[HVE_FRAME_HEADER_SIZE]);
hve_status_t hve_frame_parse(const uint8_t *frame,
                             size_t frame_size,
                             hve_frame_info_t *info_out,
                             const uint8_t **payload_out);

const char *hve_status_string(hve_status_t status);

#ifdef __cplusplus
}
#endif

#endif /* HVE_H */
