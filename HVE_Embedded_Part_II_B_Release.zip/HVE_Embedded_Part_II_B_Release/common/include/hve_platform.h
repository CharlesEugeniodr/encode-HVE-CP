#ifndef HVE_PLATFORM_H
#define HVE_PLATFORM_H

#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Platform timing contract.
 * counter_read() must be monotonic modulo counter_bits.
 * counter_hz() is the number of counter ticks per second.
 */
uint64_t hve_platform_counter_read(void);
uint64_t hve_platform_counter_hz(void);
unsigned hve_platform_counter_bits(void);
uint64_t hve_platform_core_clock_hz(void);

/* GPIO marker is asserted only around the measured region. */
void hve_platform_marker_set(int high);

/* Line-oriented control channel. Returns 1 on a complete line, 0 on EOF/error. */
int hve_platform_readline(char *buffer, size_t capacity);
void hve_platform_write_line(const char *line);

const char *hve_platform_target_name(void);
const char *hve_platform_board_name(void);
const char *hve_platform_toolchain(void);
const char *hve_platform_build_flags(void);
const char *hve_platform_build_id(void);

#ifdef __cplusplus
}
#endif

#endif /* HVE_PLATFORM_H */
