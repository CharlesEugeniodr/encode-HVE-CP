#ifndef HVE_BASELINE_H
#define HVE_BASELINE_H

#include <stdint.h>
#include "hve.h"

#ifdef __cplusplus
extern "C" {
#endif

/* Direct coordinate bitfield, 17 significant bits:
 * [16:8] theta, [7] s, [6:4] tau, [3:0] phi.
 * It is a fair compact fieldwise baseline because it carries the same four fields
 * without using the mixed-radix cardinality reduction of HVE BASE15.
 */
hve_status_t hve_baseline17_encode(const hve_state_t *state, uint32_t *word_out);
hve_status_t hve_baseline17_decode(uint32_t word, hve_state_t *state_out);

/* Byte-aligned fieldwise baseline, exactly 5 bytes:
 * theta big-endian (2 bytes), then s, tau, phi.
 */
hve_status_t hve_baseline40_pack(const hve_state_t *state, uint8_t output[5]);
hve_status_t hve_baseline40_unpack(const uint8_t input[5], hve_state_t *state_out);

#ifdef __cplusplus
}
#endif

#endif /* HVE_BASELINE_H */
