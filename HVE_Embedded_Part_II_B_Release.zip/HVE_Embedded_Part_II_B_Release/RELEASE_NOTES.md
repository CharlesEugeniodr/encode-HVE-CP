# Release notes — HVE Embedded Part II-B

## Purpose

This release starts the physical-evidence execution phase of HVE-720 Embedded. It does not claim MCU, FPGA or energy results that were not physically measured.

## Added

- immutable evidence-session directory structure;
- serial/host controller v2 with transcript and boot classification;
- mandatory 32,400/368/zero-failure self-test gate;
- hardware inventory and experiment lock templates;
- physical quick and 30-repetition publication plans;
- toolchain and SDK readiness probe;
- serial port inventory;
- ELF/map memory extraction;
- GCC stack-usage collection;
- FPGA simulation/synthesis driver with explicit not-executed state;
- marker-segmented energy analysis;
- physical-only article-table generator;
- RP2040 evidence build wrapper;
- physical MCU capture wrapper;
- Portuguese execution protocol and English JSA methods addendum.

## Executed in this environment

- portable C build and unit tests: passed;
- exhaustive HVE self-test: passed;
- host dry-run evidence session: complete;
- JSON schema validation and statistical pipeline: passed;
- host ELF memory and static stack extraction: passed;
- SHA-256 evidence chain: generated;
- physical toolchain audit: completed.

## Not executed

- RP2040 and STM32 cross-builds;
- physical MCU sessions;
- HDL simulation and synthesis;
- FPGA programming;
- physical power capture.

The missing ARM/FPGA toolchains and absence of connected hardware are recorded as not executed, not as HVE failures.
