# HVE Embedded Part II-B status

## Started and executed in this release

1. Traceable evidence-session controller with immutable session directories.
2. Cold-boot, warm-reset and host-dry-run classifications.
3. Mandatory self-test gate: 32,400 valid states, 368 reserved words, zero failures.
4. Hardware inventory and experiment-lock templates.
5. Physical quick plan and 30-repetition publication plan.
6. Serial port inventory and resilient serial controller.
7. Toolchain and SDK readiness audit.
8. ELF/map memory evidence and GCC static stack-usage collection.
9. FPGA simulation/synthesis evidence driver with explicit not-executed state.
10. Marker-segmented power analysis with per-segment energy output.
11. Article-table generator that refuses to populate physical tables from host data.
12. End-to-end host dry-run evidence session, dataset validation and analysis.
13. SHA-256 chain of custody for every session.

## Results of the execution available here

- Host build: passed.
- Portable C tests: passed.
- HVE self-test: 32,400 valid states, 368 reserved words, zero failures.
- Host evidence session: complete.
- JSON schema validation: passed.
- Analysis pipeline: passed.
- Memory and static stack extraction: passed for the host binary only.
- FPGA physical flow: not executed because Icarus Verilog, Yosys, nextpnr and IceStorm are absent.
- RP2040/STM32 cross-build: not executed because ARM toolchain and SDKs are absent.
- MCU and FPGA physical measurements: not executed because no hardware is connected.

## Scientific boundary

No value produced by the host dry-run is a physical MCU or FPGA result. Physical claims begin only after a declared hardware inventory, a frozen binary, a serial target capture, instrument metadata and artifact hashes exist in the same evidence session.

## Required external inputs for the next executable step

1. Exact board model/revision and serial number.
2. RP2040 Pico SDK and ARM GCC, or STM32CubeF4 and ARM GCC.
3. A connected serial port.
4. Supply voltage and clock configuration.
5. For energy: calibrated power instrument and marker capture.
6. For FPGA: Icarus/Verilator, Yosys, nextpnr-ice40, IceStorm and an iCE40UP5K board.
