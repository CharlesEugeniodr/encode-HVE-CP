#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, TextIO


class Transport:
    def write_line(self, line: str) -> None:
        raise NotImplementedError

    def read_line(self) -> str:
        raise NotImplementedError

    def close(self) -> None:
        pass


class SubprocessTransport(Transport):
    def __init__(self, executable: str, transcript: TextIO):
        self.transcript = transcript
        self.proc = subprocess.Popen(
            [executable], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, bufsize=1
        )
        if self.proc.stdin is None or self.proc.stdout is None:
            raise RuntimeError("failed to open subprocess pipes")
        self.stdin = self.proc.stdin
        self.stdout = self.proc.stdout

    def write_line(self, line: str) -> None:
        self.transcript.write(f"> {line}\n")
        self.transcript.flush()
        self.stdin.write(line + "\n")
        self.stdin.flush()

    def read_line(self) -> str:
        line = self.stdout.readline()
        if not line:
            stderr = self.proc.stderr.read() if self.proc.stderr else ""
            raise RuntimeError(f"target terminated unexpectedly: {stderr}")
        line = line.rstrip("\r\n")
        self.transcript.write(f"< {line}\n")
        self.transcript.flush()
        return line

    def close(self) -> None:
        try:
            self.write_line("QUIT")
            self.read_line()
        except Exception:
            pass
        self.proc.terminate()
        try:
            self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.proc.kill()


class SerialTransport(Transport):
    def __init__(self, port: str, baud: int, timeout: float, transcript: TextIO, toggle_dtr: bool):
        try:
            import serial  # type: ignore
        except ImportError as exc:
            raise RuntimeError("serial mode requires pyserial") from exc
        self.transcript = transcript
        self.serial = serial.Serial(port=port, baudrate=baud, timeout=timeout)
        if toggle_dtr:
            self.serial.dtr = False
            time.sleep(0.1)
            self.serial.dtr = True
            time.sleep(0.4)
        self.serial.reset_input_buffer()

    def write_line(self, line: str) -> None:
        self.transcript.write(f"> {line}\n")
        self.transcript.flush()
        self.serial.write((line + "\n").encode("ascii"))
        self.serial.flush()

    def read_line(self) -> str:
        raw = self.serial.readline()
        if not raw:
            raise TimeoutError("serial response timeout")
        line = raw.decode("utf-8", errors="strict").rstrip("\r\n")
        self.transcript.write(f"< {line}\n")
        self.transcript.flush()
        return line

    def close(self) -> None:
        self.serial.close()


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def read_json_response(transport: Transport, expected_type: str | None, retries: int) -> dict[str, Any]:
    last_line = ""
    for _ in range(retries):
        line = transport.read_line()
        last_line = line
        if not line.startswith("{"):
            continue
        obj = json.loads(line)
        if expected_type is None or obj.get("type") == expected_type:
            return obj
    raise RuntimeError(f"expected {expected_type!r}; last line={last_line!r}")


def main() -> int:
    parser = argparse.ArgumentParser(description="HVE Part II-B traceable laboratory controller")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--subprocess", dest="subprocess_path")
    mode.add_argument("--serial", dest="serial_port")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--timeout", type=float, default=20.0)
    parser.add_argument("--retries", type=int, default=40)
    parser.add_argument("--toggle-dtr", action="store_true")
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--transcript", required=True, type=Path)
    parser.add_argument("--session-id", required=True)
    parser.add_argument("--boot-class", choices=["host_dry_run", "cold_boot", "warm_reset"], required=True)
    parser.add_argument("--board-serial", default="UNDECLARED")
    parser.add_argument("--supply-voltage-v", type=float)
    parser.add_argument("--ambient-temperature-c", type=float)
    args = parser.parse_args()

    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    if not isinstance(plan.get("runs"), list) or not plan["runs"]:
        raise ValueError("plan must contain a non-empty runs array")
    if args.subprocess_path and plan.get("environment_class") != "host_harness":
        raise ValueError("host subprocess can execute only a host_harness plan")
    if args.serial_port and plan.get("environment_class") != "physical_mcu":
        raise ValueError("serial target requires a physical_mcu plan")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.transcript.parent.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []

    with args.transcript.open("w", encoding="utf-8") as transcript:
        transport: Transport
        if args.subprocess_path:
            transport = SubprocessTransport(args.subprocess_path, transcript)
        else:
            transport = SerialTransport(args.serial_port, args.baud, args.timeout, transcript, args.toggle_dtr)
        try:
            ready = read_json_response(transport, "ready", args.retries)
            transport.write_line("PING")
            pong = read_json_response(transport, "pong", args.retries)
            transport.write_line("INFO")
            info = read_json_response(transport, "info", args.retries)
            transport.write_line("SELFTEST")
            selftest = read_json_response(transport, "selftest", args.retries)
            if selftest.get("status") != "ok" or selftest.get("failures") != 0:
                raise RuntimeError(f"target self-test failed: {selftest}")
            if selftest.get("states_checked") != 32400 or selftest.get("reserved_checked") != 368:
                raise RuntimeError(f"self-test cardinality mismatch: {selftest}")

            manifest = {
                "schema_version": 1,
                "type": "capture_manifest",
                "capture_started_utc": utc_now(),
                "session_id": args.session_id,
                "boot_class": args.boot_class,
                "board_serial": args.board_serial,
                "supply_voltage_v": args.supply_voltage_v,
                "ambient_temperature_c": args.ambient_temperature_c,
                "plan_id": plan.get("plan_id", "unspecified"),
                "environment_class": plan.get("environment_class"),
                "ready": ready,
                "pong": pong,
                "info": info,
                "selftest": selftest,
            }
            args.output.with_suffix(".manifest.json").write_text(
                json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
            )

            with args.output.open("w", encoding="utf-8") as out:
                for run_index, run in enumerate(plan["runs"], start=1):
                    repetitions = int(run.get("repetitions", 1))
                    for repetition in range(1, repetitions + 1):
                        seed = int(run["seed"]) + repetition - 1
                        command = (
                            f"RUN {run['workload']} {int(run['iterations'])} "
                            f"{int(run['batch_size'])} {seed} {int(run.get('warmup', 1000))}"
                        )
                        transport.write_line(command)
                        record = read_json_response(transport, "measurement", args.retries)
                        record.update({
                            "capture_utc": utc_now(),
                            "session_id": args.session_id,
                            "boot_class": args.boot_class,
                            "board_serial": args.board_serial,
                            "supply_voltage_v": args.supply_voltage_v,
                            "ambient_temperature_c": args.ambient_temperature_c,
                            "repetition": repetition,
                            "run_index": run_index,
                            "plan_id": plan.get("plan_id", "unspecified"),
                            "environment_class": plan.get("environment_class"),
                            "controller_command": command,
                        })
                        out.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
                        out.flush()
                        records.append(record)
                        print(
                            f"{record['target']:>12} {record['workload']:<22} "
                            f"rep={repetition:02d} ticks={record['ticks_total']} status={record['status']}"
                        )
        finally:
            transport.close()

    failed = [r for r in records if r.get("status") != "ok"]
    print(f"captured {len(records)} measurements; failures={len(failed)}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
