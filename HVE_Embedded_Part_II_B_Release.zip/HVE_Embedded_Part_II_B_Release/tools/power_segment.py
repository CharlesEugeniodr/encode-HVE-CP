#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def segments(marker: np.ndarray) -> list[tuple[int, int]]:
    active = marker.astype(bool)
    starts = np.flatnonzero(active & np.r_[True, ~active[:-1]])
    ends = np.flatnonzero(active & np.r_[~active[1:], True])
    return list(zip(starts.tolist(), ends.tolist()))


def main() -> int:
    parser = argparse.ArgumentParser(description="Segment marker-gated HVE power traces")
    parser.add_argument("csv", type=Path)
    parser.add_argument("--operations-per-segment", type=int, required=True)
    parser.add_argument("--relative-uncertainty", type=float, default=0.0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.operations_per_segment <= 0:
        raise ValueError("operations-per-segment must be positive")
    df = pd.read_csv(args.csv)
    required = {"time_s", "voltage_v", "current_a", "marker"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    t = df["time_s"].to_numpy(dtype=float)
    v = df["voltage_v"].to_numpy(dtype=float)
    i = df["current_a"].to_numpy(dtype=float)
    marker = df["marker"].to_numpy(dtype=int) != 0
    if len(t) < 3 or not np.all(np.diff(t) > 0):
        raise ValueError("time_s must be strictly increasing with at least 3 samples")
    power = v * i
    inactive = ~marker
    if inactive.sum() < 2:
        raise ValueError("trace requires marker=0 baseline samples")
    baseline = float(np.median(power[inactive]))
    rows = []
    for ordinal, (start, end) in enumerate(segments(marker), start=1):
        lo = max(start - 1, 0)
        hi = min(end + 2, len(t))
        local_t = t[lo:hi]
        local_marker = marker[lo:hi]
        net_power = np.where(local_marker, power[lo:hi] - baseline, 0.0)
        energy = float(np.trapezoid(net_power, local_t))
        duration = float(t[end] - t[start]) if end > start else 0.0
        rows.append({
            "segment": ordinal,
            "start_time_s": float(t[start]),
            "end_time_s": float(t[end]),
            "duration_s": duration,
            "operations": args.operations_per_segment,
            "baseline_power_w": baseline,
            "net_energy_j": energy,
            "energy_per_operation_j": energy / args.operations_per_segment,
            "relative_uncertainty": args.relative_uncertainty,
            "absolute_energy_uncertainty_j": abs(energy * args.relative_uncertainty),
        })
    result = {
        "schema_version": 1,
        "type": "segmented_energy_measurement",
        "source_csv": str(args.csv),
        "sample_count": int(len(df)),
        "baseline_power_w": baseline,
        "segments": rows,
        "segment_count": len(rows),
        "mean_energy_per_operation_j": float(np.mean([r["energy_per_operation_j"] for r in rows])) if rows else None,
        "median_energy_per_operation_j": float(np.median([r["energy_per_operation_j"] for r in rows])) if rows else None,
        "limitation": "Instrument calibration, synchronization and systematic uncertainty remain laboratory responsibilities."
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0 if rows else 2


if __name__ == "__main__":
    raise SystemExit(main())
