#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


def bootstrap_ci(values: np.ndarray, seed: int = 720, samples: int = 10000) -> tuple[float, float]:
    if values.size == 1:
        return float(values[0]), float(values[0])
    rng = np.random.default_rng(seed)
    means = np.empty(samples, dtype=float)
    for i in range(samples):
        means[i] = rng.choice(values, size=values.size, replace=True).mean()
    low, high = np.quantile(means, [0.025, 0.975])
    return float(low), float(high)


def main() -> int:
    parser = argparse.ArgumentParser(description="Analyze HVE Part II-A raw JSONL measurements")
    parser.add_argument("dataset", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)

    records = [json.loads(line) for line in args.dataset.read_text(encoding="utf-8").splitlines() if line.strip()]
    df = pd.DataFrame(records)
    if df.empty:
        raise ValueError("empty dataset")
    df = df[df["status"] == "ok"].copy()
    if df.empty:
        raise ValueError("dataset has no successful measurements")

    df["seconds_total"] = df["ticks_total"] / df["timer_hz"]
    df["ns_per_operation"] = df["seconds_total"] * 1e9 / df["operations"]
    df["operations_per_second"] = df["operations"] / df["seconds_total"]
    df.to_csv(args.output_dir / "measurements_derived.csv", index=False)

    rows: list[dict[str, object]] = []
    group_cols = ["target", "board", "build_id", "workload", "batch_size", "environment_class"]
    for keys, group in df.groupby(group_cols, dropna=False):
        values = group["ns_per_operation"].to_numpy(dtype=float)
        ci_low, ci_high = bootstrap_ci(values)
        row = dict(zip(group_cols, keys))
        row.update({
            "samples": int(values.size),
            "mean_ns_per_operation": float(values.mean()),
            "median_ns_per_operation": float(np.median(values)),
            "stdev_ns_per_operation": float(values.std(ddof=1)) if values.size > 1 else 0.0,
            "p95_ns_per_operation": float(np.quantile(values, 0.95)),
            "p99_ns_per_operation": float(np.quantile(values, 0.99)),
            "min_ns_per_operation": float(values.min()),
            "max_ns_per_operation": float(values.max()),
            "bootstrap_mean_ci95_low": ci_low,
            "bootstrap_mean_ci95_high": ci_high,
            "mean_operations_per_second": float(group["operations_per_second"].mean()),
        })
        rows.append(row)
    summary = pd.DataFrame(rows).sort_values(["target", "workload"])
    summary.to_csv(args.output_dir / "summary.csv", index=False)
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary.to_dict(orient="records"), indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )

    for target, subset in summary.groupby("target"):
        ordered = subset.sort_values("mean_ns_per_operation")
        fig, ax = plt.subplots(figsize=(9, max(4, len(ordered) * 0.42)))
        ax.barh(ordered["workload"], ordered["mean_ns_per_operation"])
        ax.set_xlabel("Mean nanoseconds per operation")
        ax.set_ylabel("Workload")
        ax.set_title(f"HVE Part II-A timing summary - {target}")
        fig.tight_layout()
        fig.savefig(args.output_dir / f"timing_{target}.png", dpi=180)
        plt.close(fig)

    print(f"analyzed {len(df)} measurements into {len(summary)} groups")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
