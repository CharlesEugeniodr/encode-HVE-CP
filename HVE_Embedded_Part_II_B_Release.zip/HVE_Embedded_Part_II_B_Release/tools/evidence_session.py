#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import shutil
import subprocess
import sys
import uuid
from pathlib import Path


def run_logged(command: list[str], log: Path, cwd: Path) -> int:
    proc = subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=False)
    log.parent.mkdir(parents=True, exist_ok=True)
    log.write_text(
        "$ " + " ".join(command) + "\n\n--- STDOUT ---\n" + proc.stdout + "\n--- STDERR ---\n" + proc.stderr,
        encoding="utf-8"
    )
    return proc.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a complete HVE Part II-B evidence session")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--host-executable", type=Path)
    mode.add_argument("--serial-port")
    parser.add_argument("--root", type=Path, required=True, help="Part II-B release root")
    parser.add_argument("--sessions-dir", type=Path, required=True)
    parser.add_argument("--plan", type=Path, required=True)
    parser.add_argument("--schema", type=Path, required=True)
    parser.add_argument("--inventory", type=Path)
    parser.add_argument("--session-id")
    parser.add_argument("--boot-class", choices=["host_dry_run", "cold_boot", "warm_reset"], required=True)
    parser.add_argument("--board-serial", default="UNDECLARED")
    parser.add_argument("--supply-voltage-v", type=float)
    parser.add_argument("--ambient-temperature-c", type=float)
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--timeout", type=float, default=20.0)
    args = parser.parse_args()

    session_id = args.session_id or (dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8])
    session = args.sessions_dir / session_id
    if session.exists():
        raise FileExistsError(f"session already exists: {session}")
    for sub in ["raw", "logs", "analysis", "metadata", "artifacts"]:
        (session / sub).mkdir(parents=True, exist_ok=True)
    shutil.copy2(args.plan, session / "metadata" / "plan.json")
    shutil.copy2(args.schema, session / "metadata" / "measurement.schema.json")
    if args.inventory:
        shutil.copy2(args.inventory, session / "metadata" / "hardware_inventory.json")
    if args.host_executable:
        shutil.copy2(args.host_executable, session / "artifacts" / args.host_executable.name)
        host_map = args.host_executable.with_suffix(".map")
        if host_map.exists():
            shutil.copy2(host_map, session / "artifacts" / host_map.name)

    python = sys.executable
    statuses: dict[str, int] = {}
    statuses["toolchain_probe"] = run_logged(
        [python, "tools/toolchain_probe.py", "--output", str(session / "metadata" / "toolchain_probe.json")],
        session / "logs" / "toolchain_probe.log", args.root
    )
    controller = [
        python, "tools/lab_controller_v2.py",
        "--plan", str(session / "metadata" / "plan.json"),
        "--output", str(session / "raw" / "measurements.jsonl"),
        "--transcript", str(session / "raw" / "transport_transcript.txt"),
        "--session-id", session_id,
        "--boot-class", args.boot_class,
        "--board-serial", args.board_serial,
        "--timeout", str(args.timeout),
    ]
    if args.supply_voltage_v is not None:
        controller += ["--supply-voltage-v", str(args.supply_voltage_v)]
    if args.ambient_temperature_c is not None:
        controller += ["--ambient-temperature-c", str(args.ambient_temperature_c)]
    if args.host_executable:
        controller += ["--subprocess", str(args.host_executable)]
    else:
        controller += ["--serial", args.serial_port, "--baud", str(args.baud)]
    statuses["capture"] = run_logged(controller, session / "logs" / "capture.log", args.root)

    dataset = session / "raw" / "measurements.jsonl"
    if statuses["capture"] == 0 and dataset.exists():
        statuses["validate"] = run_logged(
            [python, "tools/validate_dataset.py", str(dataset), "--schema", str(session / "metadata" / "measurement.schema.json")],
            session / "logs" / "validation.log", args.root
        )
        statuses["analyze"] = run_logged(
            [python, "tools/analyze_results.py", str(dataset), "--output-dir", str(session / "analysis")],
            session / "logs" / "analysis.log", args.root
        )
    else:
        statuses["validate"] = 99
        statuses["analyze"] = 99

    prehash_complete = all(code == 0 for code in statuses.values())
    manifest = {
        "schema_version": 1,
        "type": "evidence_session",
        "session_id": session_id,
        "created_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "mode": "host_dry_run" if args.host_executable else "physical_serial",
        "boot_class": args.boot_class,
        "status": "complete" if prehash_complete else "incomplete",
        "step_returncodes": dict(statuses),
        "evidence_boundary": "Host dry-run proves pipeline integrity only. Physical claims require physical_serial mode and declared inventory."
    }
    (session / "SESSION_MANIFEST.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    statuses["hash"] = run_logged(
        [python, "tools/hash_tree.py", str(session), "--output", str(session / "SHA256_MANIFEST.json")],
        session / "logs" / "hash.log", args.root
    )
    overall = "complete" if prehash_complete and statuses["hash"] == 0 else "incomplete"
    print(json.dumps({**manifest, "status": overall, "hash_returncode": statuses["hash"]}, indent=2))
    return 0 if overall == "complete" else 1


if __name__ == "__main__":
    raise SystemExit(main())
