#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import re
import shutil
import subprocess
from pathlib import Path

SECTION_RE = re.compile(r"^(\.[A-Za-z0-9_.$-]+)\s+(\d+)\s+")


def run_size(elf: Path, tool: str) -> tuple[list[dict[str, int | str]], str]:
    proc = subprocess.run([tool, "-A", str(elf)], capture_output=True, text=True, check=False)
    if proc.returncode != 0:
        raise RuntimeError(proc.stderr or proc.stdout)
    sections = []
    for line in proc.stdout.splitlines():
        match = SECTION_RE.match(line.strip())
        if match:
            sections.append({"name": match.group(1), "bytes": int(match.group(2))})
    return sections, proc.stdout


def main() -> int:
    parser = argparse.ArgumentParser(description="Extract traceable section-size metrics from an ELF")
    parser.add_argument("--elf", type=Path, required=True)
    parser.add_argument("--size-tool", default="size")
    parser.add_argument("--map", dest="map_file", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    tool = shutil.which(args.size_tool)
    if not tool:
        raise SystemExit(f"size tool not found: {args.size_tool}")
    sections, raw = run_size(args.elf, tool)
    totals = {name: 0 for name in ["text", "rodata", "data", "bss", "other"]}
    for section in sections:
        name = str(section["name"])
        value = int(section["bytes"])
        if name.startswith(".text"):
            totals["text"] += value
        elif name.startswith(".rodata"):
            totals["rodata"] += value
        elif name.startswith(".data"):
            totals["data"] += value
        elif name.startswith(".bss"):
            totals["bss"] += value
        else:
            totals["other"] += value
    result = {
        "schema_version": 1,
        "type": "binary_memory_metrics",
        "elf": str(args.elf),
        "size_tool": tool,
        "sections": sections,
        "totals_bytes": totals,
        "flash_approx_bytes": totals["text"] + totals["rodata"] + totals["data"],
        "ram_static_approx_bytes": totals["data"] + totals["bss"],
        "map_file": str(args.map_file) if args.map_file else None,
        "map_file_present": bool(args.map_file and args.map_file.exists()),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    args.output.with_suffix(".size.txt").write_text(raw, encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
