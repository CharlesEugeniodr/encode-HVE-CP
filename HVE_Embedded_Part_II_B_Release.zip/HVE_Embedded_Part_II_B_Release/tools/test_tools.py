#!/usr/bin/env python3
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]


def run(cmd: list[str]) -> None:
    subprocess.run(cmd, check=True, cwd=ROOT)


def main() -> int:
    report = json.loads((ROOT / "data/generated/rtl_cycle_model_report.json").read_text())
    assert report["status"] == "ok"
    assert report["valid_checked"] == 32400
    assert report["reserved_checked"] == 368

    with tempfile.TemporaryDirectory() as tmp:
        tmpdir = Path(tmp)
        t = np.linspace(0.0, 0.1, 1001)
        marker = ((t >= 0.02) & (t <= 0.08)).astype(int)
        voltage = np.full_like(t, 3.3)
        current = np.where(marker, 0.020, 0.010)
        csv_path = tmpdir / "power.csv"
        pd.DataFrame({
            "time_s": t,
            "voltage_v": voltage,
            "current_a": current,
            "marker": marker,
        }).to_csv(csv_path, index=False)
        out = tmpdir / "energy.json"
        run([sys.executable, "tools/power_integrate.py", str(csv_path), "--operations", "6000", "--output", str(out)])
        result = json.loads(out.read_text())
        assert result["net_energy_j"] > 0
        assert result["energy_per_operation_j"] > 0

    print("PART II-A PYTHON TOOL TESTS PASSED")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
