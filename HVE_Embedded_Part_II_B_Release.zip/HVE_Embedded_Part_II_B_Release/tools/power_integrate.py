#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser(description="Integrate marker-gated HVE energy measurements")
    parser.add_argument("csv", type=Path, help="CSV columns: time_s, voltage_v, current_a, marker")
    parser.add_argument("--operations", type=int, required=True)
    parser.add_argument("--baseline-power-w", type=float)
    parser.add_argument("--relative-uncertainty", type=float, default=0.0)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    df = pd.read_csv(args.csv)
    required = {"time_s", "voltage_v", "current_a", "marker"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"missing columns: {sorted(missing)}")
    if args.operations <= 0:
        raise ValueError("operations must be positive")

    time_s = df["time_s"].to_numpy(dtype=float)
    power_w = (df["voltage_v"] * df["current_a"]).to_numpy(dtype=float)
    marker = df["marker"].to_numpy(dtype=int) != 0
    baseline = args.baseline_power_w
    if baseline is None:
        if (~marker).sum() < 2:
            raise ValueError("baseline requires marker=0 samples or --baseline-power-w")
        baseline = float(np.median(power_w[~marker]))

    active_power = np.where(marker, np.maximum(power_w - baseline, 0.0), 0.0)
    energy_j = float(np.trapezoid(active_power, time_s))
    duration_s = float(np.trapezoid(marker.astype(float), time_s))
    energy_per_op_j = energy_j / args.operations
    uncertainty_j = abs(energy_j * args.relative_uncertainty)

    result = {
        "schema_version": 1,
        "type": "energy_measurement",
        "source_csv": str(args.csv),
        "operations": args.operations,
        "baseline_power_w": baseline,
        "active_duration_s": duration_s,
        "net_energy_j": energy_j,
        "energy_per_operation_j": energy_per_op_j,
        "relative_uncertainty": args.relative_uncertainty,
        "absolute_energy_uncertainty_j": uncertainty_j,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
