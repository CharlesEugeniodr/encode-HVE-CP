#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def parse_su(path: Path) -> list[dict[str, object]]:
    rows = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8", errors="replace").splitlines(), start=1):
        if not line.strip():
            continue
        parts = line.split("\t")
        if len(parts) < 3:
            continue
        location, bytes_text, kind = parts[0], parts[1], parts[2]
        try:
            value = int(bytes_text)
        except ValueError:
            continue
        function = location.rsplit(":", 1)[-1]
        rows.append({"file": str(path), "line": line_no, "location": location, "function": function, "bytes": value, "kind": kind})
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Collect GCC -fstack-usage .su evidence")
    parser.add_argument("root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    records = []
    for path in sorted(args.root.rglob("*.su")):
        records.extend(parse_su(path))
    records.sort(key=lambda row: int(row["bytes"]), reverse=True)
    result = {
        "schema_version": 1,
        "type": "stack_usage_static",
        "root": str(args.root),
        "files_scanned": len(list(args.root.rglob("*.su"))),
        "records": records,
        "maximum": records[0] if records else None,
        "limitation": "Static per-function stack usage does not by itself prove the maximum call-chain stack depth.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"collected {len(records)} stack records")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
