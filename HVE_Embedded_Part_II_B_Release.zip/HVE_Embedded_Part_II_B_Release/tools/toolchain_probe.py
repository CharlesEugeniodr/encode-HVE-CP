#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import platform
import shutil
import subprocess
from pathlib import Path

TOOLS = {
    "cmake": ["cmake", "--version"],
    "gcc": ["gcc", "--version"],
    "clang": ["clang", "--version"],
    "python3": ["python3", "--version"],
    "arm_none_eabi_gcc": ["arm-none-eabi-gcc", "--version"],
    "openocd": ["openocd", "--version"],
    "picotool": ["picotool", "version"],
    "iverilog": ["iverilog", "-V"],
    "verilator": ["verilator", "--version"],
    "yosys": ["yosys", "-V"],
    "nextpnr_ice40": ["nextpnr-ice40", "--version"],
    "icepack": ["icepack", "-h"],
    "iceprog": ["iceprog", "-h"],
}


def first_line(command: list[str]) -> tuple[int, str]:
    try:
        proc = subprocess.run(command, capture_output=True, text=True, timeout=10, check=False)
    except Exception as exc:
        return 127, f"{type(exc).__name__}: {exc}"
    text = (proc.stdout + "\n" + proc.stderr).strip()
    return proc.returncode, text.splitlines()[0] if text else ""


def main() -> int:
    parser = argparse.ArgumentParser(description="Probe HVE Part II-B build and laboratory toolchains")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--strict", action="store_true", help="fail if any physical tool is missing")
    args = parser.parse_args()

    tool_data: dict[str, object] = {}
    missing: list[str] = []
    for name, command in TOOLS.items():
        executable = shutil.which(command[0])
        if executable is None:
            tool_data[name] = {"available": False, "path": None, "version": None}
            if name not in {"gcc", "clang", "python3", "cmake"}:
                missing.append(name)
            continue
        rc, version = first_line(command)
        tool_data[name] = {
            "available": True,
            "path": executable,
            "version_command_returncode": rc,
            "version": version,
        }

    pico_sdk = os.environ.get("PICO_SDK_PATH", "")
    stm32cube = os.environ.get("STM32CUBE_F4_PATH", "")
    result = {
        "schema_version": 1,
        "type": "toolchain_probe",
        "captured_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "host": {
            "platform": platform.platform(),
            "machine": platform.machine(),
            "processor": platform.processor(),
            "python": platform.python_version(),
        },
        "environment": {
            "PICO_SDK_PATH": pico_sdk or None,
            "PICO_SDK_PATH_exists": bool(pico_sdk and Path(pico_sdk).exists()),
            "STM32CUBE_F4_PATH": stm32cube or None,
            "STM32CUBE_F4_PATH_exists": bool(stm32cube and Path(stm32cube).exists()),
        },
        "tools": tool_data,
        "missing_physical_tools": missing,
        "physical_execution_ready": not missing and bool(pico_sdk) and bool(stm32cube),
        "evidence_note": "A missing tool means not executed, never a failed HVE result.",
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    return 1 if args.strict and not result["physical_execution_ready"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
