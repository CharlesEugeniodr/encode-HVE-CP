#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate article-ready HVE tables from traceable session summaries")
    parser.add_argument("summaries", nargs="+", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frames = []
    for path in args.summaries:
        if path.suffix.lower() == ".json":
            data = json.loads(path.read_text(encoding="utf-8"))
            frame = pd.DataFrame(data)
        else:
            frame = pd.read_csv(path)
        frame["source_summary"] = str(path)
        frames.append(frame)
    if not frames:
        raise ValueError("no summaries")
    df = pd.concat(frames, ignore_index=True)
    physical = df[df.get("environment_class", "") == "physical_mcu"].copy() if "environment_class" in df else df.iloc[0:0]
    df.to_csv(args.output_dir / "all_summary_rows.csv", index=False)
    physical.to_csv(args.output_dir / "physical_mcu_summary_rows.csv", index=False)
    columns = [c for c in [
        "target", "board", "build_id", "workload", "samples",
        "mean_ns_per_operation", "median_ns_per_operation", "p95_ns_per_operation",
        "bootstrap_mean_ci95_low", "bootstrap_mean_ci95_high", "mean_operations_per_second"
    ] if c in physical.columns]
    table = physical[columns].copy() if columns else physical
    table.to_csv(args.output_dir / "table_timing_physical.csv", index=False)
    md = "# HVE Part II-B publication tables\n\n"
    if physical.empty:
        md += "No physical MCU measurements were found. No timing table may be inserted into the article.\n"
    else:
        md += table.to_markdown(index=False) + "\n"
    (args.output_dir / "table_timing_physical.md").write_text(md, encoding="utf-8")
    print(f"generated tables; physical rows={len(physical)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
