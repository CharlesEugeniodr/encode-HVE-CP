#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import shutil
import subprocess
from pathlib import Path


def run(command: list[str], cwd: Path, log: Path) -> int:
    proc = subprocess.run(command, cwd=cwd, capture_output=True, text=True, check=False)
    log.write_text(proc.stdout + "\n--- STDERR ---\n" + proc.stderr, encoding="utf-8")
    return proc.returncode


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute and archive HVE FPGA simulation/synthesis when tools exist")
    parser.add_argument("--project", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--strict", action="store_true")
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    tools = {name: shutil.which(name) for name in ["make", "iverilog", "vvp", "yosys", "nextpnr-ice40", "icepack"]}
    result = {
        "schema_version": 1,
        "type": "fpga_flow",
        "captured_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "project": str(args.project),
        "tools": tools,
        "simulation": {"status": "not_executed"},
        "synthesis": {"status": "not_executed"},
    }
    if tools["make"] and tools["iverilog"] and tools["vvp"]:
        rc = run(["make", "sim"], args.project, args.output_dir / "simulation_driver.log")
        result["simulation"] = {"status": "ok" if rc == 0 else "failed", "returncode": rc}
    else:
        result["simulation"] = {"status": "not_executed", "reason": "Icarus Verilog toolchain missing"}
    if all(tools[name] for name in ["make", "yosys", "nextpnr-ice40", "icepack"]):
        rc = run(["make", "all"], args.project, args.output_dir / "synthesis_driver.log")
        result["synthesis"] = {"status": "ok" if rc == 0 else "failed", "returncode": rc}
    else:
        result["synthesis"] = {"status": "not_executed", "reason": "Yosys/nextpnr/IceStorm toolchain missing"}
    output = args.output_dir / "fpga_flow_summary.json"
    output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))
    failed = any(result[key]["status"] == "failed" for key in ["simulation", "synthesis"])
    missing = any(result[key]["status"] == "not_executed" for key in ["simulation", "synthesis"])
    return 1 if failed or (args.strict and missing) else 0


if __name__ == "__main__":
    raise SystemExit(main())
