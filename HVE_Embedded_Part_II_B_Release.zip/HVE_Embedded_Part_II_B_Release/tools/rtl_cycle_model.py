#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from pathlib import Path


def divmod_restoring(dividend: int, divisor: int, width: int = 15) -> tuple[int, int]:
    if not 0 <= dividend < (1 << width):
        raise ValueError("dividend outside width")
    quotient = 0
    remainder = 0
    for bit in range(width - 1, -1, -1):
        remainder = (remainder << 1) | ((dividend >> bit) & 1)
        quotient <<= 1
        if remainder >= divisor:
            remainder -= divisor
            quotient |= 1
    return quotient, remainder


def decode_seq_model(index: int) -> tuple[bool, tuple[int, int, int, int] | None, int]:
    if not 0 <= index < 32768:
        raise ValueError("index outside 15-bit space")
    if index >= 32400:
        return False, None, 1
    q1, phi = divmod_restoring(index, 9)
    q2, tau = divmod_restoring(q1, 5)
    s = q2 & 1
    theta = q2 >> 1
    # HDL control: launch div9 + 15 cycles + launch div5 + 15 cycles + completion.
    latency_cycles = 33
    return True, (theta, s, tau, phi), latency_cycles


def encode(theta: int, s: int, tau: int, phi: int) -> int:
    return (((theta * 2 + s) * 5 + tau) * 9 + phi)


def exhaustive_report() -> dict[str, int | str]:
    valid_checked = 0
    reserved_checked = 0
    failures = 0
    min_latency = 10**9
    max_latency = 0
    for index in range(32768):
        valid, state, latency = decode_seq_model(index)
        min_latency = min(min_latency, latency)
        max_latency = max(max_latency, latency)
        if index < 32400:
            valid_checked += 1
            if not valid or state is None or encode(*state) != index:
                failures += 1
        else:
            reserved_checked += 1
            if valid or state is not None:
                failures += 1
    return {
        "schema_version": 1,
        "type": "rtl_cycle_model_report",
        "valid_checked": valid_checked,
        "reserved_checked": reserved_checked,
        "failures": failures,
        "min_model_latency_cycles": min_latency,
        "max_model_latency_cycles": max_latency,
        "status": "ok" if failures == 0 else "failed",
        "evidence_class": "independent_python_algorithm_model_not_hdl_simulation"
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    report = exhaustive_report()
    text = json.dumps(report, indent=2) + "\n"
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    return 0 if report["status"] == "ok" else 1


if __name__ == "__main__":
    raise SystemExit(main())
