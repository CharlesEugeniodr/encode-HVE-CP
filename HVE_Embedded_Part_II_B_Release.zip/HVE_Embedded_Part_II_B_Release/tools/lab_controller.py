#!/usr/bin/env python3
from __future__ import annotations

import argparse
import datetime as dt
import json
import subprocess
import sys
import time
from pathlib import Path
from typing import Any, TextIO


class Transport:
    def write_line(self, line: str) -> None:
        raise NotImplementedError

    def read_line(self) -> str:
        raise NotImplementedError

    def close(self) -> None:
        pass


class SubprocessTransport(Transport):
    def __init__(self, executable: str):
        self.proc = subprocess.Popen(
            [executable], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, bufsize=1
        )
        if self.proc.stdin is None or self.proc.stdout is None:
            raise RuntimeError("failed to open subprocess pipes")
        self.stdin: TextIO = self.proc.stdin
        self.stdout: TextIO = self.proc.stdout

    def write_line(self, line: str) -> None:
        self.stdin.write(line + "\n")
        self.stdin.flush()

    def read_line(self) -> str:
        line = self.stdout.readline()
        if not line:
            stderr = self.proc.stderr.read() if self.proc.stderr else ""
            raise RuntimeError(f"target terminated unexpectedly: {stderr}")
        return line.strip()

    def close(self) -> None:
        try:
            self.write_line("QUIT")
            self.read_line()
        except Exception:
            pass
        self.proc.terminate()
        try:
            self.proc.wait(timeout=2)
        except subprocess.TimeoutExpired:
            self.proc.kill()


class SerialTransport(Transport):
    def __init__(self, port: str, baud: int, timeout: float):
        try:
            import serial  # type: ignore
        except ImportError as exc:
            raise RuntimeError("serial mode requires pyserial: python -m pip install pyserial") from exc
        self.serial = serial.Serial(port=port, baudrate=baud, timeout=timeout)
        self.serial.reset_input_buffer()
        time.sleep(0.25)

    def write_line(self, line: str) -> None:
        self.serial.write((line + "\n").encode("ascii"))
        self.serial.flush()

    def read_line(self) -> str:
        raw = self.serial.readline()
        if not raw:
            raise TimeoutError("serial response timeout")
        return raw.decode("utf-8", errors="strict").strip()

    def close(self) -> None:
        self.serial.close()


def read_json_response(transport: Transport, expected_type: str | None = None) -> dict[str, Any]:
    for _ in range(20):
        line = transport.read_line()
        if not line.startswith("{"):
            continue
        obj = json.loads(line)
        if expected_type is None or obj.get("type") == expected_type:
            return obj
    raise RuntimeError(f"did not receive expected response type {expected_type!r}")


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def main() -> int:
    parser = argparse.ArgumentParser(description="Execute the HVE Part II-A laboratory plan")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--subprocess", dest="subprocess_path", help="host-mock executable")
    mode.add_argument("--serial", dest="serial_port", help="serial port, e.g. COM5 or /dev/ttyACM0")
    parser.add_argument("--baud", type=int, default=115200)
    parser.add_argument("--timeout", type=float, default=15.0)
    parser.add_argument("--plan", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    plan = json.loads(args.plan.read_text(encoding="utf-8"))
    if not isinstance(plan.get("runs"), list) or not plan["runs"]:
        raise ValueError("plan must contain a non-empty runs array")

    transport: Transport
    if args.subprocess_path:
        transport = SubprocessTransport(args.subprocess_path)
    else:
        transport = SerialTransport(args.serial_port, args.baud, args.timeout)

    args.output.parent.mkdir(parents=True, exist_ok=True)
    records: list[dict[str, Any]] = []
    try:
        ready = read_json_response(transport, "ready")
        transport.write_line("INFO")
        info = read_json_response(transport, "info")
        transport.write_line("SELFTEST")
        selftest = read_json_response(transport, "selftest")
        if selftest.get("status") != "ok":
            raise RuntimeError(f"target self-test failed: {selftest}")

        manifest = {
            "capture_utc": utc_now(),
            "plan_id": plan.get("plan_id", "unspecified"),
            "environment_class": plan.get("environment_class", "host_harness"),
            "ready": ready,
            "info": info,
            "selftest": selftest,
        }
        args.output.with_suffix(".manifest.json").write_text(
            json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
        )

        with args.output.open("w", encoding="utf-8") as out:
            for run in plan["runs"]:
                repetitions = int(run.get("repetitions", 1))
                for repetition in range(1, repetitions + 1):
                    command = (
                        f"RUN {run['workload']} {int(run['iterations'])} "
                        f"{int(run['batch_size'])} {int(run['seed']) + repetition - 1} "
                        f"{int(run.get('warmup', 1000))}"
                    )
                    transport.write_line(command)
                    record = read_json_response(transport, "measurement")
                    record["capture_utc"] = utc_now()
                    record["repetition"] = repetition
                    record["plan_id"] = plan.get("plan_id", "unspecified")
                    record["environment_class"] = plan.get("environment_class", "host_harness")
                    record["controller_command"] = command
                    out.write(json.dumps(record, ensure_ascii=False, separators=(",", ":")) + "\n")
                    out.flush()
                    records.append(record)
                    print(
                        f"{record['target']:>12} {record['workload']:<22} "
                        f"rep={repetition:02d} ticks={record['ticks_total']} status={record['status']}"
                    )
    finally:
        transport.close()

    failed = [r for r in records if r.get("status") != "ok"]
    print(f"captured {len(records)} measurements; failures={len(failed)}")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
