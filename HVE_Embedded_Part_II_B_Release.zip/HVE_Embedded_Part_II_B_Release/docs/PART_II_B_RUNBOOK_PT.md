# Procedimento operacional — HVE Parte II-B

## 1. Congelar o experimento

- Copiar e preencher `lab/hardware_inventory.template.json`.
- Registrar placa, revisão, número de série, tensão, clock e GPIO marcador.
- Congelar SDK, compilador, flags, fonte e plano.
- Não alterar o binário entre cold boot, warm reset e publicação.

## 2. Auditar o ambiente

```sh
python tools/toolchain_probe.py --output evidence/toolchain_probe.json
python tools/serial_probe.py --output evidence/serial_ports.json
```

Um item ausente significa somente que a etapa não foi executada.

## 3. Compilar e arquivar

RP2040:

```sh
export PICO_SDK_PATH=/caminho/pico-sdk
./build_scripts/build_rp2040_evidence.sh
```

STM32F446RE:

- integrar os arquivos no projeto Cube;
- ativar `-fstack-usage` e mapa do linker;
- arquivar `.ioc`, ELF, BIN, MAP, `.su`, log e versão do compilador;
- executar `map_metrics.py` e `stack_usage_collect.py`.

## 4. Executar a triagem física

```sh
./build_scripts/run_physical_mcu_session.sh PORTA NUMERO_DE_SERIE cold_boot
```

A sessão é inválida quando:

- o SELFTEST não verifica 32.400 estados;
- algum dos 368 códigos reservados é aceito;
- existe falha de round-trip;
- o plano ou o binário muda durante a captura;
- não há identificação da placa.

## 5. Publicação

Após a triagem passar:

```sh
./build_scripts/run_physical_mcu_session.sh PORTA NUMERO_DE_SERIE cold_boot data/plans/physical_publication_plan_v2.json
./build_scripts/run_physical_mcu_session.sh PORTA NUMERO_DE_SERIE warm_reset data/plans/physical_publication_plan_v2.json
```

Cada sessão deve permanecer separada. Não misturar repetições de placas, clocks ou tensões diferentes.

## 6. Energia

O CSV bruto precisa conter:

- `time_s`;
- `voltage_v`;
- `current_a`;
- `marker`.

Executar:

```sh
python tools/power_segment.py trace.csv --operations-per-segment 1000000 --relative-uncertainty 0.02 --output energy.json
```

Preservar o CSV original, a calibração, a taxa de amostragem e a sincronização do GPIO.

## 7. FPGA

```sh
./build_scripts/run_fpga_evidence.sh
```

Somente publicar área, Fmax e timing quando os logs de simulação, Yosys e nextpnr existirem, estiverem associados ao mesmo bitstream e forem incluídos no manifesto SHA-256.

## 8. Inserção no artigo

```sh
python tools/generate_publication_tables.py CAMINHO/summary.json --output-dir article_tables
```

O gerador deixa a tabela física vazia quando recebe apenas dados de host. Esse comportamento é intencional.
