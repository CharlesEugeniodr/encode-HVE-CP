# HVE Part II-A FPGA track

The FPGA track now contains two distinct decoder architectures:

1. the Part I combinational reference using constant `/` and `%` operators;
2. a resource-predictable sequential decoder using restoring division by 9 and 5.

The sequential decoder takes two fixed 15-cycle division stages plus control cycles. The encoder is a three-stage pipeline and can accept one state per clock after pipeline fill.

## Physical smoke test

`hve_selftest_top.v` traverses all 32,768 15-bit words on power-up. It requires every valid word to decode and re-encode exactly and requires every reserved word to be rejected. On the iCEBreaker board, green means pass and red means failure.

## Open-source tool flow

```sh
cd fpga/icebreaker
make sim       # requires Icarus Verilog
make           # requires Yosys, nextpnr-ice40 and IceStorm
make flash     # requires iceprog and connected board
```

No simulation, synthesis, timing, area, bitstream, or power result is claimed in the packaged evidence unless the corresponding tool logs exist in the physical laboratory archive. The Python cycle model validates the algorithm independently but is not a substitute for HDL simulation or synthesis.
