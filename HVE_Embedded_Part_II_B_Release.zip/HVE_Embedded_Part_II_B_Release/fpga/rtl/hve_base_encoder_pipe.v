`timescale 1ns/1ps
`default_nettype none

// Three-stage pipelined HVE BASE encoder. Throughput is one state per cycle
// after pipeline fill; latency from valid_in to valid_out is three cycles.
module hve_base_encoder_pipe (
    input  wire        clk,
    input  wire        reset_n,
    input  wire        valid_in,
    input  wire [8:0]  theta_in,
    input  wire        s_in,
    input  wire [2:0]  tau_in,
    input  wire [3:0]  phi_in,
    output reg         valid_out,
    output reg  [14:0] index_out
);
    reg valid1;
    reg valid2;
    reg [9:0] stage1;
    reg [2:0] tau1;
    reg [3:0] phi1;
    reg [12:0] stage2;
    reg [3:0] phi2;

    always @(posedge clk) begin
        if (!reset_n) begin
            valid1 <= 1'b0;
            valid2 <= 1'b0;
            valid_out <= 1'b0;
            stage1 <= 10'd0;
            tau1 <= 3'd0;
            phi1 <= 4'd0;
            stage2 <= 13'd0;
            phi2 <= 4'd0;
            index_out <= 15'd0;
        end else begin
            // Stage 1
            valid1 <= valid_in && (theta_in < 9'd360) && (tau_in < 3'd5) && (phi_in < 4'd9);
            stage1 <= ({1'b0, theta_in} << 1) + s_in;
            tau1 <= tau_in;
            phi1 <= phi_in;

            // Stage 2
            valid2 <= valid1;
            stage2 <= stage1 * 4'd5 + tau1;
            phi2 <= phi1;

            // Stage 3 / output register
            valid_out <= valid2;
            index_out <= valid2 ? (stage2 * 5'd9 + phi2) : 15'd0;
        end
    end
endmodule

`default_nettype wire
