`timescale 1ns/1ps
`default_nettype none

// iCEBreaker physical smoke test.
// It checks all 32,400 valid indices by sequential decode + pipelined encode,
// and checks rejection of the 368 reserved indices. Green LED means pass;
// red LED means at least one failure. LEDs are active-low on the board.
module hve_selftest_top (
    input  wire CLK,
    input  wire BTN_N,
    output wire LEDR_N,
    output wire LEDG_N
);
    localparam [2:0] ST_LAUNCH_DEC = 3'd0;
    localparam [2:0] ST_WAIT_DEC   = 3'd1;
    localparam [2:0] ST_WAIT_ENC   = 3'd2;
    localparam [2:0] ST_DONE       = 3'd3;

    reg [4:0] por_counter = 5'd0;
    wire reset_n = por_counter[4] && BTN_N;
    always @(posedge CLK) begin
        if (!por_counter[4]) por_counter <= por_counter + 1'b1;
        if (!BTN_N) por_counter <= 5'd0;
    end

    reg [2:0] state = ST_LAUNCH_DEC;
    reg [14:0] index_counter = 15'd0;
    reg [15:0] failures = 16'd0;
    reg dec_start = 1'b0;
    reg enc_valid_in = 1'b0;

    wire dec_busy;
    wire dec_done;
    wire dec_valid;
    wire [8:0] dec_theta;
    wire dec_s;
    wire [2:0] dec_tau;
    wire [3:0] dec_phi;
    wire enc_valid_out;
    wire [14:0] enc_index;

    hve_base_decoder_seq decoder (
        .clk(CLK), .reset_n(reset_n), .start(dec_start), .index(index_counter),
        .busy(dec_busy), .done(dec_done), .valid(dec_valid),
        .theta(dec_theta), .s(dec_s), .tau(dec_tau), .phi(dec_phi)
    );

    hve_base_encoder_pipe encoder (
        .clk(CLK), .reset_n(reset_n), .valid_in(enc_valid_in),
        .theta_in(dec_theta), .s_in(dec_s), .tau_in(dec_tau), .phi_in(dec_phi),
        .valid_out(enc_valid_out), .index_out(enc_index)
    );

    always @(posedge CLK) begin
        if (!reset_n) begin
            state <= ST_LAUNCH_DEC;
            index_counter <= 15'd0;
            failures <= 16'd0;
            dec_start <= 1'b0;
            enc_valid_in <= 1'b0;
        end else begin
            dec_start <= 1'b0;
            enc_valid_in <= 1'b0;
            case (state)
                ST_LAUNCH_DEC: begin
                    dec_start <= 1'b1;
                    state <= ST_WAIT_DEC;
                end

                ST_WAIT_DEC: begin
                    if (dec_done) begin
                        if (index_counter < 15'd32400) begin
                            if (!dec_valid) failures <= failures + 1'b1;
                            enc_valid_in <= dec_valid;
                            state <= dec_valid ? ST_WAIT_ENC : ST_LAUNCH_DEC;
                            if (!dec_valid) begin
                                if (index_counter == 15'd32767) state <= ST_DONE;
                                else index_counter <= index_counter + 1'b1;
                            end
                        end else begin
                            if (dec_valid) failures <= failures + 1'b1;
                            if (index_counter == 15'd32767) state <= ST_DONE;
                            else begin
                                index_counter <= index_counter + 1'b1;
                                state <= ST_LAUNCH_DEC;
                            end
                        end
                    end
                end

                ST_WAIT_ENC: begin
                    if (enc_valid_out) begin
                        if (enc_index != index_counter) failures <= failures + 1'b1;
                        if (index_counter == 15'd32767) state <= ST_DONE;
                        else begin
                            index_counter <= index_counter + 1'b1;
                            state <= ST_LAUNCH_DEC;
                        end
                    end
                end

                ST_DONE: state <= ST_DONE;
                default: state <= ST_LAUNCH_DEC;
            endcase
        end
    end

    assign LEDG_N = ~((state == ST_DONE) && (failures == 16'd0));
    assign LEDR_N = ~((state == ST_DONE) && (failures != 16'd0));

    wire unused_dec_busy = dec_busy;
endmodule

`default_nettype wire
