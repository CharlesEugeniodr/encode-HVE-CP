`timescale 1ns/1ps
`default_nettype none

// Resource-predictable sequential HVE BASE decoder.
// It avoids Verilog division/modulo operators in the datapath by using two
// 15-cycle restoring divisions, first by 9 and then by 5.
module hve_base_decoder_seq (
    input  wire        clk,
    input  wire        reset_n,
    input  wire        start,
    input  wire [14:0] index,
    output reg         busy,
    output reg         done,
    output reg         valid,
    output reg  [8:0]  theta,
    output reg         s,
    output reg  [2:0]  tau,
    output reg  [3:0]  phi
);
    localparam [2:0] ST_IDLE = 3'd0;
    localparam [2:0] ST_WAIT9 = 3'd1;
    localparam [2:0] ST_LAUNCH5 = 3'd2;
    localparam [2:0] ST_WAIT5 = 3'd3;

    reg [2:0] state;
    reg start9;
    reg start5;
    reg [14:0] q1_reg;

    wire busy9;
    wire done9;
    wire [14:0] quotient9;
    wire [14:0] remainder9;
    wire busy5;
    wire done5;
    wire [14:0] quotient5;
    wire [14:0] remainder5;

    hve_divmod_const_seq #(.WIDTH(15), .DIVISOR(9)) div9 (
        .clk(clk), .reset_n(reset_n), .start(start9), .dividend(index),
        .busy(busy9), .done(done9), .quotient(quotient9), .remainder(remainder9)
    );

    hve_divmod_const_seq #(.WIDTH(15), .DIVISOR(5)) div5 (
        .clk(clk), .reset_n(reset_n), .start(start5), .dividend(q1_reg),
        .busy(busy5), .done(done5), .quotient(quotient5), .remainder(remainder5)
    );

    always @(posedge clk) begin
        if (!reset_n) begin
            state <= ST_IDLE;
            start9 <= 1'b0;
            start5 <= 1'b0;
            q1_reg <= 15'd0;
            busy <= 1'b0;
            done <= 1'b0;
            valid <= 1'b0;
            theta <= 9'd0;
            s <= 1'b0;
            tau <= 3'd0;
            phi <= 4'd0;
        end else begin
            start9 <= 1'b0;
            start5 <= 1'b0;
            done <= 1'b0;

            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        theta <= 9'd0;
                        s <= 1'b0;
                        tau <= 3'd0;
                        phi <= 4'd0;
                        if (index >= 15'd32400) begin
                            valid <= 1'b0;
                            done <= 1'b1;
                        end else begin
                            valid <= 1'b0;
                            busy <= 1'b1;
                            start9 <= 1'b1;
                            state <= ST_WAIT9;
                        end
                    end
                end

                ST_WAIT9: begin
                    busy <= 1'b1;
                    if (done9) begin
                        q1_reg <= quotient9;
                        phi <= remainder9[3:0];
                        state <= ST_LAUNCH5;
                    end
                end

                ST_LAUNCH5: begin
                    busy <= 1'b1;
                    start5 <= 1'b1;
                    state <= ST_WAIT5;
                end

                ST_WAIT5: begin
                    busy <= 1'b1;
                    if (done5) begin
                        tau <= remainder5[2:0];
                        s <= quotient5[0];
                        theta <= quotient5[9:1];
                        valid <= 1'b1;
                        busy <= 1'b0;
                        done <= 1'b1;
                        state <= ST_IDLE;
                    end
                end

                default: state <= ST_IDLE;
            endcase
        end
    end

    wire unused_busy = busy9 ^ busy5;
endmodule

`default_nettype wire
