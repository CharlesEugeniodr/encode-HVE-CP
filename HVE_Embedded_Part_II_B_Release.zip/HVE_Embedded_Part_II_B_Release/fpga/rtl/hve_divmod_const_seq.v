`timescale 1ns/1ps
`default_nettype none

// Fixed-width restoring divider for a compile-time constant divisor.
// One result is produced after WIDTH busy cycles. Start is accepted only when idle.
module hve_divmod_const_seq #(
    parameter integer WIDTH = 15,
    parameter integer DIVISOR = 9
) (
    input  wire                 clk,
    input  wire                 reset_n,
    input  wire                 start,
    input  wire [WIDTH-1:0]     dividend,
    output reg                  busy,
    output reg                  done,
    output reg  [WIDTH-1:0]     quotient,
    output reg  [WIDTH-1:0]     remainder
);
    reg [WIDTH-1:0] dividend_shift;
    reg [WIDTH-1:0] quotient_work;
    reg [WIDTH:0]   remainder_work;
    reg [5:0]       count;

    wire [WIDTH:0] remainder_shift;
    wire           subtract_divisor;
    wire [WIDTH:0] remainder_next;
    wire [WIDTH-1:0] quotient_next;

    assign remainder_shift = {remainder_work[WIDTH-1:0], dividend_shift[WIDTH-1]};
    assign subtract_divisor = (remainder_shift >= DIVISOR);
    assign remainder_next = subtract_divisor ? (remainder_shift - DIVISOR) : remainder_shift;
    assign quotient_next = {quotient_work[WIDTH-2:0], subtract_divisor};

    always @(posedge clk) begin
        if (!reset_n) begin
            busy <= 1'b0;
            done <= 1'b0;
            quotient <= {WIDTH{1'b0}};
            remainder <= {WIDTH{1'b0}};
            dividend_shift <= {WIDTH{1'b0}};
            quotient_work <= {WIDTH{1'b0}};
            remainder_work <= {(WIDTH+1){1'b0}};
            count <= 6'd0;
        end else begin
            done <= 1'b0;
            if (start && !busy) begin
                busy <= 1'b1;
                dividend_shift <= dividend;
                quotient_work <= {WIDTH{1'b0}};
                remainder_work <= {(WIDTH+1){1'b0}};
                count <= WIDTH;
            end else if (busy) begin
                dividend_shift <= {dividend_shift[WIDTH-2:0], 1'b0};
                quotient_work <= quotient_next;
                remainder_work <= remainder_next;
                if (count == 6'd1) begin
                    quotient <= quotient_next;
                    remainder <= remainder_next[WIDTH-1:0];
                    busy <= 1'b0;
                    done <= 1'b1;
                    count <= 6'd0;
                end else begin
                    count <= count - 1'b1;
                end
            end
        end
    end
endmodule

`default_nettype wire
