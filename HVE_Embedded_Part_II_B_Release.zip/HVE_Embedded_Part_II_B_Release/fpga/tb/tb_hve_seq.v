`timescale 1ns/1ps
`default_nettype none

module tb_hve_seq;
    reg clk = 1'b0;
    reg reset_n = 1'b0;
    reg start = 1'b0;
    reg [14:0] index = 15'd0;
    wire busy;
    wire done;
    wire valid;
    wire [8:0] theta;
    wire s;
    wire [2:0] tau;
    wire [3:0] phi;

    reg enc_valid_in = 1'b0;
    wire enc_valid_out;
    wire [14:0] enc_index;

    integer i;
    integer failures = 0;

    always #5 clk = ~clk;

    hve_base_decoder_seq decoder (
        .clk(clk), .reset_n(reset_n), .start(start), .index(index),
        .busy(busy), .done(done), .valid(valid),
        .theta(theta), .s(s), .tau(tau), .phi(phi)
    );

    hve_base_encoder_pipe encoder (
        .clk(clk), .reset_n(reset_n), .valid_in(enc_valid_in),
        .theta_in(theta), .s_in(s), .tau_in(tau), .phi_in(phi),
        .valid_out(enc_valid_out), .index_out(enc_index)
    );

    task launch_decode;
        input [14:0] value;
        begin
            @(posedge clk);
            index <= value;
            start <= 1'b1;
            @(posedge clk);
            start <= 1'b0;
            while (!done) @(posedge clk);
        end
    endtask

    initial begin
        repeat (4) @(posedge clk);
        reset_n <= 1'b1;

        for (i = 0; i < 32768; i = i + 1) begin
            launch_decode(i[14:0]);
            if (i < 32400) begin
                if (!valid) begin
                    $display("FAIL valid index rejected %0d", i);
                    failures = failures + 1;
                end else begin
                    @(posedge clk);
                    enc_valid_in <= 1'b1;
                    @(posedge clk);
                    enc_valid_in <= 1'b0;
                    while (!enc_valid_out) @(posedge clk);
                    if (enc_index !== i[14:0]) begin
                        $display("FAIL roundtrip %0d -> %0d", i, enc_index);
                        failures = failures + 1;
                    end
                end
            end else if (valid) begin
                $display("FAIL reserved index accepted %0d", i);
                failures = failures + 1;
            end
        end

        if (failures == 0) $display("ALL SEQUENTIAL RTL TESTS PASSED");
        else $display("SEQUENTIAL RTL FAILURES=%0d", failures);
        $finish;
    end
endmodule

`default_nettype wire
