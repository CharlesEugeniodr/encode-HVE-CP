# HVE profile consolidation

## 1. Canonical relationship

The supplied project material describes several layers.  They are compatible
when their cardinalities and semantics are kept explicit:

| Profile | Product | Cardinality | Engine role |
| --- | ---: | ---: | --- |
| HVE-720 | `360 * 2` | 720 | theta/sigma layer |
| HVE-6480 | `360 * 2 * 9` | 6,480 | HVE-720 plus nine phi planes |
| HVE-6480+tau | `360 * 2 * 9 * 5` | 32,400 | complete BASE core |
| HVE-Lang v1.1 legacy | `360 * 2 * 5 * 5` | 18,000 | subset with five nonnegative phi levels |
| HVE-128 EFQ semantic payload | `360 * 1000 * 2 * 3600 * 112 * 2^24` | exact product | high-resolution payload inside a 128-bit envelope |
| HVE-Zeta Sigma-0 | assigned region | 137,000 | concept IDs injected into HVE-128 `(micro,tau)` |

The HVE-6480+tau CSV enumerates the BASE states in document order:

`index = phi * 3600 + tau * 720 + s * 360 + theta`.

The CSV order is exhaustive and bijective over all 32,400 states.

## 2. Semantic orders

The supplied 32,400-row CSV fixes the following orders:

- tau: `0, +15, -15, +30, -30` degrees;
- phi: `base, +15, +30, +45, +60, -15, -30, -45, -60` degrees;
- sigma: `+1, -1`;
- theta varies fastest from `0` through `359`.

The engine retains its older wire order for backward compatibility and exposes
an exhaustive crosswalk to this document order.

## 3. Legacy 18,000-state migration

The uploaded HVE-Lang v1.1 CSV is a wrapped semicolon table.  Its actual state
space is:

`theta in 0..359`, `sigma in {+1,-1}`, `tau in {-2,-1,0,1,2}`,
`phi in {0,1,2,3,4}`.

The migration interprets each tau level as 15 degrees and each phi level as a
nonnegative 15-degree plane:

- tau `-2,-1,0,1,2` -> `-30,-15,0,+15,+30`;
- phi `0,1,2,3,4` -> `base,+15,+30,+45,+60`.

This gives an injective 18,000-state subset of HVE-32,400.  The 14,400 new
states are the four negative phi planes across the same 3,600 theta/sigma/tau
states.

The legacy metric columns are retained only as source metadata.  If
`Bits_Angular` is interpreted as the minimum state index width, 18,000 states
need 15 bits, not 70.  The declared `Bits_Total_Minimo=40.34` is also smaller
than the declared 41-bit color field, and 25 bytes equals 200 bits rather than
the declared `70+41=111` bits.  Those values require a separate framing or
coding specification before they can become normative.

## 4. HVE-128 EFQ correction

The primary source lists:

- mode: 3 bits;
- reserved A: 5;
- theta: 9;
- micro: 10;
- sigma: 1;
- tau: 12;
- direction: 7;
- RGB: 24;
- extra: 32;
- reserved B: 24.

These declared widths sum to 127, not 128.  The source also labels the
seven-bit direction field as bits 87..80, an eight-bit inclusive interval.  Its
reference code masks seven bits at shift 80, so direction actually occupies
bits 86..80 and bit 87 is unused.  Engine 1.2 names bit 87 `reserved_c` and
requires it to be zero in the strict v1 profile.  This preserves existing
source-code packing while making all 128 positions explicit.

The semantic field product is:

`N = 360 * 1000 * 2 * 3600 * 112 * 2^24`.

Its entropy satisfies `62 < log2(N) < 63`; therefore the semantic payload needs
63 bits in a minimum fixed-width word.  The 128-bit token is an envelope that
also carries mode, metadata, and reserved expansion space.  These are distinct
claims and are reported separately.

## 5. HVE-Zeta boundary

The supplied note states that 137,000 concepts were mapped injectively into
`(delta-theta,tau)` at `theta=0`, but it does not include the referenced
`hve_toolkit_128.py` or its tests.  Engine 1.2 therefore defines its own named
mapping:

`zeta-sigma0/micro-fast/engine-v1`.

For concept index `i`:

`micro = i mod 1000`, `tau = floor(i / 1000)`.

The inverse is `i = 1000 * tau + micro`.  The assigned region uses 137 tau rows
out of the available 3,600 and is exhaustively tested for all 137,000 IDs.
This proves the new engine mapping.  It does not assert binary compatibility
with the absent historical toolkit.

## 6. Visual boundary

The supplied radial numeral-zero image is a useful visualization of layered
angular rays.  The image alone is not evidence of fractality: no iterative
similarity rule, scaling law, or fractal dimension is defined in the artifact.
It is retained as conceptual visualization, not as a normative state table or
mathematical proof.
