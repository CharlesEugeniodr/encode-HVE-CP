# C reference core

This directory preserves the portable C11 implementation of the validated BASE,
chromatic, serialization, and framing core. The Python package is the canonical
experimentation and profile layer in version 1.2. No C
harmonic-performance claim is made in this release.
