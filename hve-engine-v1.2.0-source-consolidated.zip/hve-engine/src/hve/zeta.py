"""HVE-Zeta Sigma-0 injection into the HVE-128 (micro, tau) subspace.

The uploaded note states the capacity and the target subspace but does not
include the referenced ``hve_toolkit_128.py`` implementation.  This module
therefore defines an explicit, versioned engine mapping instead of claiming
byte compatibility with unavailable code.
"""

from __future__ import annotations

from dataclasses import dataclass

from .core import HVEError
from .efq128 import HVE128Fields, MODE_HVE128, pack_efq128, unpack_efq128

ZETA_SYMBOLS = 137_000
ZETA_MICRO_CARDINALITY = 1_000
ZETA_TAU_CARDINALITY = 3_600
ZETA_SUBSPACE_CARDINALITY = ZETA_MICRO_CARDINALITY * ZETA_TAU_CARDINALITY
ZETA_TAU_ROWS_USED = (ZETA_SYMBOLS + ZETA_MICRO_CARDINALITY - 1) // ZETA_MICRO_CARDINALITY
ZETA_EXTRA_TAG = 0x5A455441  # ASCII "ZETA"
ZETA_PROFILE = "zeta-sigma0/micro-fast/engine-v1"


@dataclass(frozen=True, slots=True)
class ZetaCoordinate:
    micro: int
    tau: int


def zeta_coordinate(symbol_index: int) -> ZetaCoordinate:
    if not isinstance(symbol_index, int) or isinstance(symbol_index, bool):
        raise HVEError("Zeta symbol index must be an integer")
    if not 0 <= symbol_index < ZETA_SYMBOLS:
        raise HVEError(f"Zeta symbol index must be in [0, {ZETA_SYMBOLS - 1}]")
    return ZetaCoordinate(
        micro=symbol_index % ZETA_MICRO_CARDINALITY,
        tau=symbol_index // ZETA_MICRO_CARDINALITY,
    )


def zeta_symbol_index(coordinate: ZetaCoordinate) -> int:
    if not isinstance(coordinate, ZetaCoordinate):
        raise HVEError("coordinate must be a ZetaCoordinate")
    if not 0 <= coordinate.micro < ZETA_MICRO_CARDINALITY:
        raise HVEError("Zeta micro coordinate must be in [0, 999]")
    if not 0 <= coordinate.tau < ZETA_TAU_CARDINALITY:
        raise HVEError("Zeta tau coordinate must be in [0, 3599]")
    index = coordinate.tau * ZETA_MICRO_CARDINALITY + coordinate.micro
    if index >= ZETA_SYMBOLS:
        raise HVEError("coordinate is outside the assigned 137,000-symbol Zeta region")
    return index


def encode_zeta(symbol_index: int) -> HVE128Fields:
    coordinate = zeta_coordinate(symbol_index)
    return HVE128Fields(
        mode=MODE_HVE128,
        theta=0,
        micro=coordinate.micro,
        sigma=0,
        tau=coordinate.tau,
        direction=0,
        rgb=0,
        extra=ZETA_EXTRA_TAG,
    )


def decode_zeta(fields: HVE128Fields) -> int:
    if not isinstance(fields, HVE128Fields):
        raise HVEError("fields must be HVE128Fields")
    fields.validate(strict_profile=True)
    expected_fixed = (
        fields.mode == MODE_HVE128
        and fields.theta == 0
        and fields.sigma == 0
        and fields.direction == 0
        and fields.rgb == 0
        and fields.extra == ZETA_EXTRA_TAG
        and fields.reserved_a == 0
        and fields.reserved_c == 0
        and fields.reserved_b == 0
    )
    if not expected_fixed:
        raise HVEError("token is not canonical HVE-Zeta Sigma-0 engine-v1")
    return zeta_symbol_index(ZetaCoordinate(fields.micro, fields.tau))


def pack_zeta(symbol_index: int) -> int:
    return pack_efq128(encode_zeta(symbol_index))


def unpack_zeta(value: int) -> int:
    return decode_zeta(unpack_efq128(value))


assert ZETA_SYMBOLS <= ZETA_SUBSPACE_CARDINALITY
assert ZETA_TAU_ROWS_USED == 137
