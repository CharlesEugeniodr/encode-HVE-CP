"""Motor Matplotlib para o Modelo de Equivalencia Reversivel de Ordem 16.

Gera um painel tecnico com:

1. simetria real ``z ~ -z``;
2. seletividade comparada das potencias pares;
3. funcao inversa canonica;
4. comportamento em escala logaritmica;
5. equivalencia vetorial ``v ~ -v``;
6. erro numerico de ida e volta.

Uso:

    python equivalence_matplotlib.py --n 3 --output equivalence_dashboard.png
"""

from __future__ import annotations

import argparse
import math
from pathlib import Path
from typing import Iterable

import matplotlib

if not matplotlib.get_backend().lower().startswith(("agg", "module://")):
    # O painel continua compativel com ambientes sem interface grafica.
    try:
        matplotlib.use("Agg")
    except ImportError:
        pass

import matplotlib.pyplot as plt
import numpy as np

from equivalence_engine import EquivalenceEngine, GOLDEN_RATIO, MODEL_POWER


class EquivalencePlotter:
    """Construtor de visualizacoes tecnicas para o motor de equivalencia."""

    def __init__(self, engine: EquivalenceEngine) -> None:
        self.engine = engine

    @staticmethod
    def _style_axis(axis: plt.Axes) -> None:
        axis.grid(True, which="both", alpha=0.23, linewidth=0.7)
        axis.spines[["top", "right"]].set_visible(False)

    def plot_scalar_symmetry(self, axis: plt.Axes) -> None:
        z = np.linspace(-1.08, 1.08, 1401)
        y = self.engine.scale * np.abs(z) ** MODEL_POWER
        axis.plot(z, y, color="#4c2a85", linewidth=2.4)
        sample = 0.82
        sample_y = self.engine.encode_scalar(sample)
        axis.scatter(
            [-sample, sample],
            [sample_y, sample_y],
            s=54,
            color=["#dd4968", "#238a8d"],
            zorder=4,
        )
        axis.annotate(
            r"$F(-z)=F(z)$",
            xy=(sample, sample_y),
            xytext=(0.18, 0.70 * self.engine.scale),
            arrowprops={"arrowstyle": "->", "color": "#333333"},
            fontsize=10,
        )
        axis.set_title("1. Simetria real e classe [z]")
        axis.set_xlabel("representante z")
        axis.set_ylabel(r"$Y=A_n z^{16}$")
        self._style_axis(axis)

    def plot_selectivity(self, axis: plt.Axes) -> None:
        z = np.linspace(0.0, 1.0, 1001)
        palette = {2: "#90be6d", 4: "#43aa8b", 8: "#277da1", 16: "#4c2a85"}
        for power in (2, 4, 8, 16):
            axis.plot(
                z,
                z**power,
                label=rf"$z^{{{power}}}$",
                color=palette[power],
                linewidth=2.5 if power == 16 else 1.5,
            )
        axis.set_title("2. Seletividade nao linear")
        axis.set_xlabel("magnitude normalizada Z")
        axis.set_ylabel("resposta normalizada")
        axis.legend(frameon=False, ncols=2)
        self._style_axis(axis)

    def plot_inverse(self, axis: plt.Axes) -> None:
        y = np.linspace(0.0, self.engine.scale, 1001)
        z = np.array([self.engine.decode_scalar(value) for value in y])
        axis.plot(y, z, color="#238a8d", linewidth=2.4)
        axis.set_title("3. Reversao canonica unica")
        axis.set_xlabel(r"$Y \in [0,A_n]$")
        axis.set_ylabel(r"$Z=(Y/A_n)^{1/16}$")
        axis.text(
            0.04,
            0.90,
            r"saida: $Z=|z|\geq 0$",
            transform=axis.transAxes,
            bbox={"boxstyle": "round,pad=0.35", "fc": "white", "ec": "#238a8d"},
        )
        self._style_axis(axis)

    def plot_log_domain(self, axis: plt.Axes) -> None:
        log10_z = np.linspace(-24.0, 2.0, 1200)
        log10_y = math.log10(self.engine.scale) + MODEL_POWER * log10_z
        axis.plot(log10_z, log10_y, color="#f9844a", linewidth=2.4)
        axis.axhline(-308.0, color="#777777", linestyle="--", linewidth=1.2)
        axis.text(
            -23.5,
            -301.0,
            "ordem da faixa normal float64",
            fontsize=8.5,
            color="#555555",
        )
        axis.set_title("4. Calculo sem cortes no dominio log")
        axis.set_xlabel(r"$\log_{10} Z$")
        axis.set_ylabel(r"$\log_{10} Y$")
        self._style_axis(axis)

    def plot_vector_equivalence(self, axis: plt.Axes) -> None:
        vector = np.array([0.82, 0.54], dtype=float)
        opposite = -vector
        matrix_a = self.engine.encode_vector(vector)
        matrix_b = self.engine.encode_vector(opposite)
        difference = float(np.linalg.norm(matrix_a - matrix_b, ord="fro"))

        axis.axhline(0.0, color="#b8b8b8", linewidth=0.8)
        axis.axvline(0.0, color="#b8b8b8", linewidth=0.8)
        axis.plot(
            [-vector[0], vector[0]],
            [-vector[1], vector[1]],
            color="#4c2a85",
            linewidth=2.0,
            alpha=0.55,
        )
        axis.quiver(
            0,
            0,
            vector[0],
            vector[1],
            angles="xy",
            scale_units="xy",
            scale=1,
            color="#238a8d",
            width=0.018,
            label=r"$\mathbf{v}$",
        )
        axis.quiver(
            0,
            0,
            opposite[0],
            opposite[1],
            angles="xy",
            scale_units="xy",
            scale=1,
            color="#dd4968",
            width=0.018,
            label=r"$-\mathbf{v}$",
        )
        axis.text(
            0.04,
            0.92,
            rf"$\|M(v)-M(-v)\|_F={difference:.1e}$",
            transform=axis.transAxes,
            bbox={"boxstyle": "round,pad=0.35", "fc": "white", "ec": "#4c2a85"},
        )
        axis.set_xlim(-1.1, 1.1)
        axis.set_ylim(-1.1, 1.1)
        axis.set_aspect("equal", adjustable="box")
        axis.set_title("5. Extensao vetorial completa")
        axis.set_xlabel("componente 1")
        axis.set_ylabel("componente 2")
        axis.legend(frameon=False, loc="lower right")
        self._style_axis(axis)

    def plot_round_trip_error(self, axis: plt.Axes) -> None:
        z = np.logspace(-18.0, 1.0, 800)
        y = self.engine.scale * z**MODEL_POWER
        recovered = (y / self.engine.scale) ** (1.0 / MODEL_POWER)
        relative_error = np.abs(recovered - z) / z
        display_error = np.maximum(relative_error, np.finfo(float).eps / 10.0)
        axis.loglog(z, display_error, color="#577590", linewidth=1.9)
        axis.axhline(
            np.finfo(float).eps,
            color="#f94144",
            linestyle="--",
            linewidth=1.1,
            label="epsilon float64",
        )
        axis.set_title("6. Precisao da ida e volta")
        axis.set_xlabel("magnitude Z")
        axis.set_ylabel("erro relativo")
        axis.legend(frameon=False)
        self._style_axis(axis)

    def dashboard(
        self,
        *,
        figsize: tuple[float, float] = (15.5, 11.2),
    ) -> plt.Figure:
        """Monta o painel tecnico completo e retorna a figura."""

        figure, axes = plt.subplots(2, 3, figsize=figsize, constrained_layout=True)
        self.plot_scalar_symmetry(axes[0, 0])
        self.plot_selectivity(axes[0, 1])
        self.plot_inverse(axes[0, 2])
        self.plot_log_domain(axes[1, 0])
        self.plot_vector_equivalence(axes[1, 1])
        self.plot_round_trip_error(axes[1, 2])
        figure.suptitle(
            "Motor de Equivalencia Reversivel de Ordem 16\n"
            + rf"$Y=\Phi\sqrt{{n/3}}\,z^{{16}}$   |   "
            + rf"$n={self.engine.n:g}$   |   $A_n={self.engine.scale:.8g}$",
            fontsize=17,
            fontweight="bold",
        )
        return figure

    def save_dashboard(
        self,
        output: str | Path,
        *,
        dpi: int = 180,
        transparent: bool = False,
    ) -> Path:
        """Gera e salva o painel completo."""

        destination = Path(output).expanduser().resolve()
        destination.parent.mkdir(parents=True, exist_ok=True)
        figure = self.dashboard()
        figure.savefig(
            destination,
            dpi=dpi,
            bbox_inches="tight",
            facecolor="white",
            transparent=transparent,
        )
        plt.close(figure)
        return destination


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Gera o painel Matplotlib do modelo de equivalencia de ordem 16."
    )
    parser.add_argument("--n", type=float, default=3.0)
    parser.add_argument("--phi", type=float, default=GOLDEN_RATIO)
    parser.add_argument(
        "--output",
        default="equivalence_dashboard.png",
        help="Caminho do PNG ou PDF de saida.",
    )
    parser.add_argument("--dpi", type=int, default=180)
    parser.add_argument("--show", action="store_true")
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    arguments = _build_parser().parse_args(argv)
    engine = EquivalenceEngine(n=arguments.n, phi=arguments.phi)
    plotter = EquivalencePlotter(engine)
    destination = plotter.save_dashboard(arguments.output, dpi=arguments.dpi)
    print(destination)
    if arguments.show:
        image = plt.imread(destination)
        plt.figure(figsize=(15.5, 11.2))
        plt.imshow(image)
        plt.axis("off")
        plt.show()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
