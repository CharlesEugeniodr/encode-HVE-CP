# Motor de Equivalencia Reversivel de Ordem 16

Implementacao de referencia do modelo

\[
Y=\Phi\sqrt{\frac n3}\left(z^1z^3z^5z^7\right)
 =\Phi\sqrt{\frac n3}\,z^{16},
\qquad
\Phi=\frac{1+\sqrt5}{2}.
\]

O motor trata `z` e `-z` como representantes da mesma classe. A reversao real
devolve o representante canonico nao negativo:

\[
Z=\left(\frac{Y}{\Phi\sqrt{n/3}}\right)^{1/16}=|z|.
\]

Nao sao usados limites artificiais, `clamp` ou epsilon matematico. Para valores
fora da faixa direta do `float64`, o motor oferece aritmetica `Decimal` e
representacao logaritmica.

## Arquivos

- `equivalence_engine.py`: motor matematico escalar, vetorial, complexo,
  decimal e logaritmico.
- `equivalence_matplotlib.py`: motor visual e gerador do painel tecnico.
- `test_equivalence_engine.py`: testes automatizados com `unittest`.
- `example_usage.py`: demonstracao executavel.
- `requirements.txt`: dependencias externas.

## Instalacao

```bash
python -m pip install -r requirements.txt
```

## Uso escalar

```python
from equivalence_engine import EquivalenceEngine

engine = EquivalenceEngine(n=3)
y = engine.encode_scalar(-0.92)
z = engine.decode_scalar(y)

assert z == 0.92
```

Pela linha de comando:

```bash
python equivalence_engine.py --n 3 scalar -0.92
```

## Uso vetorial

A extensao vetorial e

\[
M(\mathbf v)=A_n\|\mathbf v\|^{14}\mathbf v\mathbf v^T,
\qquad
A_n=\Phi\sqrt{n/3}.
\]

Ela preserva a magnitude e o eixo da classe
`[v] = {v, -v}`. O autovalor principal e `A_n ||v||^16`; o autovetor principal
recupera a direcao ate o sinal.

```python
import numpy as np
from equivalence_engine import EquivalenceEngine

engine = EquivalenceEngine(n=7)
v = np.array([1.0, -2.0, 3.0])
matrix = engine.encode_vector(v)
result = engine.decode_vector(matrix)

print(result.canonical_vector)
print(result.relative_residual)
```

Pela linha de comando:

```bash
python equivalence_engine.py --n 7 vector 1 -2 3
```

## Reversao complexa

No dominio complexo, `z^16` identifica a orbita

\[
z\sim ze^{2\pi ik/16},\qquad k=0,\ldots,15.
\]

```python
engine = EquivalenceEngine(n=15)
y = engine.encode_complex(1.2 - 0.7j)
roots = engine.decode_complex_roots(y)
assert len(roots) == 16
```

## Precisao sem delimitacao artificial

### Dominio logaritmico

```python
log_y = engine.encode_log(1e-200)
log_z = engine.decode_log_magnitude(log_y)
```

### Decimal

```python
from decimal import Decimal

y = engine.encode_scalar_decimal(Decimal("1e-1000"), precision=120)
z = engine.decode_scalar_decimal(y, precision=120)
```

## Motor Matplotlib

```bash
python equivalence_matplotlib.py \
  --n 3 \
  --output equivalence_dashboard.png \
  --dpi 180
```

Ou por API:

```python
from equivalence_engine import EquivalenceEngine
from equivalence_matplotlib import EquivalencePlotter

engine = EquivalenceEngine(n=3)
EquivalencePlotter(engine).save_dashboard("painel.png")
```

## Testes

```bash
python -m unittest -v test_equivalence_engine.py
```

Os testes cobrem:

- identidade `1 + 3 + 5 + 7 = 16`;
- invariancia real por sinal;
- ida e volta escalar;
- operacao Decimal em magnitudes extremas;
- 16 ramos complexos;
- equivalencia vetorial;
- reconstrucao por autodecomposicao;
- rejeicao de matrizes invalidas.

## Limites cientificos

- A prova de reversibilidade ocorre no espaco de equivalencia, nao recupera um
  sinal que tenha sido declarado irrelevante.
- O fator `Phi * sqrt(n/3)` e uma escala positiva. Sua adequacao fisica ou
  estatistica depende da definicao externa de `n` e precisa ser validada pela
  aplicacao.
- Para simples eliminacao de sinal, a potencia 2 ja seria suficiente. A ordem
  16 acrescenta seletividade extrema: suprime `|z| < 1` e expande `|z| > 1`.
- A matriz vetorial deve ser simetrica, positiva semidefinida e de posto zero
  ou um para possuir reversao valida por este modelo.
