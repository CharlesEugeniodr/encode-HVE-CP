"""Motor de Equivalencia Reversivel de Ordem 16.

Modelo escalar
--------------

    Y = Phi * sqrt(n / 3) * (z^1 z^3 z^5 z^7)
      = Phi * sqrt(n / 3) * z^16

No dominio real, ``z`` e ``-z`` pertencem a mesma classe de equivalencia.
O decodificador devolve o representante canonico nao negativo ``|z|``.

Extensao vetorial
-----------------

    M(v) = A_n * ||v||^14 * v v^T
         = A_n * ||v||^16 * u u^T,

onde ``u = v / ||v||``. A matriz e invariante por ``v -> -v`` e sua
autodecomposicao recupera exatamente a classe ``[v] = {v, -v}``.

O modulo tambem fornece avaliacao logaritmica, aritmetica Decimal e os
16 ramos da reversao complexa. Nenhum clamp ou epsilon e imposto ao modelo.
"""

from __future__ import annotations

import argparse
import cmath
import json
import math
from dataclasses import asdict, dataclass
from decimal import Decimal, localcontext
from typing import Iterable, Sequence

import numpy as np


GOLDEN_RATIO = (1.0 + math.sqrt(5.0)) / 2.0
ODD_EXPONENTS = (1, 3, 5, 7)
MODEL_POWER = sum(ODD_EXPONENTS)


class ModelDomainError(ValueError):
    """Indica que um valor nao pertence ao dominio matematico do modelo."""


class VectorRepresentationError(ValueError):
    """Indica que uma matriz nao representa uma classe vetorial valida."""


@dataclass(frozen=True, slots=True)
class ScalarRoundTrip:
    """Resultado auditavel de uma transformacao escalar de ida e volta."""

    input_value: float
    encoded_value: float
    canonical_value: float
    reconstructed_value: float
    absolute_residual: float
    equivalent: bool


@dataclass(frozen=True, slots=True)
class VectorDecodeResult:
    """Resultado da reversao de uma matriz vetorial invariante ao sinal."""

    canonical_vector: np.ndarray
    canonical_direction: np.ndarray
    magnitude: float
    principal_eigenvalue: float
    reconstructed_matrix: np.ndarray
    absolute_residual: float
    relative_residual: float
    rank: int


def _finite_real(value: float, name: str) -> float:
    result = float(value)
    if not math.isfinite(result):
        raise ModelDomainError(f"{name} deve ser real e finito; recebido {value!r}.")
    return result


def _json_ready(value: object) -> object:
    """Converte dataclasses, arrays e complexos em estruturas JSON."""

    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, complex):
        return {"real": value.real, "imag": value.imag}
    if isinstance(value, Decimal):
        return str(value)
    if hasattr(value, "__dataclass_fields__"):
        return {key: _json_ready(item) for key, item in asdict(value).items()}
    if isinstance(value, dict):
        return {str(key): _json_ready(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_json_ready(item) for item in value]
    if isinstance(value, np.generic):
        return value.item()
    return value


@dataclass(frozen=True, slots=True)
class EquivalenceEngine:
    """Implementa o modelo reversivel de equivalencia de ordem 16.

    Parameters
    ----------
    n:
        Parametro positivo do modelo. Pode representar dimensao, ordem ou
        outra grandeza, desde que seu significado seja definido pela aplicacao.
    phi:
        Fator positivo. O padrao e a razao aurea ``(1 + sqrt(5)) / 2``.
    """

    n: float
    phi: float = GOLDEN_RATIO

    def __post_init__(self) -> None:
        n = _finite_real(self.n, "n")
        phi = _finite_real(self.phi, "phi")
        if n <= 0.0:
            raise ModelDomainError("n deve ser estritamente positivo.")
        if phi <= 0.0:
            raise ModelDomainError("phi deve ser estritamente positivo.")
        object.__setattr__(self, "n", n)
        object.__setattr__(self, "phi", phi)

    @property
    def scale(self) -> float:
        """Retorna ``A_n = phi * sqrt(n / 3)``."""

        return self.phi * math.sqrt(self.n / 3.0)

    @staticmethod
    def canonical_scalar(z: float) -> float:
        """Representante canonico da classe real ``[z] = {z, -z}``."""

        return abs(_finite_real(z, "z"))

    @staticmethod
    def real_equivalence_class(z: float) -> tuple[float, ...]:
        """Retorna a classe real; zero possui apenas um representante."""

        magnitude = EquivalenceEngine.canonical_scalar(z)
        if magnitude == 0.0:
            return (0.0,)
        return (-magnitude, magnitude)

    @staticmethod
    def equivalent_real(
        z1: float,
        z2: float,
        *,
        rel_tol: float = 1e-12,
        abs_tol: float = 0.0,
    ) -> bool:
        """Testa equivalencia real por igualdade de magnitudes."""

        return math.isclose(
            abs(_finite_real(z1, "z1")),
            abs(_finite_real(z2, "z2")),
            rel_tol=rel_tol,
            abs_tol=abs_tol,
        )

    def encode_scalar(self, z: float) -> float:
        """Calcula ``Y = A_n * z^16`` em ponto flutuante."""

        magnitude = self.canonical_scalar(z)
        try:
            return self.scale * magnitude**MODEL_POWER
        except OverflowError as exc:
            raise OverflowError(
                "A avaliacao direta excedeu a faixa numerica; use encode_log()."
            ) from exc

    def decode_scalar(self, y: float) -> float:
        """Recupera o representante canonico ``Z = (Y / A_n)^(1/16)``."""

        y_value = _finite_real(y, "y")
        if y_value < 0.0:
            raise ModelDomainError(
                "y deve ser nao negativo no modelo real de equivalencia."
            )
        if y_value == 0.0:
            return 0.0
        return (y_value / self.scale) ** (1.0 / MODEL_POWER)

    def encode_log(self, z: float) -> float:
        """Retorna ``log(Y)`` sem formar ``z^16`` diretamente.

        Para ``z = 0``, retorna ``-inf``, representacao exata de ``log(0)``.
        """

        magnitude = self.canonical_scalar(z)
        if magnitude == 0.0:
            return -math.inf
        return math.log(self.scale) + MODEL_POWER * math.log(magnitude)

    def decode_log_magnitude(self, log_y: float) -> float:
        """Retorna ``log(Z)`` a partir de ``log(Y)`` sem impor limites."""

        log_value = float(log_y)
        if math.isnan(log_value) or log_value == math.inf:
            raise ModelDomainError("log_y deve ser finito ou -inf para o caso nulo.")
        if log_value == -math.inf:
            return -math.inf
        return (log_value - math.log(self.scale)) / MODEL_POWER

    def decode_from_log(self, log_y: float) -> float:
        """Recupera ``Z`` a partir de ``log(Y)``.

        Se o valor final estiver fora da faixa do tipo float, o chamador pode
        conservar diretamente o resultado de :meth:`decode_log_magnitude`.
        """

        log_z = self.decode_log_magnitude(log_y)
        if log_z == -math.inf:
            return 0.0
        try:
            return math.exp(log_z)
        except OverflowError as exc:
            raise OverflowError(
                "Z excede a faixa float; conserve log(Z) ou use Decimal."
            ) from exc

    def decimal_scale(self, *, precision: int = 80) -> Decimal:
        """Calcula o fator em aritmetica Decimal de precisao configuravel."""

        if precision < 18:
            raise ValueError("precision deve ser pelo menos 18 digitos.")
        with localcontext() as context:
            context.prec = precision
            n_value = Decimal(str(self.n))
            if math.isclose(self.phi, GOLDEN_RATIO, rel_tol=0.0, abs_tol=0.0):
                phi_value = (Decimal(1) + Decimal(5).sqrt()) / Decimal(2)
            else:
                phi_value = Decimal(str(self.phi))
            return +(phi_value * (n_value / Decimal(3)).sqrt())

    def encode_scalar_decimal(
        self,
        z: Decimal | int | float | str,
        *,
        precision: int = 80,
    ) -> Decimal:
        """Calcula a transformacao sem o limite de expoente do float64."""

        with localcontext() as context:
            context.prec = precision
            value = z if isinstance(z, Decimal) else Decimal(str(z))
            if not value.is_finite():
                raise ModelDomainError("z deve ser Decimal finito.")
            return +(self.decimal_scale(precision=precision) * abs(value) ** MODEL_POWER)

    def decode_scalar_decimal(
        self,
        y: Decimal | int | float | str,
        *,
        precision: int = 80,
    ) -> Decimal:
        """Reverte por quatro raizes quadradas: ``16 = 2^4``."""

        with localcontext() as context:
            context.prec = precision
            value = y if isinstance(y, Decimal) else Decimal(str(y))
            if not value.is_finite() or value < 0:
                raise ModelDomainError("y deve ser Decimal finito e nao negativo.")
            if value == 0:
                return Decimal(0)
            root = value / self.decimal_scale(precision=precision)
            for _ in range(4):
                root = root.sqrt()
            return +root

    def scalar_round_trip(
        self,
        z: float,
        *,
        rel_tol: float = 2e-12,
        abs_tol: float = 0.0,
    ) -> ScalarRoundTrip:
        """Executa e audita a transformacao escalar completa."""

        input_value = _finite_real(z, "z")
        encoded = self.encode_scalar(input_value)
        canonical = self.decode_scalar(encoded)
        reconstructed = self.encode_scalar(canonical)
        residual = abs(reconstructed - encoded)
        equivalent = self.equivalent_real(
            input_value, canonical, rel_tol=rel_tol, abs_tol=abs_tol
        )
        return ScalarRoundTrip(
            input_value=input_value,
            encoded_value=encoded,
            canonical_value=canonical,
            reconstructed_value=reconstructed,
            absolute_residual=residual,
            equivalent=equivalent,
        )

    def encode_complex(self, z: complex) -> complex:
        """Calcula a transformacao complexa ``Y = A_n z^16``."""

        value = complex(z)
        if not all(math.isfinite(part) for part in (value.real, value.imag)):
            raise ModelDomainError("z complexo deve possuir partes finitas.")
        return self.scale * value**MODEL_POWER

    def decode_complex_roots(self, y: complex) -> tuple[complex, ...]:
        """Retorna todos os 16 ramos complexos da equacao ``A_n z^16 = Y``."""

        value = complex(y)
        if not all(math.isfinite(part) for part in (value.real, value.imag)):
            raise ModelDomainError("y complexo deve possuir partes finitas.")
        if value == 0j:
            return (0j,)
        normalized = value / self.scale
        radius = abs(normalized) ** (1.0 / MODEL_POWER)
        angle = cmath.phase(normalized)
        return tuple(
            radius
            * cmath.exp(1j * (angle + 2.0 * math.pi * branch) / MODEL_POWER)
            for branch in range(MODEL_POWER)
        )

    def equivalent_complex(
        self,
        z1: complex,
        z2: complex,
        *,
        rel_tol: float = 1e-11,
        abs_tol: float = 1e-13,
    ) -> bool:
        """Testa se dois complexos pertencem a mesma orbita de ordem 16."""

        y1 = self.encode_complex(z1)
        y2 = self.encode_complex(z2)
        return math.isclose(y1.real, y2.real, rel_tol=rel_tol, abs_tol=abs_tol) and math.isclose(
            y1.imag, y2.imag, rel_tol=rel_tol, abs_tol=abs_tol
        )

    @staticmethod
    def canonicalize_vector_sign(vector: Sequence[float] | np.ndarray) -> np.ndarray:
        """Escolhe sinal deterministico pela componente de maior modulo."""

        array = np.asarray(vector, dtype=float)
        if array.ndim != 1 or array.size == 0:
            raise ModelDomainError("O vetor deve ser unidimensional e nao vazio.")
        if not np.all(np.isfinite(array)):
            raise ModelDomainError("O vetor deve conter apenas valores finitos.")
        if not np.any(array):
            return array.copy()
        pivot = int(np.argmax(np.abs(array)))
        return -array if array[pivot] < 0.0 else array.copy()

    @staticmethod
    def equivalent_vectors(
        vector1: Sequence[float] | np.ndarray,
        vector2: Sequence[float] | np.ndarray,
        *,
        rtol: float = 1e-10,
        atol: float = 1e-12,
    ) -> bool:
        """Testa ``v ~= w`` ou ``v ~= -w``."""

        first = np.asarray(vector1, dtype=float)
        second = np.asarray(vector2, dtype=float)
        if first.shape != second.shape or first.ndim != 1:
            return False
        return bool(
            np.allclose(first, second, rtol=rtol, atol=atol)
            or np.allclose(first, -second, rtol=rtol, atol=atol)
        )

    def encode_vector(self, vector: Sequence[float] | np.ndarray) -> np.ndarray:
        """Codifica a classe vetorial em uma matriz PSD de posto no maximo 1.

        Implementa ``M = A_n ||v||^14 v v^T`` de forma numericamente clara.
        """

        array = np.asarray(vector, dtype=float)
        if array.ndim != 1 or array.size == 0:
            raise ModelDomainError("O vetor deve ser unidimensional e nao vazio.")
        if not np.all(np.isfinite(array)):
            raise ModelDomainError("O vetor deve conter apenas valores finitos.")
        magnitude = float(np.linalg.norm(array))
        if magnitude == 0.0:
            return np.zeros((array.size, array.size), dtype=float)
        direction = array / magnitude
        principal_eigenvalue = self.scale * magnitude**MODEL_POWER
        return principal_eigenvalue * np.outer(direction, direction)

    def decode_vector(
        self,
        matrix: Sequence[Sequence[float]] | np.ndarray,
        *,
        rtol: float = 1e-10,
        atol: float = 0.0,
    ) -> VectorDecodeResult:
        """Reverte uma matriz vetorial valida para o representante canonico.

        A matriz deve ser real, simetrica, positiva semidefinida e possuir posto
        zero ou um dentro das tolerancias fornecidas.
        """

        value = np.asarray(matrix, dtype=float)
        if value.ndim != 2 or value.shape[0] != value.shape[1] or value.shape[0] == 0:
            raise VectorRepresentationError("A representacao deve ser uma matriz quadrada.")
        if not np.all(np.isfinite(value)):
            raise VectorRepresentationError("A matriz deve conter apenas valores finitos.")
        if not np.allclose(value, value.T, rtol=rtol, atol=atol):
            raise VectorRepresentationError("A matriz deve ser simetrica.")

        symmetric = 0.5 * (value + value.T)
        matrix_norm = float(np.linalg.norm(symmetric, ord=2))
        dimension = symmetric.shape[0]
        if matrix_norm == 0.0:
            zero_vector = np.zeros(dimension, dtype=float)
            zero_matrix = np.zeros_like(symmetric)
            return VectorDecodeResult(
                canonical_vector=zero_vector,
                canonical_direction=zero_vector.copy(),
                magnitude=0.0,
                principal_eigenvalue=0.0,
                reconstructed_matrix=zero_matrix,
                absolute_residual=0.0,
                relative_residual=0.0,
                rank=0,
            )

        eigenvalues, eigenvectors = np.linalg.eigh(symmetric)
        tolerance = max(float(atol), float(rtol) * matrix_norm)
        if float(eigenvalues[0]) < -tolerance:
            raise VectorRepresentationError("A matriz nao e positiva semidefinida.")

        positive = np.flatnonzero(eigenvalues > tolerance)
        if positive.size > 1:
            raise VectorRepresentationError("A matriz possui posto superior a um.")

        principal_eigenvalue = max(float(eigenvalues[-1]), 0.0)
        if principal_eigenvalue <= tolerance:
            zero_vector = np.zeros(dimension, dtype=float)
            zero_matrix = np.zeros_like(symmetric)
            residual = float(np.linalg.norm(symmetric, ord="fro"))
            return VectorDecodeResult(
                canonical_vector=zero_vector,
                canonical_direction=zero_vector.copy(),
                magnitude=0.0,
                principal_eigenvalue=0.0,
                reconstructed_matrix=zero_matrix,
                absolute_residual=residual,
                relative_residual=1.0,
                rank=0,
            )

        direction = self.canonicalize_vector_sign(eigenvectors[:, -1])
        magnitude = (principal_eigenvalue / self.scale) ** (1.0 / MODEL_POWER)
        canonical_vector = magnitude * direction
        reconstructed = self.encode_vector(canonical_vector)
        absolute_residual = float(np.linalg.norm(reconstructed - symmetric, ord="fro"))
        relative_residual = absolute_residual / float(
            np.linalg.norm(symmetric, ord="fro")
        )
        return VectorDecodeResult(
            canonical_vector=canonical_vector,
            canonical_direction=direction,
            magnitude=magnitude,
            principal_eigenvalue=principal_eigenvalue,
            reconstructed_matrix=reconstructed,
            absolute_residual=absolute_residual,
            relative_residual=relative_residual,
            rank=1,
        )

    def vector_round_trip(
        self,
        vector: Sequence[float] | np.ndarray,
        *,
        rtol: float = 1e-10,
        atol: float = 1e-12,
    ) -> dict[str, object]:
        """Executa ida e volta vetorial e retorna um relatorio auditavel."""

        original = np.asarray(vector, dtype=float)
        encoded = self.encode_vector(original)
        decoded = self.decode_vector(encoded, rtol=rtol, atol=0.0)
        return {
            "input_vector": original,
            "encoded_matrix": encoded,
            "decoded": decoded,
            "equivalent": self.equivalent_vectors(
                original, decoded.canonical_vector, rtol=rtol, atol=atol
            ),
        }


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Motor reversivel de equivalencia de ordem 16."
    )
    parser.add_argument("--n", type=float, default=3.0, help="Parametro positivo n.")
    parser.add_argument(
        "--phi", type=float, default=GOLDEN_RATIO, help="Fator positivo phi."
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    scalar = subparsers.add_parser("scalar", help="Executa ida e volta escalar.")
    scalar.add_argument("z", type=float)

    vector = subparsers.add_parser("vector", help="Executa ida e volta vetorial.")
    vector.add_argument("values", nargs="+", type=float)

    complex_parser = subparsers.add_parser(
        "complex", help="Codifica um complexo e recupera os 16 ramos."
    )
    complex_parser.add_argument("real", type=float)
    complex_parser.add_argument("imag", type=float)
    return parser


def main(argv: Iterable[str] | None = None) -> int:
    """Interface de linha de comando do motor."""

    arguments = _build_parser().parse_args(argv)
    engine = EquivalenceEngine(n=arguments.n, phi=arguments.phi)

    if arguments.command == "scalar":
        report: object = engine.scalar_round_trip(arguments.z)
    elif arguments.command == "vector":
        report = engine.vector_round_trip(arguments.values)
    else:
        original = complex(arguments.real, arguments.imag)
        encoded = engine.encode_complex(original)
        roots = engine.decode_complex_roots(encoded)
        report = {
            "input": original,
            "encoded": encoded,
            "root_count": len(roots),
            "roots": roots,
            "nearest_root_error": min(abs(root - original) for root in roots),
            "max_reconstruction_residual": max(
                abs(engine.encode_complex(root) - encoded) for root in roots
            ),
        }

    print(json.dumps(_json_ready(report), indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
