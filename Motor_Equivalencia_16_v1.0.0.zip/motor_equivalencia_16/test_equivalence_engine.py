"""Testes do Motor de Equivalencia Reversivel de Ordem 16.

Executar com:

    python -m unittest -v test_equivalence_engine.py
"""

from __future__ import annotations

import math
import unittest
from decimal import Decimal

import numpy as np

from equivalence_engine import (
    GOLDEN_RATIO,
    MODEL_POWER,
    ODD_EXPONENTS,
    EquivalenceEngine,
    ModelDomainError,
    VectorRepresentationError,
)


class ScalarModelTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = EquivalenceEngine(n=3)

    def test_model_power_is_sum_of_odd_exponents(self) -> None:
        self.assertEqual(ODD_EXPONENTS, (1, 3, 5, 7))
        self.assertEqual(sum(ODD_EXPONENTS), 16)
        self.assertEqual(MODEL_POWER, 16)

    def test_golden_ratio_inverse_identity(self) -> None:
        self.assertAlmostEqual(1.0 / GOLDEN_RATIO, GOLDEN_RATIO - 1.0, places=15)

    def test_scale_at_n_equal_three_is_phi(self) -> None:
        self.assertAlmostEqual(self.engine.scale, GOLDEN_RATIO, places=15)

    def test_real_sign_invariance(self) -> None:
        for value in (0.0, 0.25, 0.92, 2.0, 8.5):
            with self.subTest(value=value):
                self.assertEqual(
                    self.engine.encode_scalar(value),
                    self.engine.encode_scalar(-value),
                )

    def test_scalar_round_trip_recovers_equivalence_class(self) -> None:
        for value in (-10.0, -2.0, -0.92, -1e-8, 0.0, 1e-8, 0.92, 2.0, 10.0):
            with self.subTest(value=value):
                report = self.engine.scalar_round_trip(value)
                self.assertTrue(report.equivalent)
                self.assertAlmostEqual(report.canonical_value, abs(value), places=12)
                self.assertTrue(
                    math.isclose(
                        report.encoded_value,
                        report.reconstructed_value,
                        rel_tol=2e-12,
                        abs_tol=0.0,
                    )
                )

    def test_zero_is_unique_zero_class(self) -> None:
        self.assertEqual(self.engine.real_equivalence_class(0.0), (0.0,))
        self.assertEqual(self.engine.encode_scalar(0.0), 0.0)
        self.assertEqual(self.engine.decode_scalar(0.0), 0.0)

    def test_negative_real_output_is_rejected(self) -> None:
        with self.assertRaises(ModelDomainError):
            self.engine.decode_scalar(-1.0)

    def test_n_must_be_positive(self) -> None:
        for invalid in (0.0, -1.0, float("inf"), float("nan")):
            with self.subTest(invalid=invalid):
                with self.assertRaises(ModelDomainError):
                    EquivalenceEngine(n=invalid)

    def test_log_round_trip_over_extreme_dynamic_range(self) -> None:
        for exponent in (-1000.0, -200.0, -20.0, 0.0, 100.0):
            with self.subTest(exponent=exponent):
                log_y = math.log(self.engine.scale) + MODEL_POWER * exponent
                recovered_log_z = self.engine.decode_log_magnitude(log_y)
                self.assertAlmostEqual(recovered_log_z, exponent, places=12)

    def test_decimal_mode_has_no_float_underflow_cutoff(self) -> None:
        value = Decimal("1e-100")
        encoded = self.engine.encode_scalar_decimal(value, precision=100)
        decoded = self.engine.decode_scalar_decimal(encoded, precision=100)
        relative_error = abs(decoded - value) / value
        self.assertLess(relative_error, Decimal("1e-90"))
        self.assertNotEqual(encoded, Decimal(0))


class ComplexModelTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = EquivalenceEngine(n=15)

    def test_complex_reversal_has_sixteen_branches(self) -> None:
        original = complex(1.2, -0.7)
        encoded = self.engine.encode_complex(original)
        roots = self.engine.decode_complex_roots(encoded)
        self.assertEqual(len(roots), 16)
        self.assertLess(min(abs(root - original) for root in roots), 2e-14)
        self.assertLess(
            max(abs(self.engine.encode_complex(root) - encoded) for root in roots),
            2e-10,
        )

    def test_sixteenth_root_rotation_is_equivalent(self) -> None:
        original = complex(0.4, 1.1)
        for branch in range(16):
            rotated = original * np.exp(2j * np.pi * branch / 16)
            with self.subTest(branch=branch):
                self.assertTrue(self.engine.equivalent_complex(original, rotated))

    def test_complex_zero_has_one_distinct_root(self) -> None:
        self.assertEqual(self.engine.decode_complex_roots(0j), (0j,))


class VectorModelTests(unittest.TestCase):
    def setUp(self) -> None:
        self.engine = EquivalenceEngine(n=7)

    def test_vector_sign_invariance(self) -> None:
        vector = np.array([1.5, -2.0, 0.25, 4.0])
        np.testing.assert_allclose(
            self.engine.encode_vector(vector),
            self.engine.encode_vector(-vector),
            rtol=0.0,
            atol=0.0,
        )

    def test_vector_round_trip_recovers_full_equivalence_class(self) -> None:
        vectors = (
            np.array([1.0, 2.0, 3.0]),
            np.array([-4.0, 0.25, 2.0]),
            np.array([1e-6, -2e-6, 3e-6, 4e-6]),
        )
        for vector in vectors:
            with self.subTest(vector=vector):
                report = self.engine.vector_round_trip(vector)
                decoded = report["decoded"]
                self.assertTrue(report["equivalent"])
                self.assertEqual(decoded.rank, 1)
                self.assertLess(decoded.relative_residual, 2e-12)

    def test_zero_vector_round_trip(self) -> None:
        vector = np.zeros(5)
        matrix = self.engine.encode_vector(vector)
        decoded = self.engine.decode_vector(matrix)
        self.assertEqual(decoded.rank, 0)
        self.assertEqual(decoded.magnitude, 0.0)
        np.testing.assert_array_equal(decoded.canonical_vector, vector)

    def test_rejects_nonsymmetric_matrix(self) -> None:
        matrix = np.array([[1.0, 1.0], [0.0, 1.0]])
        with self.assertRaises(VectorRepresentationError):
            self.engine.decode_vector(matrix)

    def test_rejects_rank_two_matrix(self) -> None:
        matrix = np.eye(3)
        with self.assertRaises(VectorRepresentationError):
            self.engine.decode_vector(matrix)

    def test_rejects_indefinite_matrix(self) -> None:
        matrix = np.diag([1.0, -0.5, 0.0])
        with self.assertRaises(VectorRepresentationError):
            self.engine.decode_vector(matrix)


if __name__ == "__main__":
    unittest.main(verbosity=2)
