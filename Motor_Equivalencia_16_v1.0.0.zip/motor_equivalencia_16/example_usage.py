"""Exemplos minimos dos motores matematico e visual."""

from pathlib import Path

import numpy as np

from equivalence_engine import EquivalenceEngine
from equivalence_matplotlib import EquivalencePlotter


def main() -> None:
    engine = EquivalenceEngine(n=3)

    scalar = engine.scalar_round_trip(-0.92)
    print("Escalar:")
    print(f"  entrada = {scalar.input_value}")
    print(f"  Y = {scalar.encoded_value:.12g}")
    print(f"  representante canonico = {scalar.canonical_value:.12g}")
    print(f"  equivalente = {scalar.equivalent}")

    vector = np.array([1.0, -2.0, 3.0])
    matrix = engine.encode_vector(vector)
    decoded = engine.decode_vector(matrix)
    print("\nVetor:")
    print(f"  entrada = {vector}")
    print(f"  magnitude recuperada = {decoded.magnitude:.12g}")
    print(f"  vetor canonico = {decoded.canonical_vector}")
    print(f"  residuo relativo = {decoded.relative_residual:.3e}")

    complex_value = 1.2 - 0.7j
    encoded_complex = engine.encode_complex(complex_value)
    roots = engine.decode_complex_roots(encoded_complex)
    print("\nComplexo:")
    print(f"  numero de ramos = {len(roots)}")
    print(f"  erro do ramo original = {min(abs(root-complex_value) for root in roots):.3e}")

    output = Path(__file__).with_name("equivalence_dashboard_example.png")
    EquivalencePlotter(engine).save_dashboard(output)
    print(f"\nPainel salvo em: {output}")


if __name__ == "__main__":
    main()
